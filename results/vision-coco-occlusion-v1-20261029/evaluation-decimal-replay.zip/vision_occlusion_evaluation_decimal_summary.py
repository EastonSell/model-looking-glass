"""Independent Decimal reconstruction of closed occlusion study logit effects.

Only saved logits and audited case records are read. This does not verify
patch landings, execution, input provenance, causal mediation or generality.
"""
import argparse
from decimal import Decimal, localcontext
import hashlib
import json
import math
from pathlib import Path
import struct

AUDIT_SHA = 'db69cb0c4d0e93dfd578ec03e035399ca19f3b3447f6d2db7575d2034a7313b5'
TERMINAL_SHA = 'b15cb5c818df86746d35c62b1452e8c0f6f589adf3a17d579256d4675f779b64'
CONDITIONS = ('animal_mask', 'background_mask', 'animal_transfer', 'background_transfer',
              'animal_random', 'background_random')


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path, limit):
    with path.open('rb') as stream:
        raw = stream.read(limit + 1)
    require(0 < len(raw) <= limit, 'saved file is empty or too large')
    return raw


def logits_for(data, index, label):
    record = json.loads(read(data / f'forward-{index:03d}.json', 200_000))
    payload = read(data / f'forward-{index:03d}.bin', 1_000_000)
    layout = record['layout']['logits']
    require(type(record['submission']) is int and record['submission'] == index and
            record['label'] == label and record['sha256'] == digest(payload) and
            layout['shape'] == [1, 1000] and type(layout['offset']) is int and
            type(layout['bytes']) is int and layout['bytes'] == 4000 and
            0 <= layout['offset'] <= len(payload) - 4000, 'saved logit identity differs')
    values = struct.unpack_from('<1000f', payload, layout['offset'])
    require(all(math.isfinite(x) for x in values), 'nonfinite saved logit')
    return values


def distribution(logits, category):
    values = [Decimal.from_float(x) for x in logits]
    maximum = max(values)
    exps = [(x - maximum).exp() for x in values]
    total = sum(exps)
    group = range(281, 286) if category == 17 else range(151, 269)
    group_total = sum(exps[i] for i in group)
    require(group_total > 0 and total > 0, 'invalid group probability')
    return {'values': values, 'max': maximum, 'log_total': total.ln(),
            'probs': [x / total for x in exps],
            'log_group': group_total.ln() - total.ln(),
            'top1': values.index(maximum)}


def effects(clean, changed):
    tv = sum(abs(a-b) for a, b in zip(clean['probs'], changed['probs'])) / 2
    kl = sum(p * ((a - clean['max'] - clean['log_total']) -
                  (b - changed['max'] - changed['log_total']))
             for p, a, b in zip(clean['probs'], clean['values'], changed['values']))
    # Roundoff in a finite Decimal context may produce a vanishing negative KL.
    if kl < 0 and abs(kl) < Decimal('1e-55'):
        kl = Decimal(0)
    require(tv >= 0 and kl >= 0, 'invalid distribution effect')
    return tv, kl, clean['top1'] != changed['top1']


def run(data, audit_path):
    audited_raw = read(audit_path, 5_000_000)
    terminal_raw = read(data / 'terminal.json', 5_000_000)
    require(digest(audited_raw) == AUDIT_SHA and digest(terminal_raw) == TERMINAL_SHA,
            'closed audit or terminal hash differs')
    audited, terminal = json.loads(audited_raw)['result'], json.loads(terminal_raw)
    require(audited['mode'] == 'evaluation' and audited['forwards'] == 144 and
            audited['phase_terminal_sha256'] == TERMINAL_SHA and len(terminal['cases']) == 8 and
            audited['selected'] == [row['image_id'] for row in terminal['cases']], 'case inventory differs')
    results, max_error, top_changes = [], 0., 0
    with localcontext() as context:
        context.prec = 60
        for number, (case, audited_case) in enumerate(zip(terminal['cases'], audited['cases'])):
            ident, category = case['image_id'], case['category_id']
            require((type(ident) is int and type(category) is int and category in (17, 18) and
                     ident == audited_case['image_id'] and audited_case['dose_status'] == 'matchable'),
                    'case or previously audited dose differs')
            base = number * 18 + 1
            clean = distribution(logits_for(data, base, f'case-{ident}:clean'), category)
            # The fixed 18-forward schedule places masks at +1/+2, then the
            # transfer and random arms at +11 through +14.
            offsets = dict(zip(CONDITIONS, (1, 2, 11, 12, 13, 14)))
            drops, details = {}, {}
            for name in CONDITIONS:
                changed = distribution(logits_for(data, base + offsets[name], f'case-{ident}:{name}'), category)
                drop = clean['log_group'] - changed['log_group']
                tv, kl, top = effects(clean, changed)
                saved = case['conditions'][name]
                for key, actual in (('drop', drop), ('tv', tv), ('kl_clean_to_patched', kl)):
                    error = abs(float(actual) - saved[key])
                    require(error <= 1e-10, 'saved continuous effect differs from Decimal replay')
                    max_error = max(max_error, error)
                require(type(saved['top1_changed']) is bool and saved['top1_changed'] == top,
                        'top-one change differs')
                top_changes += int(top)
                drops[name] = drop
                details[name] = {'drop': float(drop), 'tv': float(tv),
                                 'kl_clean_to_patched': float(kl), 'top1_changed': top}
            b = drops['animal_mask'] - drops['background_mask']
            t = drops['animal_transfer'] - drops['background_transfer']
            ra, rb = drops['animal_random'], drops['background_random']
            values = {'occlusion_contrast': float(b), 'transfer_contrast': float(t),
                      'animal_random_drop': float(ra), 'background_random_drop': float(rb),
                      'random_contrast': float(ra-rb)}
            for key, value in values.items():
                expected = audited_case['comparisons'][key]
                error = abs(value - expected)
                require(error <= 1e-10, 'audited comparison differs from Decimal replay')
                max_error = max(max_error, error)
            decision = (b >= Decimal.from_float(.05) and t >= Decimal.from_float(.025) and
                        t - max(abs(ra), abs(rb)) >= Decimal.from_float(.025))
            require(decision == audited_case['comparisons']['positive'], 'Decimal and audited decision differ')
            results.append({'image_id': ident, 'category_id': category, 'drops_and_distribution': details,
                            **values, 'positive': decision,
                            'mask_threshold_pass': b >= Decimal.from_float(.05),
                            'transfer_threshold_pass': t >= Decimal.from_float(.025),
                            'control_adjusted_threshold_pass':
                                t - max(abs(ra), abs(rb)) >= Decimal.from_float(.025)})
    require(sum(row['positive'] for row in results) == audited['aggregate']['positive'] and
            audited['aggregate'] == {'status': 'negative', 'evaluable': 8, 'positive': 0, 'cats': 4, 'dogs': 4},
            'aggregate differs')
    return {'schema': 'vision-occlusion-evaluation-decimal-summary-v1', 'audit_sha256': AUDIT_SHA,
            'terminal_sha256': TERMINAL_SHA, 'cases': results,
            'max_absolute_saved_or_audited_error': max_error,
            'top1_changes_of_48_interventions': top_changes,
            'scope': '60-digit Decimal replay of saved logits and joint decision; masks, patch landing, '
                     'dose, execution and source authenticity require separate evidence.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', type=Path, required=True)
    parser.add_argument('--audit', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    result = run(args.data, args.audit)
    raw = (json.dumps(result, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()
    with args.report.open('xb') as out:
        require(out.write(raw) == len(raw), 'short report write')
    print(json.dumps({'report_sha256': digest(raw), 'cases': len(result['cases']),
                      'max_abs_error': result['max_absolute_saved_or_audited_error']}))


if __name__ == '__main__':
    main()
