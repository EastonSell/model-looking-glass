"""Independently replay closed ViT occlusion/transfer evidence using stdlib.

Input files must be quiescent. This checks saved-byte and arithmetic consistency,
not model execution, source or asset authenticity, process exit, chronology,
pretraining independence, causal mediation, or population generalization.
"""
import argparse
import hashlib
import importlib.util
import io
import json
import math
from pathlib import Path
import re
import zipfile

HELPER_SHA = '651e16ad4d074eaced60b48dc801bd81a58b932e8833edeee1883d47a116df61'
HELPER_PATH = Path(__file__).with_name('vision_cls_v5_intervention_independent.py')
if hashlib.sha256(HELPER_PATH.read_bytes()).hexdigest() != HELPER_SHA:
    raise ValueError('fixed arithmetic helper differs')
spec = importlib.util.spec_from_file_location('fixed_occlusion_arithmetic', HELPER_PATH)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
s = helper.s

MANIFEST_SHA = 'aa61b294710f5a6cd9682dc783085c7079f1addfbad8257fdbd893d143ce4cef'
V6_MANIFEST_SHA = '586e0abe9c06a2eb02ad74dc8bda38137349cf1d5953363b2a190ae59d2f0075'
V6_SCREEN_SHA = '2e51bd187d6b0762874030cbe3dbcd64c16a532f969e09e56730816cced0777e'
V6_ARCHIVE_SHA = '7b88dc730498fad1418b8b0c54a33e673357252093a460611f440187a63e0f76'
DISCOVERY_IDS = (328437, 142719, 476736, 503893)
STATE_BYTES = 197 * 192 * 4
TOKEN_BYTES = 192 * 4
PIXEL_BYTES = 3 * 224 * 224 * 4


def radius(row, col):
    return (row - 6) ** 2 + (col - 6) ** 2


def rectangle(row, col):
    return (16 * col, 16 * row, 16 * (col + 2), 16 * (row + 2))


def overlaps(a, b):
    return min(a[2], b[2]) > max(a[0], b[0]) and min(a[3], b[3]) > max(a[1], b[1])


def tokens(row, col):
    return [1 + 14 * (row + dr) + col + dc for dr in range(2) for dc in range(2)]


def geometry(image):
    """Reconstruct geometry from saved annotation-derived sites and boxes."""
    width, height = image['width'], image['height']
    s.require(type(width) is int and type(height) is int and width > 0 and height > 0, 'image dimensions')
    box = image['bbox_resized_xyxy']
    s.require(type(box) is list and len(box) == 4 and all(type(v) in (int, float) and math.isfinite(v)
                                                         for v in box), 'animal box')
    boxes = [box]
    for ann in image['other_boxes']:
        x, y, w, h = ann['bbox_xywh']
        s.require(all(type(v) in (int, float) and math.isfinite(v) for v in (x, y, w, h)) and w >= 0 and h >= 0,
                  'other box')
        boxes.append((224*x/width, 224*y/height, 224*(x+w)/width, 224*(y+h)/height))
    choices, seen = [], set()
    for site in image['sites']:
        row, col = site['row_col']
        s.require(type(row) is int and type(col) is int and 0 <= row <= 12 and 0 <= col <= 12
                  and (row, col) not in seen, 'site coordinates')
        seen.add((row, col))
        counts = site['token_mask_pixels']
        s.require(type(counts) is list and len(counts) == 4 and all(type(x) is int and 0 <= x <= 256 for x in counts)
                  and type(site['mask_pixels']) is int and sum(counts) == site['mask_pixels']
                  and site['token_ids'] == tokens(row, col) and site['squared_center_radius'] == radius(row, col),
                  'site occupancy or tokens')
        a = rectangle(row, col)
        s.require(box[0] <= a[0] and box[1] <= a[1] and a[2] <= box[2] and a[3] <= box[3], 'site outside box')
        if site['mask_pixels'] < 768:
            continue
        for r in range(13):
            for c in range(13):
                if radius(r, c) == radius(row, col) and not any(overlaps(rectangle(r, c), b) for b in boxes):
                    choices.append((abs(row-r) + abs(col-c), radius(row, col), row, col, r, c, site))
    if not choices:
        return None
    best = min(choices, key=lambda x: x[:6])
    manhattan, rad, row, col, br, bc, site = best
    adjacent = [{'annotation_id': ann['annotation_id'], 'category_id': ann['category_id']}
                for ann, b in zip(image['other_boxes'], boxes[1:]) if overlaps(rectangle(row, col), b)]
    return {'animal': {'row_col': [row, col], 'token_ids': tokens(row, col), 'mask_pixels': site['mask_pixels'],
                       'token_mask_pixels': site['token_mask_pixels'],
                       'other_box_overlaps': sorted(adjacent, key=lambda x: x['annotation_id'])},
            'background': {'row_col': [br, bc], 'token_ids': tokens(br, bc)},
            'squared_center_radius': rad, 'manhattan_distance': manhattan}


def screen_inputs(manifest, manifest_sha, data):
    """Recompute all recognition gates and fixed-rank selected clean logits."""
    images = manifest['images']
    s.require(type(images) is list and len(images) == 64 and len({i['image_id'] for i in images}) == 64,
              'screen image inventory')
    _, summary = s.read_json(data / 'screen-result.json')
    s.require(summary.get('schema') == 'vision-occlusion-v1-screen-result'
              and summary.get('manifest_sha256') == manifest_sha and len(summary.get('screen', [])) == 64,
              'screen result identity')
    observed, logits = [], {}
    for n, image in enumerate(images, 1):
        _, row = s.read_json(data / f'forward-{n:03d}.json', 200_000)
        raw = s.bounded_read(data / f'forward-{n:03d}.bin', 4000)
        s.require(type(image['image_id']) is int and image['category_id'] in (17, 18)
                  and geometry(image) == image.get('occlusion_geometry'), 'screen image geometry')
        s.require(len(raw) == 4000 and row.get('submission') == n and type(row.get('submission')) is int
                  and row.get('label') == f"screen:{image['image_id']}" and row.get('file') == f'forward-{n:03d}.bin'
                  and row.get('dtype') == 'little-endian-float32' and row.get('sha256') == s.sha(raw)
                  and row.get('layout') == {'logits': {'shape': [1, 1000], 'offset': 0, 'bytes': 4000}}
                  and row.get('metadata') == {'kind': 'screen', 'image_id': image['image_id']}, 'screen forward')
        computed = s.screen_scoring(raw, image['category_id'])
        saved = row['score']
        s.check_score(saved, {k: v for k, v in computed.items() if k not in ('recognized', 'reasons', 'logit_sha256')})
        gate, reasons = s.reported_screen_gate(saved, image['category_id'])
        s.require(type(saved.get('recognized')) is bool and saved['recognized'] == computed['recognized'] == gate
                  and saved.get('reasons') == computed['reasons'] == reasons
                  and saved.get('logit_sha256') == computed['logit_sha256'], 'screen recognition')
        observed.append({'image_id': image['image_id'], **saved})
        logits[image['image_id']] = raw
    s.require(s.typed_equal(summary.get('screen'), observed), 'screen summary')
    selected, counts = [], {}
    for cat, name in ((17, 'cat'), (18, 'dog')):
        rows = [(i, r) for i, r in zip(images, observed) if i['category_id'] == cat]
        s.require(len(rows) == 32 and [i['rank'] for i, _ in rows] == list(range(32)), 'screen rank')
        eligible = [i for i, r in rows if r['recognized'] and i.get('occlusion_geometry') is not None]
        selected.extend(eligible[:4])
        counts[name] = {'candidates': 32, 'geometry_qualified': sum(i['occlusion_geometry'] is not None for i, _ in rows),
                        'screened': 32, 'recognized': sum(r['recognized'] for _, r in rows),
                        'recognized_geometry': len(eligible), 'selected': min(4, len(eligible))}
    s.require(summary.get('selected_ids') == [i['image_id'] for i in selected]
              and s.typed_equal(summary.get('counts'), counts), 'selected screen differs')
    return selected, logits


def discovery_inputs(prior_manifest, prior_screen, prior_archive):
    mraw, manifest = s.read_json(prior_manifest)
    rraw, result = s.read_json(prior_screen)
    archive = s.bounded_read(prior_archive, 5_000_000)
    s.require(s.sha(mraw) == V6_MANIFEST_SHA and s.sha(rraw) == V6_SCREEN_SHA
              and s.sha(archive) == V6_ARCHIVE_SHA, 'prior v6 public identities')
    images, rows = manifest['images'], result['screen']
    s.require(len(images) == len(rows) == 64 and [x['image_id'] for x in images] == [x['image_id'] for x in rows],
              'prior screen inventory')
    selected, logits, qualified = [], {}, {17: [], 18: []}
    with zipfile.ZipFile(io.BytesIO(archive)) as z:
        for n, (image, row) in enumerate(zip(images, rows), 1):
            ident = image['image_id']
            raw = z.read(f'forward-{n:03d}.bin')
            meta = json.loads(z.read(f'forward-{n:03d}.json'))
            score = s.screen_scoring(raw, image['category_id'])
            s.check_score(row, {k:v for k,v in score.items() if k not in ('recognized','reasons','logit_sha256')})
            recognized, reasons = s.reported_screen_gate(row, image['category_id'])
            s.require(len(raw) == 4000 and s.sha(raw) == row['logit_sha256'] == meta['sha256']
                      and type(row.get('recognized')) is bool and row['recognized'] == score['recognized'] == recognized
                      and row.get('reasons') == score['reasons'] == reasons, 'discovery screen logits')
            geom = geometry(image)
            if recognized and geom is not None:
                qualified[image['category_id']].append({**image, 'occlusion_geometry': geom})
            logits[ident] = raw
    for category in (17,18):
        selected.extend(sorted(qualified[category],key=lambda x:x['rank'])[:2])
    s.require(tuple(x['image_id'] for x in selected) == DISCOVERY_IDS, 'discovery selection')
    return selected, logits


def check_pixels(data, image, row, synthetic):
    raw = {}
    for name in ('clean', 'animal', 'background'):
        path = data / f"input-{image['image_id']}-{name}.bin"
        raw[name] = s.bounded_read(path, PIXEL_BYTES)
        s.require(len(raw[name]) == PIXEL_BYTES and s.sha(raw[name]) == row['input_sha256'][name], 'input hash')
        s.values(raw[name])
    if not synthetic:
        s.require(s.sha(raw['clean']) == image['pixel_sha256'], 'manifest pixel identity')
    for site in ('animal', 'background'):
        rr, cc = image['occlusion_geometry'][site]['row_col']
        expected = bytearray(raw['clean'])
        for channel in range(3):
            for y in range(16*rr, 16*(rr+2)):
                begin = ((channel*224 + y)*224 + 16*cc)*4
                expected[begin:begin+32*4] = bytes(32*4)
        s.require(raw[site] == expected, 'mask pixels or untouched bits differ')


def dose_plan(clean, animals, background, image, saved):
    ids = {k: image['occlusion_geometry'][k]['token_ids'] for k in ('animal', 'background')}
    own = {k: helper.block(clean, ids[k]) for k in ids}
    donors = {'animal': helper.block(animals, ids['animal']),
              'background': helper.block(background, ids['background'])}
    norms = {k: helper.distance(v, bytes(len(v))) for k, v in own.items()}
    distances = {k: helper.distance(own[k], donors[k]) for k in ids}
    helper.compare_nested(saved.get('receiver_norms'), norms, 'receiver norms')
    helper.compare_nested(saved.get('donor_distances'), distances, 'donor distances')
    s.require(all(type(saved[key][k]) in (int, float) and saved[key][k] >= 0
                  for key in ('receiver_norms', 'donor_distances') for k in ids), 'negative reported dose')
    def reasons(n, d):
        return [reason for k in ids for reason, bad in ((k+'-receiver-norm', n[k] <= 1e-6),
                                                         (k+'-donor-distance', d[k] <= 1e-6)) if bad]
    why = reasons(norms, distances)
    s.require(why == reasons(saved['receiver_norms'], saved['donor_distances']), 'reported eligibility boundary')
    if why:
        s.require(saved['status'] == 'dose-ineligible' and saved['reasons'] == why, 'dose ineligible')
        return 'dose-ineligible', {}, norms
    q = min(.196*norms['animal'], .196*norms['background'], *distances.values())
    rq = min(.196*saved['receiver_norms']['animal'], .196*saved['receiver_norms']['background'],
             *saved['donor_distances'].values())
    s.close(saved.get('q'), q, 'q differs')
    s.require(saved['q'] == rq and (q <= 1e-6) == (rq <= 1e-6), 'reported q bound')
    if q <= 1e-6:
        s.require(saved['status'] == 'dose-ineligible' and saved['reasons'] == ['q'], 'q ineligible')
        return 'dose-ineligible', {}, norms
    signs = [1.0 if hashlib.sha256(f"vision-coco-occlusion-v1:{image['image_id']}:{i}".encode('ascii')).digest()[0] & 1
             else -1.0 for i in range(768)]
    replacements, planned = {}, {}
    for site in ids:
        x, y = s.values(own[site]), s.values(donors[site])
        replacements[site] = {'transfer': helper.encode([a + (q / distances[site])*(b-a) for a, b in zip(x, y)]),
                              'random': helper.encode([a + (q / math.sqrt(768))*sign for a, sign in zip(x, signs)])}
        planned[site] = {kind: helper.distance(own[site], value) for kind, value in replacements[site].items()}
    helper.compare_nested(saved.get('planned_norms'), planned, 'planned norm')
    helper.compare_nested(saved.get('donor_scales'), {k:q/distances[k] for k in ids}, 'donor scale')
    tolerance = min(max(1e-5, 1e-5*q), .01*q)
    s.close(saved.get('tolerance'), tolerance, 'dose tolerance')
    s.require(saved['tolerance'] == min(max(1e-5,1e-5*rq),.01*rq), 'reported tolerance')
    def mismatch(q_, tol, n, deliveries):
        reference = deliveries['animal']['transfer']
        for site in ids:
            for x in deliveries[site].values():
                if x <= 0 or abs(x-q_) > tol or x > .2*n[site] or abs(x-reference) > .01*reference:
                    return site+'-rounded-delivery'
        return None
    why = mismatch(q, tolerance, norms, planned)
    saved_why = mismatch(rq, saved['tolerance'], saved['receiver_norms'], saved['planned_norms'])
    s.require(why == saved_why, 'reported dose boundary')
    if why:
        s.require(saved['status'] == 'dose-unmatchable' and saved['reasons'] == [why], 'dose unmatchable')
        return 'dose-unmatchable', {}, norms
    limited = any(q/norms[k] < .02 for k in ids)
    s.require(limited == any(rq/saved['receiver_norms'][k] < .02 for k in ids), 'reported limited-dose boundary')
    status = 'limited-dose' if limited else 'matchable'
    s.require(saved['status'] == status and saved['reasons'] == [], 'dose status')
    return status, replacements, norms


def log_group(raw, category):
    z = s.values(raw)
    s.require(len(z) == 1000 and category in (17, 18), 'logit shape or category')
    group = z[281:286] if category == 17 else z[151:269]
    gm, am = max(group), max(z)
    return ((gm-am) + math.log(math.fsum(math.exp(x-gm) for x in group))
            - math.log(math.fsum(math.exp(x-am) for x in z)))


def record(records, label, path=None, selected=None, action='capture'):
    row, tensors = records.take(label, path, selected, action)
    shapes = {'logits': [1, 1000]}
    if path is None:
        shapes.update(early=s.STATE_SHAPE, late=s.STATE_SHAPE)
    else:
        shapes.update(before_all=s.STATE_SHAPE, after_all=s.STATE_SHAPE)
        if selected is not None:
            shapes.update({f'{name}_{i}': [192] for i in range(4) for name in ('before', 'after')})
        if action == 'patch':
            shapes['requested'] = s.STATE_SHAPE if selected is None else [4, 192]
    s.expect_shapes(row, tensors, shapes)
    s.require(type(row['metadata'].get('capture_bytes')) is int and
              row['metadata']['capture_bytes'] == sum(len(v) for k,v in tensors.items() if k not in ('logits','requested'))
              and type(row['metadata'].get('source_bytes')) is int and
              row['metadata']['source_bytes'] == len(tensors.get('requested', b'')), 'metadata byte counts')
    for value in tensors.values():
        s.values(value)
    return row, tensors


def patch(records, label, path, selected, action, before, replacement, expected_logits, reference):
    row, data = record(records, label, path, selected, action)
    s.require(data['before_all'] == before, 'patch pre-state')
    if action == 'patch':
        s.require(data['requested'] == replacement, 'requested patch bits')
    if selected is None:
        s.require(data['after_all'] == (before if action == 'null' else replacement), 'full landing')
    else:
        expected = helper.block(before, selected) if action == 'null' else replacement
        altered = bytearray(before)
        for i, token in enumerate(selected):
            lo, hi = token*TOKEN_BYTES, (token+1)*TOKEN_BYTES
            delivered = expected[i*TOKEN_BYTES:(i+1)*TOKEN_BYTES]
            s.require(data[f'before_{i}'] == before[lo:hi] and data[f'after_{i}'] == delivered,
                      'token witness')
            altered[lo:hi] = delivered
        s.require(data['after_all'] == altered, 'patch landing or untouched tokens')
    if expected_logits is not None:
        s.require(data['logits'] == expected_logits, 'control logits')
    score, _ = s.checked_score(row, data, reference)
    return score, data


def compare_condition(saved, score, clean_logits, changed_logits, category, baseline_logp):
    s.check_score(saved, score)
    effect = helper.distribution(clean_logits, changed_logits)
    helper.compare_nested({k:saved.get(k) for k in effect}, effect, 'distribution')
    s.require(0 <= saved['tv'] <= 1 and saved['kl_clean_to_patched'] >= 0
              and type(saved['top1_changed']) is bool, 'distribution values')
    logp = log_group(changed_logits, category)
    drop = baseline_logp-logp
    s.close(saved.get('correct_group_log_probability'), logp, 'group log probability')
    s.close(saved.get('drop'), drop, 'group log probability drop')
    return drop


def decision(comparisons):
    return comparisons['occlusion_contrast'] >= .05 and comparisons['transfer_contrast'] >= .025 and \
           comparisons['transfer_contrast'] - max(abs(comparisons['animal_random_drop']),
                                                    abs(comparisons['background_random_drop'])) >= .025


def aggregate(cases):
    evals = [(row['category_id'], row['comparisons']['positive']) for row in cases
             if row['dose_status'] == 'matchable']
    s.require(all(type(cat) is int and cat in (17, 18) and type(positive) is bool
                  for cat, positive in evals), 'aggregate inputs')
    n, positive = len(evals), sum(value for _, value in evals)
    return {'status': 'inconclusive' if n < 4 or {cat for cat, _ in evals} != {17, 18} else
                      ('positive' if positive * 4 >= n * 3 else 'negative'),
            'evaluable': n, 'positive': positive,
            'cats': sum(cat == 17 for cat, _ in evals), 'dogs': sum(cat == 18 for cat, _ in evals)}


def validate_reported_delivery(condition):
    fraction, per_token = condition.get('realized_over_receiver_norm'), condition.get('token_doses')
    s.require(type(fraction) in (int, float) and math.isfinite(fraction) and fraction > 0 and
              type(per_token) is list and len(per_token) == 4 and
              all(type(value) in (int, float) and math.isfinite(value) and value >= 0 for value in per_token),
              'reported dose fraction or per-token norm differs')


def forward_count(terminal):
    count, submissions = terminal.get('saved_forwards'), terminal.get('submissions')
    s.require(type(count) is int and 0 <= count <= 144 and type(submissions) is int and submissions == count,
              'forward count')
    return count


def source_revision(start, terminal):
    source = start.get('source')
    s.require(type(source) is dict and type(source.get('revision')) is str and
              re.fullmatch('[0-9a-f]{40}', source['revision']) is not None and
              type(terminal.get('source_revision')) is str and terminal['source_revision'] == source['revision'],
              'source revision identity')
    return source['revision']


def case_replay(records, data, image, saved, expected_logits, synthetic):
    ident, category = image['image_id'], image['category_id']
    geom = image['occlusion_geometry']
    s.require(geom == geometry(image) and saved.get('image_id') == ident and saved.get('category_id') == category
              and s.typed_equal(saved.get('geometry'), geom), 'case identity or geometry')
    check_pixels(data, image, saved, synthetic)
    prefix = f'case-{ident}:'
    row, clean = record(records, prefix+'clean')
    s.require(clean['logits'] == expected_logits, 'screen-to-clean logits')
    baseline, reference = s.checked_score(row, clean)
    s.check_score(saved['baseline'], baseline)
    base_logp = log_group(clean['logits'], category)
    s.close(saved['baseline_log_probability'], base_logp, 'baseline group log probability')
    conditions, drops, masked = saved['conditions'], {}, {}
    for site in ('animal', 'background'):
        row, z = record(records, prefix+site+'_mask')
        score, _ = s.checked_score(row, z, reference)
        drops[site+'_mask'] = compare_condition(conditions[site+'_mask'], score, clean['logits'], z['logits'], category, base_logp)
        masked[site] = z
    status, replacements, norms = dose_plan(clean['early'], masked['animal']['early'], masked['background']['early'],
                                            image, saved['dose'])
    row, repeat = record(records, prefix+'repeat')
    s.require(all(repeat[k] == clean[k] for k in ('logits','early','late')), 'clean repeat')
    score, _ = s.checked_score(row, repeat, reference)
    drops['repeat'] = compare_condition(conditions['repeat'], score, clean['logits'], repeat['logits'], category, base_logp)
    plans = []
    for site in ('animal','background'):
        ids = geom[site]['token_ids']
        plans.extend([(site+'_null', s.EARLY, ids, 'null', clean['early'], None, clean['logits']),
                      (site+'_self', s.EARLY, ids, 'patch', clean['early'], helper.block(clean['early'], ids), clean['logits'])])
    plans.append(('full_self', s.EARLY, None, 'patch', clean['early'], clean['early'], clean['logits']))
    for site in ('animal','background'):
        plans.append((site+'_full', s.EARLY, None, 'patch', clean['early'], masked[site]['early'], masked[site]['logits']))
    if status in ('matchable','limited-dose'):
        for kind in ('transfer','random'):
            for site in ('animal','background'):
                plans.append((site+'_'+kind, s.EARLY, geom[site]['token_ids'], 'patch', clean['early'],
                              replacements[site][kind], None))
    for site in ('animal','background'):
        ids = geom[site]['token_ids']
        plans.append((site+'_final', s.LATE, ids, 'patch', clean['late'], helper.block(masked[site]['late'], ids), clean['logits']))
    actual = {}
    for name,path,ids,action,before,replacement,expected in plans:
        score,z = patch(records, prefix+name, path, ids, action, before, replacement, expected, reference)
        drops[name] = compare_condition(conditions[name], score, clean['logits'], z['logits'], category, base_logp)
        if name.endswith(('_transfer','_random')):
            site = name.split('_',1)[0]
            pre,post = helper.block(z['before_all'],ids),helper.block(z['after_all'],ids)
            actual[name] = helper.distance(pre,post)
            n = helper.distance(pre,bytes(len(pre)))
            c = conditions[name]
            validate_reported_delivery(c)
            s.close(c.get('actual_dose'), actual[name], 'actual dose')
            s.close(c.get('receiver_norm'), n, 'actual receiver norm')
            s.close(c.get('realized_over_receiver_norm'), actual[name]/n, 'realized relative dose')
            helper.compare_nested(c.get('token_doses'),
                                  [helper.distance(pre[i*TOKEN_BYTES:(i+1)*TOKEN_BYTES],
                                                   post[i*TOKEN_BYTES:(i+1)*TOKEN_BYTES]) for i in range(4)],
                                  'per-token dose')
            s.require(actual[name] > 0 and abs(actual[name]-saved['dose']['q']) <= saved['dose']['tolerance']
                      and actual[name] <= .2*n, 'actual dose bound')
            if name != 'animal_transfer':
                s.require(abs(actual[name]-actual['animal_transfer']) <= .01*actual['animal_transfer'], 'actual dose match')
            s.require(c['actual_dose'] > 0 and abs(c['actual_dose']-saved['dose']['q']) <= saved['dose']['tolerance']
                      and c['receiver_norm'] > 0 and c['actual_dose'] <= .2*c['receiver_norm'], 'reported actual dose bound')
            if name != 'animal_transfer':
                ref = conditions['animal_transfer']['actual_dose']
                s.require(abs(c['actual_dose']-ref) <= .01*ref, 'reported actual dose match')
    row, end = record(records, prefix+'post_clean')
    s.require(all(end[k] == clean[k] for k in ('logits','early','late')), 'post-clean repeat')
    score, _ = s.checked_score(row, end, reference)
    drops['post_clean'] = compare_condition(conditions['post_clean'], score, clean['logits'], end['logits'], category, base_logp)
    s.require(set(conditions) == set(drops), 'condition inventory')
    comparison = {'occlusion_contrast': drops['animal_mask']-drops['background_mask']}
    reported = {'occlusion_contrast': conditions['animal_mask']['drop']-conditions['background_mask']['drop']}
    if status in ('matchable','limited-dose'):
        for dest,a,b in (('transfer_contrast','animal_transfer','background_transfer'),
                         ('random_contrast','animal_random','background_random')):
            comparison[dest], reported[dest] = drops[a]-drops[b], conditions[a]['drop']-conditions[b]['drop']
        for dest in ('animal_random_drop','background_random_drop'):
            name=dest.replace('_drop','');comparison[dest],reported[dest]=drops[name],conditions[name]['drop']
        comparison['positive'], reported['positive'] = decision(comparison), decision(reported)
        s.require(comparison['positive'] == reported['positive'], 'reported decision boundary')
    helper.compare_nested(saved['comparisons'], comparison, 'comparison')
    for name,value in reported.items():
        s.require(s.typed_equal(saved['comparisons'].get(name),value), 'reported comparison arithmetic')
    s.require(s.typed_equal(saved['comparisons'].get('positive'), comparison.get('positive')), 'positive flag')
    return {'image_id': ident, 'category_id': category, 'dose_status': status, 'comparisons': comparison}


def audit(manifest_path, data, *, synthetic=False, screen_data=None,
          prior_manifest=None, prior_screen=None, prior_archive=None):
    s.require_nearest_rounding()
    raw, manifest = s.read_json(manifest_path)
    if synthetic:
        s.require(manifest.get('fabricated') is True, 'synthetic manifest marker')
    else:
        s.require(s.sha(raw) == MANIFEST_SHA, 'fixed manifest hash')
    start_raw, start = s.read_json(data/'started.json')
    terminal_raw, terminal = s.read_json(data/'terminal.json')
    mode = start.get('mode')
    source_revision(start, terminal)
    s.require(mode in ('discovery','evaluation') and start.get('schema') == 'vision-occlusion-v1-start'
              and terminal.get('schema') == 'vision-occlusion-v1-terminal' and terminal.get('mode') == mode
              and terminal.get('status') == 'complete' and start.get('manifest_sha256') == s.sha(raw)
              and terminal.get('manifest_sha256') == s.sha(raw) and start.get('runtime') == terminal.get('runtime')
              and start.get('model_state_sha256') == terminal.get('model_state_sha256_before_after'), 'phase identity')
    if not synthetic:
        s.require(start.get('model_state_sha256') == s.MODEL_STATE, 'fixed model-state claim')
    if mode == 'evaluation':
        s.require(screen_data is not None, 'evaluation requires saved screen')
        images, expected = screen_inputs(manifest, s.sha(raw), screen_data)
        screen_result_sha256 = s.sha(s.bounded_read(screen_data/'screen-result.json', 4_000_000))
        prior_archive_sha256 = None
    else:
        s.require(not synthetic and all(x is not None for x in (prior_manifest,prior_screen,prior_archive)),
                  'discovery requires fixed prior public inputs')
        images, expected = discovery_inputs(prior_manifest, prior_screen, prior_archive)
        screen_result_sha256, prior_archive_sha256 = V6_SCREEN_SHA, V6_ARCHIVE_SHA
    ids = [x['image_id'] for x in images]
    s.require(start.get('selected_ids') == ids and type(terminal.get('selected')) is int
              and terminal['selected'] == len(ids) and [x.get('image_id') for x in terminal.get('cases',[])] == ids,
              'selected image identity')
    count = forward_count(terminal)
    expected_files = {'started.json','terminal.json'} | {
        f'forward-{n:03d}.{ext}' for n in range(1,count+1) for ext in ('json','bin')}
    for ident in ids:
        expected_files.add(f'case-{ident}.json')
        expected_files.update(f'input-{ident}-{name}.bin' for name in ('clean','animal','background'))
    s.require({p.name for p in data.iterdir()} == expected_files, 'intervention file inventory')
    records = s.Records(data, count)
    cases = []
    for image, row in zip(images,terminal['cases']):
        _, per_case = s.read_json(data/f"case-{image['image_id']}.json")
        s.require(s.typed_equal(per_case,row), 'case terminal mismatch')
        cases.append(case_replay(records, data, image, row, expected[image['image_id']], synthetic))
    s.require(records.next == count+1, 'unused or missing forward')
    agg = aggregate(cases)
    s.require(s.typed_equal(terminal.get('aggregate'),agg), 'aggregate decision')
    s.require_nearest_rounding()
    return {'manifest_sha256':s.sha(raw), 'phase_start_sha256':s.sha(start_raw),
            'phase_terminal_sha256':s.sha(terminal_raw), 'screen_result_sha256':screen_result_sha256,
            'prior_screen_archive_sha256':prior_archive_sha256,
            'mode':mode,'selected':ids,'forwards':count,'aggregate':agg,
            'cases':cases,'forward_hashes':records.hashes}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('manifest','data','screen-data','prior-manifest','prior-screen','prior-archive','report'):
        parser.add_argument('--'+name, type=Path, required=name in ('manifest','data','report'))
    parser.add_argument('--synthetic',action='store_true')
    a=parser.parse_args()
    result=audit(a.manifest,a.data,synthetic=a.synthetic,screen_data=a.screen_data,
                 prior_manifest=a.prior_manifest,prior_screen=a.prior_screen,prior_archive=a.prior_archive)
    report={'schema':'vision-occlusion-independent-intervention-audit-v1','synthetic':a.synthetic,'result':result,
            'scope':'Quiescent saved-bit and arithmetic consistency only; not execution, source, timing, process, '
                    'pretraining, causal mediation or population attestation.'}
    raw=(json.dumps(report,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
    with a.report.open('xb') as stream:
        if stream.write(raw)!=len(raw):raise OSError('short report write')
    print(json.dumps({'report_sha256':s.sha(raw),'mode':result['mode'],'forwards':result['forwards'],
                      'aggregate':result['aggregate']}))


if __name__ == '__main__':
    main()
