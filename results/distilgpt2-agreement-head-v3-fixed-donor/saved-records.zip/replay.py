"""Replay this exposed-input comparison after extracting the full bundle."""
import hashlib, json
from pathlib import Path
from audit import audit
from prior_owner import _verify_prior
root = Path(__file__).resolve().parent
raw = (root / "cases.json").read_bytes()
assert hashlib.sha256(raw).hexdigest() == "51d14d87f7a318ff94e613d3ff88dfd338a6906675a92af41899b3a027eead7b"
rows = [item["token_ids"] for item in json.loads(raw)["cases"]]
prior = _verify_prior(root / "prior")
result = audit(root / "attempt", rows, phase="exploratory", heads=(4, 8), present_ids=(318, 389), secondary_ids=(373, 547), reference_observations=prior["observations"])
print(json.dumps(result, sort_keys=True, allow_nan=False))
