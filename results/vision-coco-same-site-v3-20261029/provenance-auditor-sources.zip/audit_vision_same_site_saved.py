"""Independent saved-file and source audit of the public same-site ViT run.

No model is loaded and no forward is run. This checks saved consistency, not
execution, chronology, official dataset origin, process-tree custody or
pretraining independence; same-forward landing requires separate replay.
"""
import argparse, collections, hashlib, json, math, struct, subprocess, sys
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parent))
from audit_vision_small_dose_inputs import digest,require,parse,eq

REV='c260321cb955ae31490da639fabc23a290c3a1ce'
MANIFEST='6fc5159a57cf07a91e93c8bc38f27d3f5925877083532ce92fec828c6d777bfb'
STATE='d1bfb26b30f847366de6388385d547fc29cc3c20b330c4faad993891e165eccd'
SOURCES={'tools/run_vision_coco_same_site.py','tools/prepare_vision_coco_same_site.py',
 'looking_glass/__init__.py','looking_glass/vision_coco_cases.py','looking_glass/vision_coco_same_site_cases.py',
 'looking_glass/vision_coco_small_dose_cases.py','looking_glass/vision_coco_same_site_study.py',
 'looking_glass/vision_coco_study.py','looking_glass/intervention_plan.py','looking_glass/interventions.py',
 'looking_glass/model_ownership.py','looking_glass/cpu_study_supervision.py','looking_glass/supervisor.py',
 'looking_glass/device_lease.py','looking_glass/device_identity.py','experiments/vision_coco_spatial_v1.json',
 'experiments/vision_coco_same_site_v3.json','docs/VISION_COCO_SPATIAL_V1.md',
 'docs/VISION_COCO_SMALL_DOSE_V2.md','docs/VISION_COCO_SAME_SITE_SMALL_DOSE_V3.md',
 'docs/VISION_COCO_SAME_SITE_RUNNER_V3.md','docs/CPU_STUDY_SUPERVISION.md'}

def score(raw,config):
 require(len(raw)==4000,'logit bytes');z=[x[0] for x in struct.iter_unpack('<f',raw)]
 require(all(math.isfinite(x) for x in z),'nonfinite logits')
 off=[i for i in range(1000) if not (151<=i<=268 or 281<=i<=285)]
 def shift(x):
  m=max(x);return m,math.fsum(math.exp(y-m) for y in x)
 dm,ds=shift(z[151:269]);cm,cs=shift(z[281:286]);om,os=shift([z[i] for i in off]);tm,ts=shift(z)
 top=max(range(1000),key=lambda i:z[i]);return {'margin':(dm-cm)+math.log(ds)-math.log(cs),'dog_mass':math.exp(dm-tm)*ds/ts,
  'cat_mass':math.exp(cm-tm)*cs/ts,'off_mass':math.exp(om-tm)*os/ts,'top1_id':top,'top1_label':config['id2label'][str(top)]}

def main(args):
 root=args.run;data=root/'run/data';source=parse((root/'run/source.json').read_bytes());outer=parse((root/'outer-receipt.json').read_bytes());superv=parse((root/'run/supervisor.json').read_bytes())
 require(source['revision']==REV and set(source['sources'])==SOURCES,'source revision/inventory')
 for path,expected in source['sources'].items():
  b=subprocess.check_output(['git','--no-replace-objects','show',REV+':'+path],cwd=args.checkout)
  require(digest(b)==expected,'committed source differs '+path)
 require(type(outer['exit_code']) is int and outer['exit_code']==0 and outer['timed_out'] is False and outer['revision']==REV and outer['mode']=='study','controller receipt')
 for name in ('stdout','stderr'):require(digest((root/(name+'.txt')).read_bytes())==outer[name+'_sha256'],'outer log digest '+name)
 require((root/'stderr.txt').read_bytes()==b'','controller stderr')
 require(superv['status']=='complete' and superv['clean'] is True and type(superv['exit_code']) is int and superv['exit_code']==0 and superv['timed_out'] is False and type(superv['pid']) is int and superv['pid']>0,'owner receipt')
 traw=(data/'terminal.json').read_bytes();term=parse(traw);start=parse((data/'started.json').read_bytes());require(digest(traw)==superv['terminal_sha256'],'terminal hash')
 require(eq(start['source'],source) and eq(start['runtime'],term['runtime']),'start/source/runtime mismatch')
 require(start['schema']=='vision-coco-same-site-start-v3' and start['split']=='heldout' and start['checkpoint_preflight_only'] is False and start['synthetic_rehearsal'] is False and start['model_state_sha256']==STATE and start['manifest_sha256']==MANIFEST,'start identity')
 require(term['schema']=='vision-coco-same-site-terminal-v3' and term['status']=='complete' and term['split']=='heldout' and term['source_revision']==REV and term['manifest_sha256']==term['case_sha256']==MANIFEST and term['model_state_sha256_before_after']==STATE and term['checkpoint_preflight_only'] is False and term['synthetic_rehearsal'] is False,'terminal identity')
 runtime=start['runtime'];require(runtime['device']=='cpu' and runtime['cuda_visible_devices']=='' and runtime['cuda_initialized'] is False and type(runtime['threads']) is int and runtime['threads']==1 and type(runtime['interop_threads']) is int and runtime['interop_threads']==1 and runtime['deterministic_algorithms'] is True and runtime['denormals_preserved'] is True and runtime['processor']=='ViTImageProcessor' and runtime['float32_matmul_precision']=='highest' and runtime['mkldnn_enabled'] is True,'runtime')
 for name,expected in (('python','3.11.15'),('torch','2.8.0+cu128'),('transformers','4.57.3'),('numpy','2.4.6'),('pillow','11.3.0')):require(runtime[name]==expected,'runtime '+name)
 manifest_bytes=args.manifest.read_bytes();require(digest(manifest_bytes)==MANIFEST,'manifest bytes');manifest=parse(manifest_bytes);pairs=manifest['pairs'];rows=term['pairs'];require(len(pairs)==len(rows)==8,'pair count')
 config=parse((args.assets/'config.json').read_bytes());labels=[];initials={};expected_conditions={};counts=collections.Counter()
 for p in pairs:
  for role in ('cat','dog','cat_donor','dog_donor'):
   iid=p[role]['image_id']
   if iid not in initials:labels.append(f"{p['pair_id']}:{role}:initial");initials[iid]=None
 for p,result in zip(pairs,rows):
  pid=p['pair_id'];require(result['pair_id']==pid and result['split']=='heldout','pair identity')
  require(eq(parse((data/(pid+'.json')).read_bytes()),result),'pair file mismatch')
  require(result['status'] in ('positive','negative','baseline-ineligible','dose-ineligible','dose-unmatchable'),'pair status');counts[result['status']]+=1
  for side in ('cat','dog'):
   x=result['sides'][side];require(type(x['image_id']) is int and x['image_id']==p[side]['image_id'] and type(x['same_species_donor_id']) is int and x['same_species_donor_id']==p[side+'_donor']['image_id'],'target/donor identity')
   ds=x['dose']['status'];require(ds in ('matchable','dose-ineligible','dose-unmatchable'),'dose status')
   cond=['repeat','null_inside','self_inside','full_self','full_swap','natural_inside']
   if ds=='matchable':cond+=['matched_opposite','matched_same_species','matched_random']
   cond+=['final_inside','post_clean'];require(set(x['conditions'])==set(cond),'condition inventory')
   for name in cond:
    label=f'{pid}:{side}:{name}';labels.append(label);expected_conditions[label]=x['conditions'][name]
 n=len(labels);require(type(term['submissions']) is int and type(term['saved_forwards']) is int and term['submissions']==term['saved_forwards']==n==195,'forward count')
 expected={'started.json','terminal.json'}|{p['pair_id']+'.json' for p in pairs}|{f'forward-{i:03d}.{ext}' for i in range(1,n+1) for ext in ('json','bin')}
 require({p.name for p in data.iterdir() if p.is_file()}==expected,'saved evidence inventory')
 for i,label in enumerate(labels,1):
  record=parse((data/f'forward-{i:03}.json').read_bytes());payload=(data/f'forward-{i:03}.bin').read_bytes()
  require(type(record['submission']) is int and record['submission']==i and record['label']==label and record['file']==f'forward-{i:03}.bin' and record['dtype']=='little-endian-float32' and len(payload)<=1_000_000 and digest(payload)==record['sha256'],'forward identity/hash')
  layout=record['layout'];require(type(layout) is dict and 'logits' in layout,'layout')
  spans=[]
  for item in layout.values():
   shape=item['shape'];offset=item['offset'];length=item['bytes'];require(type(shape) is list and shape and all(type(x) is int and x>0 for x in shape) and type(offset) is int and type(length) is int and length==4*math.prod(shape) and 0<=offset<=offset+length<=len(payload),'tensor bounds')
   spans.append((offset,offset+length))
  spans.sort();require(spans[0][0]==0 and spans[-1][1]==len(payload) and all(a[1]==b[0] for a,b in zip(spans,spans[1:])),'layout gaps/overlaps')
  logits=layout['logits'];require(eq(logits['shape'],[1,1000]) and logits['bytes']==4000,'logit shape')
  computed=score(payload[logits['offset']:logits['offset']+4000],config);saved=record['score']
  for k,v in computed.items():
   require((type(saved.get(k)) is type(v) and saved[k]==v) if type(v) in (int,str) else (type(saved.get(k)) is float and math.isclose(saved[k],v,rel_tol=0,abs_tol=1e-12)),'saved score '+label+' '+k)
  steps=record['metadata']['steps'];require(type(steps) is list and len(steps)>0,'missing action metadata')
  for order,event in enumerate(steps):
   require(type(event['order']) is int and event['order']==order and type(event['forward_index']) is int and event['forward_index']==0 and type(event['invocation']) is int and event['invocation']==0 and event['device']=='cpu' and event['dtype']=='torch.float32' and event['call_site_known'] is False,'action identity')
  if label.endswith(':initial'):
   pair_id,role,_=label.split(':');p=next(x for x in pairs if x['pair_id']==pair_id);initials[p[role]['image_id']]=saved
  else:
   expected_score=expected_conditions[label]
   require(all(k in expected_score and eq(expected_score[k],v) for k,v in saved.items()),'condition score mismatch '+label)
 for p,row in zip(pairs,rows):
  for side in ('cat','dog'):
   info=row['sides'][side];require(eq(info['baseline'],initials[p[side]['image_id']]) and eq(info['same_species_baseline'],initials[p[side+'_donor']['image_id']]),'baseline score mismatch')
  cat=row['sides']['cat']['baseline'];dog=row['sides']['dog']['baseline'];gap=dog['margin']-cat['margin'];reasons=[]
  if cat['margin']>=0:reasons.append('cat-relative-margin')
  if dog['margin']<=0:reasons.append('dog-relative-margin')
  if gap<1:reasons.append('gap-below-one')
  if cat['cat_mass']<.2:reasons.append('cat-mass-below-0.2')
  if dog['dog_mass']<.2:reasons.append('dog-mass-below-0.2')
  require(eq(row['baseline_eligibility'],{'eligible':not reasons,'reasons':reasons,'gap':gap}),'baseline eligibility')
 positive=counts['positive'];evaluable=positive+counts['negative'];decision='inconclusive' if evaluable<4 else ('positive' if positive*4>=evaluable*3 else 'negative')
 require(eq(term['aggregate'],{'status':decision,'selected':8,'evaluable':evaluable,'positive':positive}),'aggregate')
 if args.recheck_inputs:
  import audit_vision_same_site_v3 as input_audit
  args2=SimpleNamespace(manifest=args.manifest,prior=args.prior,assets=args.assets,pil_dir=args.pil_dir,checkout=args.selection_checkout,verify_https=False)
  result=input_audit.audit(args2);require(result['distinct_images']==19,'input recheck')
 return {'status':'saved_consistency_verified','revision':REV,'manifest_sha256':MANIFEST,'terminal_sha256':digest(traw),'supervisor_sha256':digest((root/'run/supervisor.json').read_bytes()),'outer_receipt_sha256':digest((root/'outer-receipt.json').read_bytes()),'model_state_sha256':STATE,'source_files':len(source['sources']),'forwards':n,'saved_data_files':len(expected),'initial_image_forwards':len(initials),'pair_status_counts':dict(counts),'aggregate':term['aggregate'],'input_rechecked_after_run':args.recheck_inputs,'limitations':['Saved-file consistency does not prove execution, timing or whole-process-tree cleanup.','Separate scientific replay is required for intervention landing and the full decision rule.','Third-party mirrors and fixed splits do not authenticate official origin or pretraining independence.']}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',type=Path,required=True);p.add_argument('--manifest',type=Path,required=True);p.add_argument('--assets',type=Path,required=True);p.add_argument('--checkout',type=Path,required=True);p.add_argument('--recheck-inputs',action='store_true');p.add_argument('--prior',type=Path);p.add_argument('--pil-dir',type=Path);p.add_argument('--selection-checkout',type=Path);a=p.parse_args();print(json.dumps(main(a),indent=2,sort_keys=True))
