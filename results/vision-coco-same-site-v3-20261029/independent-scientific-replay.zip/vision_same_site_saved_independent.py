"""Independent stdlib replay of bounded v3 same-site ViT/COCO evidence.

The caller supplies the frozen case manifest and a quiescent data directory.
This checks saved-byte consistency, not the authenticity of the model, input
images, source, supervision, publication timing, or execution. Synthetic-only
fixtures may use --synthetic; real evidence requires all eight fixed IDs.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import struct

STATE_SHAPE = [1, 197, 192]
STATE_BYTES = 197 * 192 * 4
TOKEN_BYTES = 192 * 4
EARLY = 'vit.encoder.layer.2'
LATE = 'vit.encoder.layer.11'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read_json(path, limit=4_000_000):
    raw = path.read_bytes()
    require(0 < len(raw) <= limit, f'invalid JSON length: {path.name}')
    def unique_pairs(items):
        value = {}
        for key, item in items:
            require(key not in value, 'duplicate JSON key')
            value[key] = item
        return value
    value = json.loads(raw, object_pairs_hook=unique_pairs,
                       parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite JSON')))
    return raw, value


def typed_equal(left, right):
    return json.dumps(left, sort_keys=True, separators=(',', ':'), allow_nan=False) == \
           json.dumps(right, sort_keys=True, separators=(',', ':'), allow_nan=False)


def close(a, b, message):
    require(type(a) in (int, float) and type(b) in (int, float) and not isinstance(a, bool)
            and not isinstance(b, bool) and math.isfinite(a) and math.isfinite(b)
            and math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-10), message)


def decode_word(word):
    exponent, fraction = (word >> 23) & 255, word & 0x7fffff
    require(exponent != 255, 'nonfinite binary32')
    mantissa = fraction if exponent == 0 else (1 << 23) | fraction
    value = math.ldexp(float(mantissa), -149 if exponent == 0 else exponent - 150)
    return -value if word & 0x80000000 else value


def values(raw):
    require(len(raw) % 4 == 0, 'unaligned binary32 payload')
    return [decode_word(word[0]) for word in struct.iter_unpack('<I', raw)]


def _shift_round_even(number, shift):
    if shift >= 0:
        return number << shift
    divisor = 1 << (-shift)
    quotient, remainder = divmod(number, divisor)
    return quotient + (2 * remainder > divisor or (2 * remainder == divisor and quotient % 2 == 1))


def round_f32(value):
    bits = struct.unpack('<Q', struct.pack('<d', value))[0]
    sign = (bits >> 32) & 0x80000000
    exponent, fraction = (bits >> 52) & 0x7ff, bits & ((1 << 52) - 1)
    require(exponent != 0x7ff, 'nonfinite planned value')
    mantissa = fraction if exponent == 0 else (1 << 52) | fraction
    if not mantissa:
        return sign
    power = -1074 if exponent == 0 else exponent - 1075
    high = mantissa.bit_length() - 1 + power
    if high < -126:
        return sign | _shift_round_even(mantissa, power + 149)
    significand = _shift_round_even(mantissa, power + 23 - high)
    if significand == (1 << 24):
        significand >>= 1
        high += 1
    require(high <= 127, 'planned binary32 overflows')
    return sign | ((high + 127) << 23) | (significand - (1 << 23))


def encode(values_):
    return b''.join(struct.pack('<I', round_f32(v)) for v in values_)


def token(state, index):
    require(len(state) == STATE_BYTES and type(index) is int and 1 <= index < 197, 'invalid state/token')
    return state[index * TOKEN_BYTES:(index + 1) * TOKEN_BYTES]


def block(state, tokens):
    require(type(tokens) is list and len(tokens) == len(set(tokens)) == 4, 'invalid token block')
    return b''.join(token(state, i) for i in tokens)


def distance(a, b):
    left, right = values(a), values(b)
    require(len(left) == len(right), 'distance shape mismatch')
    return math.sqrt(math.fsum((x - y) ** 2 for x, y in zip(left, right)))


def planned(own, donor, q, distance_):
    x, y = values(own), values(donor)
    require(len(x) == len(y) == 768 and distance_ > 0, 'invalid planned donor block')
    ratio = q / distance_
    return encode([a + ratio * (b - a) for a, b in zip(x, y)])


def random_planned(own, q, pair_id, side):
    x = values(own)
    require(len(x) == 768, 'invalid random block')
    scale = q / math.sqrt(768)
    signs = [1 if hashlib.sha256(f'vision-coco-small-dose-random-v2:{pair_id}:{side}:{i}'.encode('ascii')).digest()[0] & 1
             else -1 for i in range(768)]
    return encode([a + scale * sign for a, sign in zip(x, signs)])


def summarize(raw, reference=None):
    z = values(raw)
    require(len(z) == 1000, 'invalid logit vector')
    dog, cat = z[151:269], z[281:286]
    off = z[:151] + z[269:281] + z[286:]
    def shifted(v):
        m = max(v)
        return m, math.fsum(math.exp(x - m) for x in v)
    dm, ds = shifted(dog)
    cm, cs = shifted(cat)
    om, os = shifted(off)
    tm, ts = shifted(z)
    conditional = [math.exp(x - om) / os for x in off]
    score = {'margin': (dm - cm) + math.log(ds) - math.log(cs),
             'dog_mass': math.exp(dm - tm) * ds / ts,
             'cat_mass': math.exp(cm - tm) * cs / ts,
             'off_mass': math.exp(om - tm) * os / ts,
             'top1_id': max(range(1000), key=lambda i: z[i])}
    if reference is not None:
        require(len(reference) == len(conditional), 'off-group reference length mismatch')
        score['off_conditional_tv'] = .5 * math.fsum(abs(x - y) for x, y in zip(conditional, reference))
    return score, conditional


def check_score(stored, computed):
    for key, expected in computed.items():
        if key == 'top1_id':
            require(type(stored.get(key)) is int and stored[key] == expected, 'top-1 mismatch')
        else:
            close(stored.get(key), expected, f'score mismatch: {key}')


def metadata_expected(row, path, tokens, action):
    events = row['metadata']['steps']
    if path is None:
        desired = [('early', 'capture', EARLY, None), ('late', 'capture', LATE, None)]
    else:
        desired = [('before_all', 'capture', path, None)]
        if tokens is None:
            desired.append(('action', action, path, None))
        else:
            for i, t in enumerate(tokens):
                desired.extend([(f'before_{i}', 'capture', path, t), (f'action_{i}', action, path, t),
                                (f'after_{i}', 'capture', path, t)])
        desired.append(('after_all', 'capture', path, None))
    require(type(events) is list and len(events) == len(desired), 'metadata action count mismatch')
    for order, (event, (name, operation, module, index)) in enumerate(zip(events, desired)):
        require(event.get('name') == name and event.get('operation') == operation and
                event.get('module_path') == module and typed_equal(event.get('order'), order) and
                typed_equal(event.get('invocation'), 0) and typed_equal(event.get('forward_index'), 0) and
                typed_equal(event.get('batch_index'), 0 if index is not None else None) and
                typed_equal(event.get('token_index'), index) and typed_equal(event.get('output_shape'), STATE_SHAPE) and
                typed_equal(event.get('selected_shape'), [192] if index is not None else STATE_SHAPE) and
                event.get('dtype') == 'torch.float32' and event.get('output_selector') == [] and
                module in event.get('module_aliases', []), 'metadata action identity/shape mismatch')


class Records:
    def __init__(self, root, count):
        self.root, self.count, self.next = root, count, 1
        self.hashes = []

    def take(self, label, path=None, tokens=None, action='capture'):
        index = self.next
        require(index <= self.count, 'missing forward')
        raw_json, row = read_json(self.root / f'forward-{index:03d}.json', 200_000)
        require(typed_equal(row.get('submission'), index) and row.get('label') == label and
                row.get('file') == f'forward-{index:03d}.bin' and
                row.get('dtype') == 'little-endian-float32', 'forward order/identity mismatch')
        packed = (self.root / row['file']).read_bytes()
        require(len(packed) <= 1_000_000 and sha(packed) == row.get('sha256'), 'forward bytes/hash mismatch')
        layout = row.get('layout')
        require(type(layout) is dict, 'missing tensor layout')
        ordered = sorted(layout.items(), key=lambda item: item[1]['offset'])
        offset, tensors = 0, {}
        for name, entry in ordered:
            shape, start, size = entry.get('shape'), entry.get('offset'), entry.get('bytes')
            require(type(name) is str and type(shape) is list and all(type(x) is int and x > 0 for x in shape)
                    and type(start) is int and start == offset and type(size) is int
                    and size == 4 * math.prod(shape) and start + size <= len(packed), 'invalid tensor layout')
            tensors[name] = packed[start:start + size]
            offset += size
        require(offset == len(packed) and layout.get('logits', {}).get('shape') == [1, 1000], 'payload coverage mismatch')
        metadata_expected(row, path, tokens, action)
        self.hashes.append({'submission': index, 'json_sha256': sha(raw_json), 'binary_sha256': sha(packed)})
        self.next += 1
        return row, tensors


def expect_shapes(row, tensors, shapes):
    require(set(tensors) == set(shapes), 'unexpected saved tensor set')
    for name, shape in shapes.items():
        require(row['layout'][name]['shape'] == shape, f'tensor shape mismatch: {name}')


def checked_score(row, tensors, reference=None):
    computed, conditional = summarize(tensors['logits'], reference)
    check_score(row['score'], computed)
    return computed, conditional


def initial(records, pair_id, side):
    row, tensors = records.take(f'{pair_id}:{side}:initial')
    expect_shapes(row, tensors, {'logits': [1, 1000], 'early': STATE_SHAPE, 'late': STATE_SHAPE})
    for name in ('early', 'late'):
        require(all((word[0] >> 23) & 255 != 255 for word in struct.iter_unpack('<I', tensors[name])),
                f'nonfinite initial {name} state')
    score_, conditional = checked_score(row, tensors)
    return {'logits': tensors['logits'], 'early': tensors['early'], 'late': tensors['late'],
            'score': score_, 'conditional': conditional}


def clean_forward(records, pair_id, side, name, baseline):
    row, tensors = records.take(f'{pair_id}:{side}:{name}')
    expect_shapes(row, tensors, {'logits': [1, 1000], 'early': STATE_SHAPE, 'late': STATE_SHAPE})
    require(all(tensors[k] == baseline[k] for k in ('logits', 'early', 'late')), f'{name} clean mismatch')
    score_, _ = checked_score(row, tensors, baseline['conditional'])
    return score_


def intervention(records, pair_id, side, name, path, tokens, before_state, expected_replacement,
                 baseline, expected_logits=None):
    action = 'null' if name.startswith('null_') else 'patch'
    row, tensors = records.take(f'{pair_id}:{side}:{name}', path, tokens, action)
    shapes = {'logits': [1, 1000], 'before_all': STATE_SHAPE, 'after_all': STATE_SHAPE}
    if tokens is not None:
        shapes.update({f'{kind}_{i}': [192] for i in range(4) for kind in ('before', 'after')})
    if action == 'patch':
        shapes['requested'] = STATE_SHAPE if tokens is None else [4, 192]
    expect_shapes(row, tensors, shapes)
    require(tensors['before_all'] == before_state, 'same-forward pre-state mismatch')
    if action == 'patch':
        require(tensors['requested'] == expected_replacement, f'planned replacement mismatch: {name}')
    if tokens is None:
        require(tensors['after_all'] == (before_state if action == 'null' else expected_replacement),
                'full-state landing mismatch')
    else:
        replacement = block(before_state, tokens) if action == 'null' else expected_replacement
        require(len(replacement) == 4 * TOKEN_BYTES, 'replacement length mismatch')
        expected_after = bytearray(before_state)
        for i, index in enumerate(tokens):
            prior = token(before_state, index)
            landed = replacement[i * TOKEN_BYTES:(i + 1) * TOKEN_BYTES]
            require(tensors[f'before_{i}'] == prior and tensors[f'after_{i}'] == landed,
                    'per-token capture/landing mismatch')
            expected_after[index * TOKEN_BYTES:(index + 1) * TOKEN_BYTES] = landed
        require(tensors['after_all'] == expected_after, 'untouched token or landing mismatch')
    if expected_logits is not None:
        require(tensors['logits'] == expected_logits, f'{name} logit control mismatch')
    score_, _ = checked_score(row, tensors, baseline['conditional'])
    return score_, tensors


def status_for(cat, dog):
    gap = dog['margin'] - cat['margin']
    reasons = []
    if cat['margin'] >= 0: reasons.append('cat-relative-margin')
    if dog['margin'] <= 0: reasons.append('dog-relative-margin')
    if gap < 1: reasons.append('gap-below-one')
    if cat['cat_mass'] < .2: reasons.append('cat-mass-below-0.2')
    if dog['dog_mass'] < .2: reasons.append('dog-mass-below-0.2')
    return {'eligible': not reasons, 'reasons': reasons, 'gap': gap}


def prepare(own, opposite, same, ids, pair_id, side):
    receiver, other, donor = block(own, ids), block(opposite, ids), block(same, ids)
    receiver_norm = distance(receiver, bytes(len(receiver)))
    opposite_distance, same_distance = distance(receiver, other), distance(receiver, donor)
    result = {'receiver_norm': receiver_norm, 'opposite_distance': opposite_distance,
              'same_species_distance': same_distance, 'status': 'dose-ineligible', 'reasons': []}
    for name, value in (('receiver-norm', receiver_norm), ('opposite-distance', opposite_distance),
                        ('same-species-distance', same_distance)):
        if value <= 1e-6: result['reasons'].append(name)
    if result['reasons']: return result, {}
    q = min(.099 * receiver_norm, opposite_distance, same_distance)
    result['q'] = q
    if q <= 1e-6:
        result['reasons'].append('q')
        return result, {}
    requested = {'opposite': planned(receiver, other, q, opposite_distance),
                 'same_species': planned(receiver, donor, q, same_distance),
                 'random': random_planned(receiver, q, pair_id, side)}
    norms = {name: distance(value, receiver) for name, value in requested.items()}
    tolerance = min(max(1e-5, 1e-5*q), .01*q)
    result.update(tolerance=tolerance, planned_norms=norms,
                  donor_scales={'opposite':q/opposite_distance, 'same_species':q/same_distance})
    first = norms['opposite']
    if any(norm <= 0 or abs(norm-q) > tolerance or abs(norm-first) > .01*first
           or norm > .1*receiver_norm for norm in norms.values()):
        result.update(status='dose-unmatchable', reasons=['rounded-delivery'])
    else:
        result['status'] = 'matchable'
    return result, requested


def compare_dose(stored, expected):
    require(type(stored) is dict and set(stored) == set(expected), 'dose fields differ')
    for key, value in expected.items():
        actual = stored[key]
        if type(value) is dict:
            require(type(actual) is dict and set(actual) == set(value), 'dose nested fields differ')
            for name in value: close(actual[name], value[name], f'dose {key}/{name} differs')
        elif type(value) in (str, list):
            require(typed_equal(actual, value), f'dose {key} differs')
        else:
            close(actual, value, f'dose {key} differs')


def classify(base, doses, movements):
    if not base['eligible']: return 'baseline-ineligible'
    if any(value != 'matchable' for value in doses.values()):
        return 'dose-ineligible' if 'dose-ineligible' in doses.values() else 'dose-unmatchable'
    passed = all(movements[side]['opposite'] >= .05 and
                 movements[side]['opposite'] >=
                 max(abs(movements[side]['same_species']), abs(movements[side]['random'])) + .025
                 for side in ('cat', 'dog'))
    return 'positive' if passed else 'negative'


def aggregate(pairs):
    valid = {'positive', 'negative', 'baseline-ineligible', 'dose-ineligible', 'dose-unmatchable'}
    require(len(pairs) == 8 and {p['pair_id'] for p in pairs} == {f'pair-{i:02d}' for i in range(8)}
            and all(p['status'] in valid for p in pairs), 'invalid held-out pair inventory')
    qualified = [p for p in pairs if p['status'] in ('positive', 'negative')]
    positives = sum(p['status'] == 'positive' for p in qualified)
    status = ('inconclusive' if len(qualified) < 4 else
              'positive' if positives*4 >= len(qualified)*3 else 'negative')
    return {'status': status, 'selected': 8, 'evaluable': len(qualified), 'positive': positives}


def audit(manifest_path, data, synthetic=False):
    manifest_raw, manifest = read_json(manifest_path, 5_000_000)
    terminal_raw, terminal = read_json(data / 'terminal.json', 5_000_000)
    require(terminal.get('schema') == 'vision-coco-same-site-terminal-v3' and
            terminal.get('status') == 'complete' and
            terminal.get('checkpoint_preflight_only') is False and not (data / 'failure.json').exists(),
            'incomplete terminal')
    pairs = manifest['pairs']
    if synthetic:
        require(manifest.get('schema') == 'fabricated-only', 'synthetic manifest required')
        require(terminal.get('synthetic_rehearsal') is True, 'synthetic terminal required')
    else:
        require(manifest.get('schema') == 'vision-coco-vit-same-site-cases-v3', 'unexpected manifest schema')
        require(terminal.get('synthetic_rehearsal') is False, 'real terminal required')
        require(terminal.get('split') == 'heldout' and terminal.get('manifest_sha256') == sha(manifest_raw) and
                terminal.get('case_sha256') == sha(manifest_raw), 'manifest hash or split differs')
        _, started = read_json(data / 'started.json', 5_000_000)
        require(started.get('schema') == 'vision-coco-same-site-start-v3' and
                started.get('split') == 'heldout' and started.get('synthetic_rehearsal') is False and
                started.get('checkpoint_preflight_only') is False and
                started.get('manifest_sha256') == terminal['manifest_sha256'] and
                started.get('source', {}).get('revision') == terminal.get('source_revision') and
                started.get('model_state_sha256') == terminal.get('model_state_sha256_before_after'),
                'start/terminal identity differs')
        require([p['pair_id'] for p in pairs] == [f'pair-{i:02d}' for i in range(8)] and
                all(p.get('split') == 'heldout' for p in pairs), 'fixed held-out cases differ')
    ids = [p['pair_id'] for p in pairs]
    require(ids and len(ids) == len(set(ids)), 'pair IDs missing or repeated')
    target_ids = [p[s]['image_id'] for p in pairs for s in ('cat','dog')]
    donor_ids = [p[s+'_donor']['image_id'] for p in pairs for s in ('cat','dog')]
    require(len(target_ids) == len(set(target_ids)) and not set(target_ids).intersection(donor_ids),
            'target/donor identity differs')
    for pair in pairs:
        require(type(pair['box_tokens']) is list and len(pair['box_tokens']) == len(set(pair['box_tokens'])) == 4
                and all(type(t) is int and 1 <= t < 197 for t in pair['box_tokens']), 'invalid selected sites')
    count = terminal['submissions']
    require(type(count) is int and 0 < count <= 30 * len(pairs) and
            terminal.get('saved_forwards', count if synthetic else None) == count, 'forward count differs')
    files = {f'forward-{i:03d}.{ext}' for i in range(1,count+1) for ext in ('json','bin')}
    require({p.name for p in data.glob('forward-*')} == files, 'forward inventory differs')
    records = Records(data, count)
    clean = {}
    for pair in pairs:
        for role in ('cat','dog','cat_donor','dog_donor'):
            image_id = pair[role]['image_id']
            if image_id not in clean: clean[image_id] = initial(records, pair['pair_id'], role)
    terminal_pairs = terminal['pairs']
    require(type(terminal_pairs) is list and len(terminal_pairs) == len(pairs), 'terminal pair count differs')
    reported = {row['pair_id']:row for row in terminal_pairs}
    require(set(reported) == set(ids), 'terminal pair IDs differ')
    summaries, pair_hashes = [], {}
    for pair in pairs:
        pair_id, selected = pair['pair_id'], pair['box_tokens']
        raw, saved = read_json(data / f'{pair_id}.json', 1_000_000)
        pair_hashes[pair_id] = sha(raw)
        require(typed_equal(saved, reported[pair_id]) and saved.get('split') == pair['split'],
                'pair/terminal record differs')
        base = status_for(clean[pair['cat']['image_id']]['score'],clean[pair['dog']['image_id']]['score'])
        require(saved['baseline_eligibility']['eligible'] is base['eligible'] and
                saved['baseline_eligibility']['reasons'] == base['reasons'], 'baseline gate differs')
        close(saved['baseline_eligibility']['gap'], base['gap'], 'baseline gap differs')
        dose_records, side_movements = {}, {}
        for side, opposite_side in (('cat','dog'),('dog','cat')):
            own = clean[pair[side]['image_id']]
            other = clean[pair[opposite_side]['image_id']]
            same = clean[pair[side+'_donor']['image_id']]
            dose, requested = prepare(own['early'],other['early'],same['early'],selected,pair_id,side)
            dose_records[side] = dose
            info = saved['sides'][side]
            require(info['image_id'] == pair[side]['image_id'] and
                    info['same_species_donor_id'] == pair[side+'_donor']['image_id'], 'side identity differs')
            check_score(info['baseline'],own['score'])
            check_score(info['same_species_baseline'],same['score'])
            compare_dose(info['dose'],dose)
            conditions = info['conditions']
            repeat = clean_forward(records,pair_id,side,'repeat',own)
            check_score(conditions['repeat'],repeat)
            plans = [('null_inside', EARLY, selected, None, own['logits']),
                     ('self_inside', EARLY, selected, block(own['early'],selected), own['logits']),
                     ('full_self', EARLY, None, own['early'], own['logits']),
                     ('full_swap', EARLY, None, other['early'], other['logits']),
                     ('natural_inside', EARLY, selected, block(other['early'],selected), None)]
            if dose['status'] == 'matchable':
                for name in ('opposite','same_species','random'):
                    plans.append(('matched_'+name,EARLY,selected,requested[name],None))
            plans.append(('final_inside',LATE,selected,block(other['late'],selected),own['logits']))
            require(set(conditions) == {'repeat','post_clean'} | {p[0] for p in plans}, 'conditions differ')
            moves = {}
            first_norm = None
            for name, path, tokens_, replacement, expected_logits in plans:
                state = own['early'] if path == EARLY else own['late']
                score_, tensors = intervention(records,pair_id,side,name,path,tokens_,state,replacement,own,expected_logits)
                saved_condition = conditions[name]
                check_score(saved_condition,score_)
                change = score_['margin']-own['score']['margin']
                oriented = change * (1 if side == 'cat' else -1)
                close(saved_condition.get('raw_margin_change'),change,'raw change differs')
                close(saved_condition.get('annotation_oriented_change'),oriented,'oriented change differs')
                if name.startswith('matched_'):
                    pre, post = block(tensors['before_all'],tokens_), block(tensors['after_all'],tokens_)
                    norm, receiver_norm = distance(pre,post), distance(pre,bytes(len(pre)))
                    require(norm > 0 and abs(norm-dose['q']) <= dose['tolerance'] and
                            receiver_norm > 0 and norm <= .1*receiver_norm, 'actual matched dose differs')
                    if name == 'matched_opposite': first_norm = norm
                    else: require(first_norm is not None and abs(norm-first_norm) <= .01*first_norm,
                                  'matched same-side doses differ')
                    close(saved_condition.get('actual_dose'),norm,'actual dose field differs')
                    close(saved_condition.get('receiver_norm'),receiver_norm,'receiver norm differs')
                    close(saved_condition.get('realized_over_receiver_norm'),norm/receiver_norm,'relative dose differs')
                    per = [distance(pre[i*TOKEN_BYTES:(i+1)*TOKEN_BYTES],post[i*TOKEN_BYTES:(i+1)*TOKEN_BYTES]) for i in range(4)]
                    require(type(saved_condition.get('token_doses')) is list and len(saved_condition['token_doses']) == 4,
                            'token dose inventory differs')
                    for got,want in zip(saved_condition['token_doses'],per): close(got,want,'token dose differs')
                    moves[name.removeprefix('matched_')] = oriented
            post = clean_forward(records,pair_id,side,'post_clean',own)
            check_score(conditions['post_clean'],post)
            side_movements[side] = moves
        dose_status = {side:dose_records[side]['status'] for side in ('cat','dog')}
        require(saved['dose_matchability'] == dose_status, 'dose matchability differs')
        movements = side_movements if all(v == 'matchable' for v in dose_status.values()) else None
        expected_status = classify(base,dose_status,movements)
        require(saved['status'] == expected_status, 'pair status differs')
        if movements is None:
            require(saved.get('descriptive_movements') is None, 'unexpected descriptive movements')
        else:
            for side in ('cat','dog'):
                for name in ('opposite','same_species','random'):
                    close(saved['descriptive_movements'][side][name],movements[side][name], 'descriptive movement differs')
        summaries.append({'pair_id':pair_id,'status':expected_status,'baseline_eligibility':base,
                          'dose_statuses':dose_status,'descriptive_movements':movements})
    require(records.next == count+1, 'unexpected trailing forward records')
    result = None if synthetic else aggregate(summaries)
    require(terminal.get('aggregate') == result, 'aggregate differs')
    return {'schema':'independent-vision-same-site-audit-v1',
            'scope':'Saved logits, selected activation bytes, dose/control and decision consistency only; '
                    'not source, input-image, execution, supervision, timing or training-history attestation.',
            'synthetic':synthetic, 'manifest_sha256':sha(manifest_raw), 'terminal_sha256':sha(terminal_raw),
            'forwards':count, 'forward_hashes':records.hashes, 'pair_hashes':pair_hashes,
            'pairs':summaries, 'aggregate':result}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--data', type=Path, required=True)
    parser.add_argument('--synthetic', action='store_true')
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    report = audit(args.manifest,args.data,args.synthetic)
    raw = (json.dumps(report,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
    with args.report.open('xb') as stream:
        if stream.write(raw) != len(raw): raise OSError('short report write')
    print(json.dumps({'report_sha256':sha(raw),'forwards':report['forwards'],'aggregate':report['aggregate']}))


if __name__ == '__main__':
    main()


