"""Replay a closed CLS/occlusion evaluation from quiescent saved bytes.

The separately published screen is independently reconstructed first. These
checks do not authenticate execution, source/model identity, chronology,
preprocessing, process cleanup, pretraining independence, or generalization.
"""

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import zipfile


SCREEN_HELPER_SHA = 'dfd2a570480144831ff0e0c8bd9b3d17cc81a5cd08c160fb3f786ed8f77ebfd4'
CASE_HELPER_SHA = 'bb6a49546f52d34adbd27d3436446664cd42feaa94ae717514888d1c62f30089'
SCREEN_COMMIT = '5a1df2baf7929d8c03167ff142a85c2d0c8891ef'
SCREEN_RESULT_SHA = '49fa38a43ad78035c90f8cfcf6bc7558002cdc94c16fc443350bc46962d7b4a8'
SCREEN_ARCHIVE_SHA = '699eeb5f401bd78189263e0a4e77def091b440cc8843631bcf4bbd5ea967382e'


def load_helper(filename, expected, name):
    path = Path(__file__).with_name(filename)
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise ValueError('fixed replay helper differs: ' + filename)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


screen_replay = load_helper('vision_cls_occlusion_screen_independent.py', SCREEN_HELPER_SHA, 'fixed_cls_screen')
case_replay = load_helper('vision_cls_occlusion_intervention_independent.py', CASE_HELPER_SHA, 'fixed_cls_cases')
s = case_replay.s
# Make the strict duplicate-key/finite-number parser apply inside Records too.
s.read_json = screen_replay.read_json


def require(condition, message):
    if not condition:
        raise ValueError(message)


def checked_readback(index_path, readback_path, archive_path, expected_commit, archive_sha):
    """Rebuild part and member hashes; the public-readback record is cooperative."""
    index_raw, index = screen_replay.read_json(index_path, 5_000_000)
    readback_raw, readback = screen_replay.read_json(readback_path, 5_000_000)
    path = Path(archive_path)
    require(type(index) is dict and index.get('schema') == 'vision-cls-occlusion-v1-screen-archive-index' and
            type(index.get('archive_bytes')) is int and 0 < index['archive_bytes'] <= 150_000_000 and
            path.is_file() and path.stat().st_size == index['archive_bytes'] and
            index.get('archive_sha256') == archive_sha, 'screen index identity differs')
    parts = index.get('parts')
    require(type(parts) is list and 1 <= len(parts) <= 192 and type(readback) is dict and
            readback.get('schema') == 'vision-cls-occlusion-v1-screen-public-readback' and
            readback.get('status') == 'pass' and readback.get('public_commit') == expected_commit and
            readback.get('index_sha256') == s.sha(index_raw) and readback.get('archive_sha256') == archive_sha and
            type(readback.get('parts')) is list and len(readback['parts']) == len(parts),
            'screen public readback differs')
    digest, total = hashlib.sha256(), 0
    with path.open('rb') as stream:
        for number, part in enumerate(parts):
            require(type(part) is dict and part.get('file') == f'screen-evidence.part-{number:03d}' and
                    type(part.get('bytes')) is int and 0 < part['bytes'] <= 10_000_000,
                    'screen part identity differs')
            chunk = stream.read(part['bytes'])
            require(len(chunk) == part['bytes'] and s.sha(chunk) == part.get('sha256'), 'screen part bytes differ')
            blob = hashlib.sha1(b'blob ' + str(len(chunk)).encode() + b'\0' + chunk).hexdigest()
            require(s.typed_equal(readback['parts'][number], {**part, 'git_blob': blob}),
                    'screen public part digest differs')
            digest.update(chunk)
            total += len(chunk)
        require(not stream.read(1) and total == index['archive_bytes'] and digest.hexdigest() == archive_sha,
                'screen archive extent differs')
    members = index.get('members')
    require(type(members) is list and 1 <= len(members) <= 512 and
            all(type(row) is dict and type(row.get('file')) is str and
                Path(row['file']).name == row['file'] and type(row.get('bytes')) is int and
                0 <= row['bytes'] <= 1_000_000 and type(row.get('sha256')) is str and
                re.fullmatch('[0-9a-f]{64}', row['sha256']) for row in members) and
            len({row['file'] for row in members}) == len(members), 'screen index members differ')
    with zipfile.ZipFile(path) as zipped:
        entries = zipped.infolist()
        require(len(entries) == len(members) and {entry.filename for entry in entries} ==
                {row['file'] for row in members}, 'screen indexed archive inventory differs')
        for row in members:
            info = zipped.getinfo(row['file'])
            require(info.file_size == row['bytes'] and s.sha(zipped.read(info)) == row['sha256'],
                    'screen indexed member differs')
    return {'index_sha256': s.sha(index_raw), 'readback_sha256': s.sha(readback_raw)}


def aggregate(cases):
    counts = {species: {'selected': 0, 'matchable': 0, 'limited-dose': 0,
                        'dose-ineligible': 0, 'dose-unmatchable': 0, 'evaluable': 0, 'positive': 0}
              for species in ('cat', 'dog')}
    eligible = []
    for row in cases:
        category, status = row['category_id'], row['dose_status']
        require(type(category) is int and category in (17, 18) and
                status in ('matchable', 'limited-dose', 'dose-ineligible', 'dose-unmatchable'),
                'case category or dose status differs')
        values = counts['cat' if category == 17 else 'dog']
        values['selected'] += 1
        values[status] += 1
        if status == 'matchable':
            positive = row['comparisons'].get('positive')
            require(type(positive) is bool, 'evaluable decision differs')
            values['evaluable'] += 1
            values['positive'] += int(positive)
            eligible.append((category, positive))
    n, positive = len(eligible), sum(x[1] for x in eligible)
    species = {x[0] for x in eligible}
    status = ('inconclusive' if n < 4 or species != {17, 18} else
              'positive' if 4 * positive >= 3 * n else 'negative')
    return counts, {'status': status, 'evaluable': n, 'positive': positive,
                    'cats': sum(x[0] == 17 for x in eligible), 'dogs': sum(x[0] == 18 for x in eligible)}


def audit(manifest, screen_data, screen_result, screen_archive, screen_observer, screen_index, screen_readback,
          screen_revision, evaluation_data, evaluation_observer, evaluation_revision, *, synthetic=False):
    s.require_nearest_rounding()
    require(type(synthetic) is bool and type(evaluation_revision) is str and
            re.fullmatch('[0-9a-f]{40}', evaluation_revision), 'evaluation revision differs')
    screen = screen_replay.audit_screen(manifest, screen_data, screen_result, screen_archive, screen_observer,
                                        screen_revision, synthetic=synthetic)
    expected_commit = '0' * 40 if synthetic else SCREEN_COMMIT
    if not synthetic:
        require(screen['result_sha256'] == SCREEN_RESULT_SHA and screen['archive_sha256'] == SCREEN_ARCHIVE_SHA,
                'fixed public screen differs')
    public = checked_readback(screen_index, screen_readback, screen_archive, expected_commit, screen['archive_sha256'])
    data = Path(evaluation_data)
    start_raw, start = screen_replay.read_json(data / 'started.json')
    terminal_raw, terminal = screen_replay.read_json(data / 'terminal.json', 5_000_000)
    observer_raw, observer = screen_replay.read_json(evaluation_observer)
    images = screen['selected']
    ids = [row['image_id'] for row in images]
    require(1 <= len(ids) <= 8 and len(set(ids)) == len(ids), 'evaluation selection differs')
    source, screen_source = start.get('source'), screen['start'].get('source')
    require(type(source) is dict and source.get('revision') == evaluation_revision and
            terminal.get('source_revision') == evaluation_revision and
            start.get('schema') == 'vision-cls-occlusion-v1-evaluation-start' and start.get('mode') == 'evaluation' and
            terminal.get('schema') == 'vision-cls-occlusion-v1-evaluation-terminal' and
            terminal.get('mode') == 'evaluation' and terminal.get('status') == 'complete' and
            start.get('manifest_sha256') == terminal.get('manifest_sha256') == screen['manifest_sha256'] and
            s.typed_equal(start.get('selected_ids'), ids) and s.typed_equal(terminal.get('selected_ids'), ids) and
            type(terminal.get('selected')) is int and terminal['selected'] == len(ids) and
            start.get('screen_result_sha256') == screen['result_sha256'] and
            start.get('screen_archive_sha256') == screen['archive_sha256'] and
            start.get('screen_terminal_sha256') == screen['terminal_sha256'] and
            start.get('screen_public_commit') == expected_commit and
            s.typed_equal(start.get('runtime'), terminal.get('runtime')) and
            s.typed_equal(start.get('runtime'), screen['start'].get('runtime')) and
            start.get('model_state_sha256') == terminal.get('model_state_sha256_before_after') ==
            screen['start'].get('model_state_sha256') and not (data / 'failure.json').exists(),
            'evaluation start/terminal binding differs')
    if not synthetic:
        require(start.get('model_state_sha256') == s.MODEL_STATE and type(source.get('sources')) is dict and
                type(screen_source) is dict and type(screen_source.get('sources')) is dict and
                all(source['sources'].get(path) == digest for path, digest in screen_source['sources'].items()),
                'screen/evaluation recorded source or model differs')
    require(type(observer) is dict and observer.get('schema') == 'vision-cls-occlusion-v1-evaluation-direct-observer' and
            observer.get('mode') == 'evaluation' and observer.get('status') == 'complete' and
            observer.get('source_revision') == evaluation_revision and type(observer.get('exit_code')) is int and
            observer['exit_code'] == 0 and observer.get('reaped') is True and observer.get('timed_out') is False and
            observer.get('forced_stop') is False and 'error_type' in observer and observer['error_type'] is None and
            observer.get('terminal_sha256') == s.sha(terminal_raw), 'evaluation observer differs')
    count, submitted = terminal.get('saved_forwards'), terminal.get('submissions')
    saved_cases = terminal.get('cases')
    require(type(count) is int and type(submitted) is int and 0 < count <= 184 and submitted == count and
            type(saved_cases) is list and s.typed_equal([row.get('image_id') for row in saved_cases], ids),
            'evaluation count or case inventory differs')
    names = {'started.json', 'terminal.json'} | {f'forward-{i:03d}.{suffix}' for i in range(1, count + 1)
                                                 for suffix in ('json', 'bin')}
    for ident in ids:
        names.add(f'case-{ident}.json')
        names.update(f'initial-input-{ident}-{kind}.bin' for kind in ('clean', 'animal', 'background'))
    require({path.name for path in data.iterdir()} == names, 'evaluation complete file inventory differs')
    records = s.Records(data, count)
    initial = case_replay.initial_records(records, data, images, screen['input_by_id'], screen['logits_by_id'], synthetic)
    cases = []
    for image, saved in zip(images, saved_cases):
        _, one = screen_replay.read_json(data / f"case-{image['image_id']}.json")
        require(s.typed_equal(one, saved), 'case and terminal differ')
        checked = case_replay.case_replay(records, image, one, initial[image['image_id']])
        pair = screen['mask_drops'][image['image_id']]
        screen_b = pair['animal_drop'] - pair['background_drop']
        computed_b = checked['comparisons']['occlusion_contrast']
        reported_b = one['comparisons']['occlusion_contrast']
        s.close(computed_b, screen_b, 'cross-phase response contrast differs')
        require(screen_b >= .05 and computed_b >= .05 and reported_b >= .05,
                'selected response eligibility differs')
        checked['reported_drops'] = {key: value['drop'] for key, value in one['conditions'].items()}
        cases.append(checked)
    require(records.next == count + 1, 'evaluation forward order or count differs')
    by_species, outcome = aggregate(cases)
    require(s.typed_equal(terminal.get('by_species'), by_species) and
            s.typed_equal(terminal.get('aggregate'), outcome), 'evaluation aggregate differs')
    s.require_nearest_rounding()
    return {'manifest_sha256': screen['manifest_sha256'], 'screen_result_sha256': screen['result_sha256'],
            'screen_archive_sha256': screen['archive_sha256'], 'screen_terminal_sha256': screen['terminal_sha256'],
            'screen_observer_sha256': screen['observer_sha256'], **public,
            'evaluation_start_sha256': s.sha(start_raw), 'evaluation_terminal_sha256': s.sha(terminal_raw),
            'evaluation_observer_sha256': s.sha(observer_raw), 'selected': ids, 'forwards': count,
            'cases': cases, 'by_species': by_species, 'aggregate': outcome, 'forward_hashes': records.hashes}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('manifest', 'screen-data', 'screen-result', 'screen-archive', 'screen-observer',
                 'screen-index', 'screen-readback', 'evaluation-data', 'evaluation-observer', 'report'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--screen-revision', required=True)
    parser.add_argument('--evaluation-revision', required=True)
    parser.add_argument('--synthetic', action='store_true')
    args = parser.parse_args()
    result = audit(args.manifest, args.screen_data, args.screen_result, args.screen_archive, args.screen_observer,
                   args.screen_index, args.screen_readback, args.screen_revision, args.evaluation_data,
                   args.evaluation_observer, args.evaluation_revision, synthetic=args.synthetic)
    report = {'schema': 'vision-cls-occlusion-independent-evaluation-audit-v1', 'synthetic': args.synthetic,
              'result': result, 'scope': 'Quiescent saved-byte and arithmetic consistency; public readback is '
              'cooperative. No source/execution, process-tree, chronology, preprocessing, pretraining, '
              'causal mediation or population attestation. Individual condition drops are reported values '
              'checked against independently recomputed values.'}
    raw = (json.dumps(report, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()
    with args.report.open('xb') as stream:
        require(stream.write(raw) == len(raw), 'short report write')
        stream.flush()
        os.fsync(stream.fileno())
    print(json.dumps({'report_sha256': s.sha(raw), 'forwards': result['forwards'],
                      'selected': len(result['selected']), 'aggregate': result['aggregate']}, sort_keys=True))


if __name__ == '__main__':
    main()
