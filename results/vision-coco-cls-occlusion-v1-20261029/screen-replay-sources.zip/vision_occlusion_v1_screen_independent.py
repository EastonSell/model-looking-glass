"""Independent model-free occlusion screen and clean-logit handoff replay.

Inputs must remain quiescent. This checks saved-byte, selection and cross-phase
consistency, not source/model authenticity, execution, publication timing,
supervision, preprocessing, or pretraining independence. Top-one class IDs,
not optional class label strings, are verified. Rounding checks sample process
state at entry and exit and do not prove every intermediate operation.
"""
import argparse
import hashlib
import io
import re
import zipfile
import json
import math
from pathlib import Path
import struct

STATE_SHAPE = [1, 197, 192]
STATE_BYTES = 197 * 192 * 4
TOKEN_BYTES = 192 * 4
EARLY = 'vit.encoder.layer.2'
LATE = 'vit.encoder.layer.11'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def require_nearest_rounding():
    # Nonconstant expressions distinguish all four standard rounding modes.
    # This samples current process state, not concurrent transient changes.
    one = float.fromhex('0x1p0')
    delta = float.fromhex('0x1.8p-52')
    expected = float.fromhex('0x1.0000000000002p0')
    require(one + delta == expected and -one - delta == -expected,
            'binary64 rounding mode is not nearest-even')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def bounded_read(path, limit):
    with path.open('rb') as stream:
        raw = stream.read(limit+1)
    require(len(raw) <= limit, f'oversized evidence file: {path.name}')
    return raw


def read_json(path, limit=4_000_000):
    raw = bounded_read(path,limit)
    require(0 < len(raw) <= limit, f'invalid JSON length: {path.name}')
    def unique_pairs(items):
        value = {}
        for key, item in items:
            require(key not in value, 'duplicate JSON key')
            value[key] = item
        return value
    value = json.loads(raw, object_pairs_hook=unique_pairs,
                       parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite JSON')))
    return raw, value


def typed_equal(left, right):
    return json.dumps(left, sort_keys=True, separators=(',', ':'), allow_nan=False) == \
           json.dumps(right, sort_keys=True, separators=(',', ':'), allow_nan=False)


def close(a, b, message):
    require(type(a) in (int, float) and type(b) in (int, float) and not isinstance(a, bool)
            and not isinstance(b, bool) and math.isfinite(a) and math.isfinite(b)
            and math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-10), message)


def decode_word(word):
    exponent, fraction = (word >> 23) & 255, word & 0x7fffff
    require(exponent != 255, 'nonfinite binary32')
    mantissa = fraction if exponent == 0 else (1 << 23) | fraction
    value = math.ldexp(float(mantissa), -149 if exponent == 0 else exponent - 150)
    return -value if word & 0x80000000 else value


def values(raw):
    require(len(raw) % 4 == 0, 'unaligned binary32 payload')
    return [decode_word(word[0]) for word in struct.iter_unpack('<I', raw)]



def summarize(raw, reference=None):
    z = values(raw)
    require(len(z) == 1000, 'invalid logit vector')
    dog, cat = z[151:269], z[281:286]
    off = z[:151] + z[269:281] + z[286:]
    def shifted(v):
        m = max(v)
        return m, math.fsum(math.exp(x - m) for x in v)
    dm, ds = shifted(dog)
    cm, cs = shifted(cat)
    om, os = shifted(off)
    tm, ts = shifted(z)
    conditional = [math.exp(x - om) / os for x in off]
    score = {'margin': (dm - cm) + math.log(ds) - math.log(cs),
             'dog_mass': math.exp(dm - tm) * ds / ts,
             'cat_mass': math.exp(cm - tm) * cs / ts,
             'off_mass': math.exp(om - tm) * os / ts,
             'top1_id': max(range(1000), key=lambda i: z[i])}
    if reference is not None:
        require(len(reference) == len(conditional), 'off-group reference length mismatch')
        score['off_conditional_tv'] = .5 * math.fsum(abs(x - y) for x, y in zip(conditional, reference))
    return score, conditional


def check_score(stored, computed):
    for key, expected in computed.items():
        if key == 'top1_id':
            require(type(stored.get(key)) is int and stored[key] == expected, 'top-1 mismatch')
        else:
            close(stored.get(key), expected, f'score mismatch: {key}')
    for key in ('dog_mass','cat_mass','off_mass','off_conditional_tv'):
        if key in computed:
            require(0 <= stored[key] <= 1, f'probability outside [0,1]: {key}')
    if all(key in computed for key in ('dog_mass','cat_mass','off_mass')):
        close(math.fsum(stored[key] for key in ('dog_mass','cat_mass','off_mass')),1.,
              'reported probability masses do not sum to one')


def metadata_expected(row, path, tokens, action):
    events = row['metadata']['steps']
    if path is None:
        desired = [('early', 'capture', EARLY, None), ('late', 'capture', LATE, None)]
    else:
        desired = [('before_all', 'capture', path, None)]
        if tokens is None:
            desired.append(('action', action, path, None))
        else:
            for i, t in enumerate(tokens):
                desired.extend([(f'before_{i}', 'capture', path, t), (f'action_{i}', action, path, t),
                                (f'after_{i}', 'capture', path, t)])
        desired.append(('after_all', 'capture', path, None))
    require(type(events) is list and len(events) == len(desired), 'metadata action count mismatch')
    for order, (event, (name, operation, module, index)) in enumerate(zip(events, desired)):
        require(event.get('name') == name and event.get('operation') == operation and
                event.get('module_path') == module and typed_equal(event.get('order'), order) and
                typed_equal(event.get('invocation'), 0) and typed_equal(event.get('forward_index'), 0) and
                typed_equal(event.get('batch_index'), 0 if index is not None else None) and
                typed_equal(event.get('token_index'), index) and typed_equal(event.get('output_shape'), STATE_SHAPE) and
                typed_equal(event.get('selected_shape'), [192] if index is not None else STATE_SHAPE) and
                event.get('dtype') == 'torch.float32' and event.get('output_selector') == [] and
                module in event.get('module_aliases', []), 'metadata action identity/shape mismatch')


class Records:
    def __init__(self, root, count):
        self.root, self.count, self.next = root, count, 1
        self.hashes = []

    def take(self, label, path=None, tokens=None, action='capture'):
        index = self.next
        require(index <= self.count, 'missing forward')
        raw_json, row = read_json(self.root / f'forward-{index:03d}.json', 200_000)
        require(typed_equal(row.get('submission'), index) and row.get('label') == label and
                row.get('file') == f'forward-{index:03d}.bin' and
                row.get('dtype') == 'little-endian-float32', 'forward order/identity mismatch')
        packed = bounded_read(self.root / row['file'],1_000_000)
        require(len(packed) <= 1_000_000 and sha(packed) == row.get('sha256'), 'forward bytes/hash mismatch')
        layout = row.get('layout')
        require(type(layout) is dict, 'missing tensor layout')
        ordered = sorted(layout.items(), key=lambda item: item[1]['offset'])
        offset, tensors = 0, {}
        for name, entry in ordered:
            shape, start, size = entry.get('shape'), entry.get('offset'), entry.get('bytes')
            require(type(name) is str and type(shape) is list and all(type(x) is int and x > 0 for x in shape)
                    and type(start) is int and start == offset and type(size) is int
                    and size == 4 * math.prod(shape) and start + size <= len(packed), 'invalid tensor layout')
            tensors[name] = packed[start:start + size]
            offset += size
        require(offset == len(packed) and layout.get('logits', {}).get('shape') == [1, 1000], 'payload coverage mismatch')
        metadata_expected(row, path, tokens, action)
        self.hashes.append({'submission': index, 'json_sha256': sha(raw_json), 'binary_sha256': sha(packed)})
        self.next += 1
        return row, tensors


def expect_shapes(row, tensors, shapes):
    require(set(tensors) == set(shapes), 'unexpected saved tensor set')
    for name, shape in shapes.items():
        require(row['layout'][name]['shape'] == shape, f'tensor shape mismatch: {name}')


def checked_score(row, tensors, reference=None):
    computed, conditional = summarize(tensors['logits'], reference)
    check_score(row['score'], computed)
    return computed, conditional


def initial(records, pair_id, side):
    row, tensors = records.take(f'{pair_id}:{side}:initial')
    expect_shapes(row, tensors, {'logits': [1, 1000], 'early': STATE_SHAPE, 'late': STATE_SHAPE})
    for name in ('early', 'late'):
        require(all((word[0] >> 23) & 255 != 255 for word in struct.iter_unpack('<I', tensors[name])),
                f'nonfinite initial {name} state')
    score_, conditional = checked_score(row, tensors)
    return {'logits': tensors['logits'], 'early': tensors['early'], 'late': tensors['late'],
            'score': score_, 'conditional': conditional}



def validate_images(images, synthetic=False):
    require(type(images) is list and len(images) == 64, 'candidate count differs')
    ids, jpeg_hashes, pixel_hashes = set(), set(), set()
    for index, row in enumerate(images):
        cat, rank = (17, index) if index < 32 else (18, index - 32)
        image_id = row.get('image_id')
        require(type(image_id) is int and image_id >= 0 and image_id not in ids and
                type(row.get('category_id')) is int and row['category_id'] == cat and
                type(row.get('rank')) is int and row['rank'] == rank and
                row.get('role') == ('donor' if rank % 4 == 0 else 'target') and
                row.get('file_name') == f'{image_id:012d}.jpg', 'candidate identity or role differs')
        ids.add(image_id)
        for key, previous in (('jpeg_sha256', jpeg_hashes), ('pixel_sha256', pixel_hashes)):
            value = row.get(key)
            require(type(value) is str and re.fullmatch('[0-9a-f]{64}', value) is not None and
                    value not in previous, 'candidate image hash differs or is duplicated')
            previous.add(value)
        require(type(row.get('jpeg_bytes')) is int and 0 < row['jpeg_bytes'] <= 5_000_000,
                'candidate byte count differs')
        if not synthetic:
            rank_hash = sha(f'vision-coco-occlusion-v1:{cat}:{image_id}'.encode('ascii'))
            require(row.get('selection_rank_sha256') == rank_hash, 'candidate rank hash differs')
            if rank:
                previous = images[index - 1]
                require((previous['selection_rank_sha256'], previous['image_id']) < (rank_hash, image_id),
                        'candidate order differs')
        sites = row.get('sites')
        require(type(sites) is list and sites, 'candidate has no qualified site')
        coords = []
        for site in sites:
            coord, counts = site.get('row_col'), site.get('token_mask_pixels')
            require(type(coord) is list and len(coord) == 2 and
                    all(type(x) is int and 0 <= x <= 12 for x in coord) and
                    type(counts) is list and len(counts) == 4 and
                    all(type(x) is int and 0 <= x <= 256 for x in counts), 'invalid site or occupancy')
            r, c = coord
            require(type(site.get('mask_pixels')) is int and site['mask_pixels'] == sum(counts) and
                    site['mask_pixels'] >= 512 and
                    typed_equal(site.get('token_ids'), [1 + 14*(r+dr) + c+dc for dr in range(2) for dc in range(2)]) and
                    type(site.get('squared_center_radius')) is int and
                    site['squared_center_radius'] == (r-6)**2 + (c-6)**2, 'site geometry differs')
            coords.append((r, c))
        require(len(coords) == len(set(coords)) and
                coords == sorted(coords, key=lambda p: ((p[0]-6)**2 + (p[1]-6)**2, p)),
                'site order differs')


def screen_scoring(raw, category):
    require(len(raw) == 4000 and category in (17, 18), 'screen vector or category differs')
    score, _ = summarize(raw)
    top = score['top1_id']
    top_matches = 281 <= top <= 285 if category == 17 else 151 <= top <= 268
    mass = score['cat_mass'] if category == 17 else score['dog_mass']
    reasons = ([] if top_matches else ['top1-outside-annotated-group']) + \
              ([] if mass >= .2 else ['group-mass-below-0.2'])
    return {**score, 'recognized': not reasons, 'reasons': reasons, 'logit_sha256': sha(raw)}


def reported_screen_gate(score, category):
    top = score['top1_id']
    matches = 281 <= top <= 285 if category == 17 else 151 <= top <= 268
    mass = score['cat_mass'] if category == 17 else score['dog_mass']
    reasons = ([] if matches else ['top1-outside-annotated-group']) + \
              ([] if mass >= .2 else ['group-mass-below-0.2'])
    return not reasons, reasons


def validate_archive(raw, data, expected):
    require(0 < len(raw) <= 5_000_000, 'screen archive size differs')
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        entries = archive.infolist()
        require(len(entries) == len(expected) and {item.filename for item in entries} == expected,
                'screen archive inventory differs')
        for item in entries:
            require(item.file_size <= 1_000_000 and archive.read(item) == bounded_read(data / item.filename,1_000_000),
                    'screen archive member differs')


MODEL_STATE = 'd1bfb26b30f847366de6388385d547fc29cc3c20b330c4faad993891e165eccd'
MANIFEST_SHA = 'aa61b294710f5a6cd9682dc783085c7079f1addfbad8257fdbd893d143ce4cef'
RESULT = 'results/vision-coco-occlusion-v1-20261029/'


def rectangle(row, col):
    return (16 * col, 16 * row, 16 * (col + 2), 16 * (row + 2))


def intersects(left, right):
    return (left[0] < right[2] and left[2] > right[0] and
            left[1] < right[3] and left[3] > right[1])


def token_ids(row, col):
    return [1 + 14 * (row + dr) + col + dc for dr in range(2) for dc in range(2)]


def geometry(image):
    """Recompute fixed geometry from saved box/site annotations, not pixels."""
    width, height = image.get('width'), image.get('height')
    require(type(width) is int and width > 0 and type(height) is int and height > 0,
            'image dimensions differ')
    def finite_quad(value):
        return (type(value) is list and len(value) == 4 and
                all(type(v) in (float, int) and math.isfinite(v) for v in value))
    animal_box = image.get('bbox_resized_xyxy')
    require(finite_quad(animal_box), 'animal box differs')
    annotations = image.get('other_boxes')
    require(type(annotations) is list, 'other annotation list differs')
    other = []
    for item in annotations:
        require(type(item) is dict and type(item.get('annotation_id')) is int and
                type(item.get('category_id')) is int and finite_quad(item.get('bbox_xywh')),
                'other annotation differs')
        x, y, w, h = item['bbox_xywh']
        require(w >= 0 and h >= 0, 'other box has negative size')
        other.append((item, (224 * x / width, 224 * y / height,
                             224 * (x + w) / width, 224 * (y + h) / height)))
    candidates = []
    for site in image['sites']:
        r, c = site['row_col']
        rect = rectangle(r, c)
        require(animal_box[0] <= rect[0] and animal_box[1] <= rect[1] and
                rect[2] <= animal_box[2] and rect[3] <= animal_box[3],
                'animal site is outside annotated animal box')
        if site['mask_pixels'] < 768:
            continue
        radius = (r - 6) ** 2 + (c - 6) ** 2
        for br in range(13):
            for bc in range(13):
                if (br - 6) ** 2 + (bc - 6) ** 2 != radius:
                    continue
                background = rectangle(br, bc)
                if any(intersects(background, box) for box in [animal_box] + [x[1] for x in other]):
                    continue
                candidates.append(((abs(r-br) + abs(c-bc), radius, r, c, br, bc), site))
    if not candidates:
        return None
    key, site = min(candidates, key=lambda value: value[0])
    _, radius, r, c, br, bc = key
    overlaps = [{'annotation_id': ann['annotation_id'], 'category_id': ann['category_id']}
                for ann, box in other if intersects(rectangle(r, c), box)]
    overlaps.sort(key=lambda value: value['annotation_id'])
    return {'animal': {'row_col': [r, c], 'token_ids': token_ids(r, c),
                       'mask_pixels': site['mask_pixels'], 'token_mask_pixels': site['token_mask_pixels'],
                       'other_box_overlaps': overlaps},
            'background': {'row_col': [br, bc], 'token_ids': token_ids(br, bc)},
            'squared_center_radius': radius, 'manhattan_distance': key[0]}


def selection(images, scores):
    require(len(images) == len(scores) == 64, 'screen inventory differs')
    selected, counts = [], {}
    for category, name in ((17, 'cat'), (18, 'dog')):
        rows = [(image, score) for image, score in zip(images, scores) if image['category_id'] == category]
        require(len(rows) == 32, 'species count differs')
        for index, (image, score) in enumerate(rows):
            require(image['rank'] == index and type(score.get('image_id')) is int and
                    score['image_id'] == image['image_id'] and type(score.get('recognized')) is bool,
                    'screen order or recognition differs')
        qualified = [image for image, score in rows
                     if score['recognized'] and image['occlusion_geometry'] is not None]
        selected.extend(qualified[:4])
        counts[name] = {'candidates': len(rows),
                        'geometry_qualified': sum(image['occlusion_geometry'] is not None for image, _ in rows),
                        'screened': len(rows), 'recognized': sum(score['recognized'] for _, score in rows),
                        'recognized_geometry': len(qualified), 'selected': min(4, len(qualified))}
    return selected, counts


def validate_start_terminal(data, mode, manifest_hash, synthetic):
    start_raw, start = read_json(data / 'started.json')
    terminal_raw, terminal = read_json(data / 'terminal.json', 5_000_000)
    require(not (data / 'failure.json').exists() and
            start.get('schema') == 'vision-occlusion-v1-start' and start.get('mode') == mode and
            start.get('manifest_sha256') == manifest_hash and
            terminal.get('schema') == 'vision-occlusion-v1-terminal' and
            terminal.get('status') == 'complete' and terminal.get('mode') == mode and
            terminal.get('manifest_sha256') == manifest_hash and
            terminal.get('source_revision') == start.get('source', {}).get('revision') and
            typed_equal(terminal.get('runtime'), start.get('runtime')) and
            terminal.get('model_state_sha256_before_after') == start.get('model_state_sha256'),
            'start/terminal identity differs')
    require(type(start.get('source')) is dict and
            type(start['source'].get('revision')) is str and
            re.fullmatch('[0-9a-f]{40}', start['source']['revision']) is not None and
            type(start['source'].get('sources')) is dict and type(start.get('runtime')) is dict,
            'source or runtime missing')
    if not synthetic:
        require(start.get('model_state_sha256') == MODEL_STATE and
                start['runtime'].get('binary64_rounding') == 'nearest-even' and
                start['runtime'].get('denormals_preserved') is True, 'model state or runtime differs')
    return start_raw, start, terminal_raw, terminal


def observer_check(path, mode, start, terminal_raw):
    raw, record = read_json(path)
    require(record.get('schema') == 'vision-occlusion-v1-direct-observer' and
            record.get('status') == 'complete' and record.get('mode') == mode and
            record.get('source_revision') == start['source']['revision'] and
            type(record.get('exit_code')) is int and record['exit_code'] == 0 and
            record.get('reaped') is True and record.get('timed_out') is False and
            record.get('forced_stop') is False and 'error_type' in record and record['error_type'] is None and
            record.get('terminal_sha256') == sha(terminal_raw), 'direct observer record differs')
    return sha(raw)


def screen_audit(manifest_path, data, public_result, archive_path, observer_path=None, synthetic=False):
    require_nearest_rounding()
    manifest_raw, manifest = read_json(manifest_path, 5_000_000)
    require(manifest.get('schema') == 'vision-coco-occlusion-cases-v1' and
            (manifest.get('fabricated') is True if synthetic else manifest.get('fabricated') is not True),
            'manifest schema or synthetic flag differs')
    manifest_hash = sha(manifest_raw)
    require(synthetic or manifest_hash == MANIFEST_SHA, 'fixed public manifest digest differs')
    images = manifest.get('images')
    validate_images(images, synthetic=synthetic)
    for image in images:
        require(typed_equal(geometry(image), image.get('occlusion_geometry')), 'fixed geometry differs')
    start_raw, start, terminal_raw, terminal = validate_start_terminal(data, 'screen', manifest_hash, synthetic)
    require(typed_equal(start.get('selected_ids'), [image['image_id'] for image in images]) and
            type(terminal.get('submissions')) is int and terminal['submissions'] == 64 and
            type(terminal.get('saved_forwards')) is int and terminal['saved_forwards'] == 64,
            'screen candidate or forward count differs')
    expected = {'started.json', 'terminal.json', 'screen-result.json'} | {
        f'forward-{i:03d}.{ext}' for i in range(1, 65) for ext in ('json', 'bin')}
    require({p.name for p in data.iterdir()} == expected, 'screen inventory differs')
    result_raw, result = read_json(data / 'screen-result.json', 5_000_000)
    require(bounded_read(public_result, 5_000_000) == result_raw and
            result.get('schema') == 'vision-occlusion-v1-screen-result' and
            result.get('manifest_sha256') == manifest_hash and terminal.get('screen_result_sha256') == sha(result_raw),
            'public screen-result binding differs')
    require(type(result.get('screen')) is list and len(result['screen']) == 64, 'screen score inventory differs')
    observations, raw_by_id, hashes = [], {}, []
    for index, image in enumerate(images, 1):
        row_raw, row = read_json(data / f'forward-{index:03d}.json', 200_000)
        raw = bounded_read(data / f'forward-{index:03d}.bin', 4000)
        score = screen_scoring(raw, image['category_id'])
        require(type(row.get('submission')) is int and row['submission'] == index and
                row.get('label') == f"screen:{image['image_id']}" and
                row.get('file') == f'forward-{index:03d}.bin' and row.get('sha256') == sha(raw) and
                row.get('dtype') == 'little-endian-float32' and
                typed_equal(row.get('layout'), {'logits': {'shape': [1, 1000], 'offset': 0, 'bytes': 4000}}) and
                typed_equal(row.get('metadata'), {'kind': 'screen', 'image_id': image['image_id']}),
                'screen forward identity differs')
        saved, result_score = row.get('score'), result['screen'][index-1]
        require(type(saved) is dict and set(saved) == set(score) and type(result_score) is dict and
                set(result_score) == set(score) | {'image_id'} and
                type(result_score['image_id']) is int and result_score['image_id'] == image['image_id'],
                'screen score fields differ')
        numeric = {key: score[key] for key in ('margin', 'dog_mass', 'cat_mass', 'off_mass', 'top1_id')}
        check_score(saved, numeric)
        check_score(result_score, numeric)
        for key in ('recognized', 'reasons', 'logit_sha256'):
            require(typed_equal(saved[key], score[key]) and typed_equal(result_score[key], score[key]),
                    'screen gate or saved logit hash differs')
        require(typed_equal(saved, {key: result_score[key] for key in score}) and
                reported_screen_gate(saved, image['category_id']) == (score['recognized'], score['reasons']),
                'reported screen scores contradict the gate')
        observations.append({'image_id': image['image_id'], **score})
        raw_by_id[image['image_id']] = raw
        hashes.append({'submission': index, 'json_sha256': sha(row_raw), 'binary_sha256': sha(raw)})
    selected, counts = selection(images, observations)
    reported_selected, reported_counts = selection(images, result['screen'])
    ids = [image['image_id'] for image in selected]
    require(typed_equal(result.get('selected_ids'), ids) and typed_equal(result.get('counts'), counts) and
            typed_equal([image['image_id'] for image in reported_selected], ids) and
            typed_equal(reported_counts, counts), 'screen selection or counts differ')
    archive_raw = bounded_read(archive_path, 5_000_000)
    validate_archive(archive_raw, data, expected)
    require(synthetic or observer_path is not None, 'real screen observer is required')
    observer_hash = None if observer_path is None else observer_check(observer_path, 'screen', start, terminal_raw)
    require_nearest_rounding()
    return {'manifest_sha256': manifest_hash, 'start': start, 'start_sha256': sha(start_raw),
            'terminal_sha256': sha(terminal_raw), 'screen_result_sha256': sha(result_raw),
            'screen_archive_sha256': sha(archive_raw), 'observer_sha256': observer_hash,
            'raw_by_id': raw_by_id, 'observations': observations, 'selected': selected,
            'counts': counts, 'forward_hashes': hashes}


def case_labels(status):
    require(status in ('matchable', 'limited-dose', 'dose-ineligible', 'dose-unmatchable'),
            'dose status differs')
    names = ['clean', 'animal_mask', 'background_mask', 'repeat', 'animal_null', 'animal_self',
             'background_null', 'background_self', 'full_self', 'animal_full', 'background_full']
    if status in ('matchable', 'limited-dose'):
        names += ['animal_transfer', 'background_transfer', 'animal_random', 'background_random']
    return names + ['animal_final', 'background_final', 'post_clean']


def cross_phase_audit(data, screen, observer_path=None, synthetic=False):
    """Bind screen logits to every selected case's later clean forward.

    Intervening record labels and payload hashes are checked only for ordering;
    intervention geometry, tensors, doses and decisions need a separate audit.
    """
    require_nearest_rounding()
    start_raw, start, terminal_raw, terminal = validate_start_terminal(
        data, 'evaluation', screen['manifest_sha256'], synthetic)
    ids = [image['image_id'] for image in screen['selected']]
    require(typed_equal(start.get('selected_ids'), ids) and
            typed_equal(start.get('runtime'), screen['start'].get('runtime')) and
            start.get('model_state_sha256') == screen['start'].get('model_state_sha256'),
            'cross-phase image order, runtime or model state differs')
    sources = dict(start['source']['sources'])
    result_key, archive_key = RESULT + 'screen-result.json', RESULT + 'screen-evidence.zip'
    if not synthetic or result_key in sources or archive_key in sources:
        require(sources.pop(result_key, None) == screen['screen_result_sha256'] and
                sources.pop(archive_key, None) == screen['screen_archive_sha256'],
                'evaluation source handoff hashes differ')
    require(typed_equal(sources, screen['start']['source']['sources']), 'cross-phase source hashes differ')
    cases = terminal.get('cases')
    require(type(cases) is list and len(cases) == len(ids) and
            type(terminal.get('selected')) is int and terminal['selected'] == len(ids) and
            type(terminal.get('submissions')) is int and 0 <= terminal['submissions'] <= 144 and
            type(terminal.get('saved_forwards')) is int and
            terminal['saved_forwards'] == terminal['submissions'], 'evaluation inventory differs')
    count = terminal['submissions']
    expected = {'started.json', 'terminal.json'}
    expected.update(f'case-{ident}.json' for ident in ids)
    expected.update(f'input-{ident}-{kind}.bin' for ident in ids for kind in ('clean', 'animal', 'background'))
    expected.update(f'forward-{index:03d}.{ext}' for index in range(1, count + 1) for ext in ('json', 'bin'))
    require({path.name for path in data.iterdir()} == expected, 'evaluation file inventory differs')
    records, clean_records = Records(data, count), []
    for image, case in zip(screen['selected'], cases):
        ident = image['image_id']
        require(type(case) is dict and type(case.get('image_id')) is int and case['image_id'] == ident and
                type(case.get('category_id')) is int and case['category_id'] == image['category_id'] and
                typed_equal(case.get('geometry'), image['occlusion_geometry']) and
                type(case.get('dose')) is dict, 'case identity differs')
        case_raw, case_file = read_json(data / f'case-{ident}.json', 1_000_000)
        require(typed_equal(case, case_file), 'case record differs from terminal')
        labels = case_labels(case['dose'].get('status'))
        row, tensors = records.take(f'case-{ident}:clean')
        expect_shapes(row, tensors, {'logits': [1, 1000], 'early': STATE_SHAPE, 'late': STATE_SHAPE})
        for name in ('early', 'late'):
            require(all((word[0] >> 23) & 255 != 255 for word in struct.iter_unpack('<I', tensors[name])),
                    f'nonfinite initial {name} state')
        checked_score(row, tensors)
        require(tensors['logits'] == screen['raw_by_id'][ident], 'cross-phase clean logits differ')
        require(typed_equal(case.get('baseline'), row.get('score')), 'saved case baseline differs')
        clean_records.append({'image_id': ident, 'submission': row['submission'],
                              'logit_sha256': sha(tensors['logits']), 'case_sha256': sha(case_raw)})
        for label in labels[1:]:
            index = records.next
            require(index <= count, 'missing evaluation forward')
            raw_row, other = read_json(data / f'forward-{index:03d}.json', 200_000)
            raw = bounded_read(data / f'forward-{index:03d}.bin', 1_000_000)
            require(type(other.get('submission')) is int and other['submission'] == index and
                    other.get('label') == f'case-{ident}:{label}' and
                    other.get('file') == f'forward-{index:03d}.bin' and
                    other.get('dtype') == 'little-endian-float32' and other.get('sha256') == sha(raw),
                    'evaluation forward order or saved hash differs')
            records.hashes.append({'submission': index, 'json_sha256': sha(raw_row), 'binary_sha256': sha(raw)})
            records.next += 1
    require(records.next == count + 1, 'evaluation forward count or trailing records differ')
    require(synthetic or observer_path is not None, 'real evaluation observer is required')
    observer_hash = None if observer_path is None else observer_check(observer_path, 'evaluation', start, terminal_raw)
    require_nearest_rounding()
    return {'start_sha256': sha(start_raw), 'terminal_sha256': sha(terminal_raw),
            'observer_sha256': observer_hash, 'clean_forward_count': len(clean_records),
            'recorded_evaluation_forward_count': count, 'clean_records': clean_records,
            'forward_hashes': records.hashes,
            'scope': 'Clean logits and ordered saved hashes only; separate audit required for patches, doses and decisions.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--screen-data', type=Path, required=True)
    parser.add_argument('--public-screen-result', type=Path, required=True)
    parser.add_argument('--public-screen-archive', type=Path, required=True)
    parser.add_argument('--screen-observer', type=Path)
    parser.add_argument('--evaluation-data', type=Path)
    parser.add_argument('--evaluation-observer', type=Path)
    parser.add_argument('--synthetic', action='store_true')
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    screen = screen_audit(args.manifest, args.screen_data, args.public_screen_result,
                          args.public_screen_archive, args.screen_observer, args.synthetic)
    cross = None if args.evaluation_data is None else cross_phase_audit(
        args.evaluation_data, screen, args.evaluation_observer, args.synthetic)
    report = {'schema': 'independent-vision-occlusion-v1-screen-audit',
              'scope': 'Saved-byte screen, annotation geometry, selection and initial cross-phase consistency only; '
                       'no source/model authenticity, preprocessing, execution, supervision, chronology or '
                       'pretraining attestation. Input files must remain quiescent. Optional class-label strings '
                       'are not checked. Later patches, doses and decisions need a separate audit.',
              'synthetic': args.synthetic, 'manifest_sha256': screen['manifest_sha256'],
              'screen_start_sha256': screen['start_sha256'], 'screen_terminal_sha256': screen['terminal_sha256'],
              'screen_result_sha256': screen['screen_result_sha256'], 'screen_archive_sha256': screen['screen_archive_sha256'],
              'screen_observer_sha256': screen['observer_sha256'],
              'selected_ids': [row['image_id'] for row in screen['selected']], 'counts': screen['counts'],
              'screen_forward_hashes': screen['forward_hashes'], 'cross_phase': cross}
    payload = (json.dumps(report, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()
    with args.report.open('xb') as stream:
        require(stream.write(payload) == len(payload), 'short report write')
    print(json.dumps({'report_sha256': sha(payload), 'selected': len(screen['selected']),
                      'evaluation_checked': cross is not None}))


if __name__ == '__main__':
    main()

