"""Model-free response-screen and cross-phase checks for CLS/occlusion v1.

Inputs must remain quiescent. The screen uses an observed masking response as
an eligibility condition, so its selected cases are a conditional sample. This
reader checks saved-byte and arithmetic consistency only; source/model identity,
execution, supervision, timing, image preprocessing and population conclusions
remain outside its scope.
"""

import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import zipfile


HELPER_SHA256 = 'ac13ddfda8701e892a74ed4bbeb44d537f6060c0665a5abe15175aef72658e0f'
helper_path = Path(__file__).with_name('vision_occlusion_v1_screen_independent.py')
if hashlib.sha256(helper_path.read_bytes()).hexdigest() != HELPER_SHA256:
    raise ValueError('fixed screen arithmetic helper differs')
spec = importlib.util.spec_from_file_location('prior_screen_replay', helper_path)
s = importlib.util.module_from_spec(spec)
spec.loader.exec_module(s)

MANIFEST_SHA256 = 'a52040786557fde9e503b6b6d1246bee0cbd41106b3cd110ea6788ab13a53487'
RANK_DOMAIN = 'vision-coco-cls-occlusion-v1'
DISCOVERY_COMMIT = '656929d7edceed3be964bd432131b351e0cd60d4'
DISCOVERY_TERMINAL = 'd23f53d8465108b5612d69c8899f98d47e0218f5af646deb381886dcb0ff93d6'
DISCOVERY_ARCHIVE = '73f2109c183cdc6da76e632a7638d3357a58ab8e7e952d3dc0639fa0b957deb4'
PIXEL_BYTES = 3 * 224 * 224 * 4


def read_json(path, limit=4_000_000):
    raw = s.bounded_read(Path(path), limit)
    s.require(0 < len(raw) <= limit, 'invalid JSON length')
    def pairs(items):
        output = {}
        for key, value in items:
            s.require(key not in output, 'duplicate JSON key')
            output[key] = value
        return output
    def finite_float(value):
        parsed = float(value)
        s.require(math.isfinite(parsed), 'nonfinite JSON number')
        return parsed
    def invalid_constant(_):
        raise ValueError('nonfinite JSON number')
    return raw, json.loads(raw, object_pairs_hook=pairs, parse_float=finite_float, parse_constant=invalid_constant)


# Records resolves this private helper module's parser dynamically; install the
# stricter bounded parser there too, so unused numeric fields cannot be infinite.
s.read_json = read_json


def validate_manifest(raw, manifest, synthetic=False):
    """Validate the fixed candidate order and geometry in saved annotations."""
    s.require(type(manifest) is dict and manifest.get('schema') == 'vision-coco-cls-occlusion-cases-v1',
              'manifest schema differs')
    if synthetic:
        s.require(manifest.get('fabricated') is True, 'synthetic manifest marker')
    else:
        s.require(manifest.get('fabricated') is not True and s.sha(raw) == MANIFEST_SHA256,
                  'fixed manifest differs')
    images = manifest.get('images')
    # Reuse the independently reviewed geometry/type checks, but use this
    # experiment's separate fixed rank domain rather than the earlier one.
    s.validate_images(images, synthetic=True)
    for index, image in enumerate(images):
        s.require(s.typed_equal(s.geometry(image), image.get('occlusion_geometry')), 'fixed geometry differs')
        if synthetic:
            continue
        rank = s.sha(f"{RANK_DOMAIN}:{image['category_id']}:{image['image_id']}".encode('ascii'))
        s.require(image.get('selection_rank_sha256') == rank, 'candidate rank hash differs')
        if index % 32:
            previous = images[index - 1]
            s.require((previous['selection_rank_sha256'], previous['image_id']) < (rank, image['image_id']),
                      'candidate order differs')
    return images


def checked_screen_score(raw, saved, category):
    """Check tolerant scores and separately enforce the exact recognition gate."""
    calculated = s.screen_scoring(raw, category)
    s.require(type(saved) is dict and set(saved) == set(calculated), 'screen score fields differ')
    s.check_score(saved, {key: calculated[key]
                          for key in ('margin', 'dog_mass', 'cat_mass', 'off_mass', 'top1_id')})
    for key in ('recognized', 'reasons', 'logit_sha256'):
        s.require(s.typed_equal(saved[key], calculated[key]), 'screen decision or hash differs')
    s.require(s.reported_screen_gate(saved, category) == (calculated['recognized'], calculated['reasons']),
              'reported screen scores contradict recognition')
    return calculated


def log_group_probability(raw, category):
    z = s.values(raw)
    s.require(len(z) == 1000 and category in (17, 18), 'logit vector or category differs')
    group = z[281:286] if category == 17 else z[151:269]
    group_max, all_max = max(group), max(z)
    return ((group_max - all_max) + math.log(math.fsum(math.exp(x - group_max) for x in group)) -
            math.log(math.fsum(math.exp(x - all_max) for x in z)))


def checked_response_pair(clean, animal, background, saved, category):
    """Check the mask drops and preserve the inclusive raw/reported gate."""
    base = log_group_probability(clean, category)
    drops = {'animal_drop': base - log_group_probability(animal, category),
             'background_drop': base - log_group_probability(background, category)}
    s.require(type(saved) is dict, 'missing mask record')
    for name, value in drops.items():
        s.close(saved.get(name), value, 'mask drop differs')
    observed = drops['animal_drop'] - drops['background_drop']
    reported = saved['animal_drop'] - saved['background_drop']
    s.require(math.isfinite(observed) and math.isfinite(reported) and
              (observed >= .05) == (reported >= .05), 'reported mask contrast contradicts eligibility')
    return drops


def select(images, scores, masked):
    """Rebuild all 64 dispositions and first-four qualifying IDs/species."""
    s.require(type(images) is list and type(scores) is list and len(images) == len(scores) == 64 and
              type(masked) is dict, 'response screen inventory differs')
    expected = set()
    for image, score in zip(images, scores):
        s.require(type(image) is dict and type(score) is dict and
                  type(image.get('image_id')) is int and type(score.get('image_id')) is int and
                  image['image_id'] == score['image_id'] and type(score.get('recognized')) is bool,
                  'screen image or recognition differs')
        if score['recognized'] and image.get('occlusion_geometry') is not None:
            expected.add(image['image_id'])
    s.require(len({image['image_id'] for image in images}) == 64, 'duplicate screen image identity')
    s.require(set(masked) == expected, 'mask inventory differs')
    selected, counts, rows = [], {}, []
    for category, species in ((17, 'cat'), (18, 'dog')):
        subset = [(image, score) for image, score in zip(images, scores) if image.get('category_id') == category]
        s.require(len(subset) == 32 and [image['rank'] for image, _ in subset] == list(range(32)),
                  'species or rank inventory differs')
        eligible = []
        for image, score in subset:
            ident, reasons = image['image_id'], []
            if image.get('occlusion_geometry') is None:
                reasons.append('geometry')
            if not score['recognized']:
                reasons.append('recognition')
            contrast = None
            if ident in expected:
                pair = masked[ident]
                s.require(type(pair) is dict and all(type(pair.get(key)) in (int, float) and
                          math.isfinite(pair[key]) for key in ('animal_drop', 'background_drop')),
                          'mask drop differs')
                contrast = pair['animal_drop'] - pair['background_drop']
                s.require(math.isfinite(contrast), 'nonfinite mask contrast')
                if contrast < .05:
                    reasons.append('occlusion-contrast')
                else:
                    eligible.append(image)
            rows.append({'image_id': ident, 'category_id': category, 'reasons': reasons,
                         'occlusion_contrast': contrast})
        selected.extend(eligible[:4])
        counts[species] = {'candidates': 32,
                           'geometry_qualified': sum(image.get('occlusion_geometry') is not None for image, _ in subset),
                           'recognized': sum(score['recognized'] for _, score in subset),
                           'recognized_geometry': sum(image['image_id'] in expected for image, _ in subset),
                           'response_eligible': len(eligible), 'selected': min(4, len(eligible))}
    s.require(len(rows) == 64, 'unknown species')
    return selected, counts, rows


def mask_bits(clean, position):
    """Reconstruct the chosen processed-image block and untouched bits."""
    s.require(len(clean) == PIXEL_BYTES and type(position) is list and len(position) == 2 and
              all(type(v) is int and 0 <= v <= 12 for v in position), 'mask geometry differs')
    result = bytearray(clean)
    r, c = position
    for channel in range(3):
        for y in range(16 * r, 16 * (r + 2)):
            start = 4 * ((channel * 224 + y) * 224 + 16 * c)
            result[start:start + 128] = bytes(128)
    return bytes(result)


def check_pixels(image, pixels, saved):
    s.require(type(pixels) is dict and set(pixels) == {'clean', 'animal', 'background'} and
              all(type(value) is bytes and len(value) == PIXEL_BYTES for value in pixels.values()) and
              s.sha(pixels['clean']) == image['pixel_sha256'] and
              s.typed_equal(saved.get('input_sha256'), {name: s.sha(value) for name, value in pixels.items()}),
              'screen input hashes differ')
    s.values(pixels['clean'])
    for site in ('animal', 'background'):
        s.require(pixels[site] == mask_bits(pixels['clean'], image['occlusion_geometry'][site]['row_col']),
                  'masked pixels or untouched bits differ')


def check_observer(path, start, terminal_raw):
    raw, receipt = s.read_json(path)
    s.require(receipt.get('schema') == 'vision-cls-occlusion-v1-screen-direct-observer' and
              receipt.get('mode') == 'screen' and receipt.get('status') == 'complete' and
              receipt.get('source_revision') == start['source']['revision'] and
              type(receipt.get('exit_code')) is int and receipt['exit_code'] == 0 and
              receipt.get('reaped') is True and receipt.get('timed_out') is False and
              receipt.get('forced_stop') is False and 'error_type' in receipt and receipt['error_type'] is None and
              receipt.get('terminal_sha256') == s.sha(terminal_raw), 'screen observer differs')
    return s.sha(raw)


def check_archive(path, data, expected):
    """Stream the bounded public archive and verify every saved member."""
    s.require(path.is_file() and not path.is_symlink() and 0 < path.stat().st_size <= 200_000_000,
              'screen archive size or path differs')
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while True:
            piece = stream.read(1_000_000)
            if not piece:
                break
            digest.update(piece)
    with zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        s.require(len(entries) == len(expected) and {x.filename for x in entries} == expected,
                  'screen archive inventory differs')
        for entry in entries:
            s.require(entry.file_size <= 1_000_000 and
                      archive.read(entry) == s.bounded_read(data / entry.filename, 1_000_000),
                      'screen archive member differs')
    return digest.hexdigest()


def audit_screen(manifest_path, data, public_result, archive_path, observer_path, expected_revision, *, synthetic=False):
    """Recompute all clean scores, applicable masks, response ranks and saved hashes."""
    s.require_nearest_rounding()
    manifest_raw, manifest = s.read_json(manifest_path, 5_000_000)
    images = validate_manifest(manifest_raw, manifest, synthetic)
    data = Path(data)
    start_raw, start = s.read_json(data / 'started.json')
    terminal_raw, terminal = s.read_json(data / 'terminal.json', 5_000_000)
    source = start.get('source')
    s.require(type(expected_revision) is str and re.fullmatch('[0-9a-f]{40}', expected_revision) is not None and
              type(source) is dict and type(source.get('revision')) is str and
              re.fullmatch('[0-9a-f]{40}', source['revision']) is not None and
              source['revision'] == expected_revision and
              terminal.get('source_revision') == source['revision'] and
              start.get('schema') == 'vision-cls-occlusion-v1-screen-start' and start.get('mode') == 'screen' and
              terminal.get('schema') == 'vision-cls-occlusion-v1-screen-terminal' and
              terminal.get('mode') == 'screen' and terminal.get('status') == 'complete' and
              start.get('manifest_sha256') == s.sha(manifest_raw) == terminal.get('manifest_sha256') and
              s.typed_equal(start.get('runtime'), terminal.get('runtime')) and
              start.get('model_state_sha256') == terminal.get('model_state_sha256_before_after') and
              s.typed_equal(start.get('image_ids'), [x['image_id'] for x in images]) and
              not (data / 'failure.json').exists(), 'screen start or terminal differs')
    if not synthetic:
        s.require(start.get('model_state_sha256') == s.MODEL_STATE and
                  start['runtime'].get('binary64_rounding') == 'nearest-even' and
                  start['runtime'].get('denormals_preserved') is True and
                  start.get('discovery_terminal_sha256') == DISCOVERY_TERMINAL and
                  start.get('discovery_archive_sha256') == DISCOVERY_ARCHIVE and
                  start.get('discovery_public_commit') == DISCOVERY_COMMIT, 'screen runtime or discovery binding differs')
    result_raw, result = s.read_json(data / 'screen-result.json', 5_000_000)
    s.require(s.bounded_read(Path(public_result), 5_000_000) == result_raw and
              result.get('schema') == 'vision-cls-occlusion-v1-screen-result' and
              result.get('manifest_sha256') == s.sha(manifest_raw) and
              terminal.get('screen_result_sha256') == s.sha(result_raw) and
              type(result.get('screen')) is list and len(result['screen']) == 64 and
              type(result.get('masked')) is dict, 'published screen result differs')
    observations, raw_by_id, hashes = [], {}, []
    for index, image in enumerate(images, 1):
        row_raw, row = s.read_json(data / f'forward-{index:03d}.json', 200_000)
        raw = s.bounded_read(data / f'forward-{index:03d}.bin', 4000)
        s.require(len(raw) == 4000 and type(row.get('submission')) is int and row['submission'] == index and
                  row.get('label') == f"screen:{image['image_id']}" and
                  row.get('file') == f'forward-{index:03d}.bin' and row.get('sha256') == s.sha(raw) and
                  row.get('dtype') == 'little-endian-float32' and
                  s.typed_equal(row.get('layout'), {'logits': {'shape': [1, 1000], 'offset': 0, 'bytes': 4000}}) and
                  s.typed_equal(row.get('metadata'), {'kind': 'screen', 'image_id': image['image_id']}),
                  'clean screen forward differs')
        calculated = checked_screen_score(raw, row.get('score'), image['category_id'])
        entry = result['screen'][index - 1]
        s.require(type(entry) is dict and type(entry.get('image_id')) is int and
                  entry['image_id'] == image['image_id'] and
                  s.typed_equal({key: value for key, value in entry.items() if key != 'image_id'}, row['score']),
                  'reported clean score differs')
        observations.append({'image_id': image['image_id'], **calculated})
        raw_by_id[image['image_id']] = raw
        hashes.append({'submission': index, 'json_sha256': s.sha(row_raw), 'binary_sha256': s.sha(raw)})

    needed = [image for image, score in zip(images, observations)
              if score['recognized'] and image['occlusion_geometry'] is not None]
    s.require(set(result['masked']) == {str(image['image_id']) for image in needed}, 'masked result inventory differs')
    count = 64 + 2 * len(needed)
    s.require(type(terminal.get('submissions')) is int and terminal['submissions'] == count and
              type(terminal.get('saved_forwards')) is int and terminal['saved_forwards'] == count,
              'screen forward count differs')
    expected = {'started.json', 'terminal.json', 'screen-result.json'} | {
        f'forward-{index:03d}.{suffix}' for index in range(1, count + 1) for suffix in ('json', 'bin')}
    expected.update(f"screen-input-{image['image_id']}-{name}.bin" for image in needed
                    for name in ('clean', 'animal', 'background'))
    s.require({path.name for path in data.iterdir()} == expected, 'screen file inventory differs')
    records = s.Records(data, count)
    records.next = 65
    raw_masks, pairs, input_by_id, logits_by_id = {}, {}, {}, {}
    for image in needed:
        ident = image['image_id']
        saved = result['masked'][str(ident)]
        s.require(type(saved) is dict, 'missing mask result')
        pixels = {name: s.bounded_read(data / f'screen-input-{ident}-{name}.bin', PIXEL_BYTES)
                  for name in ('clean', 'animal', 'background')}
        check_pixels(image, pixels, saved)
        logits = {'clean': raw_by_id[ident]}
        for site in ('animal', 'background'):
            row, tensors = records.take(f'response:{ident}:{site}_mask')
            s.expect_shapes(row, tensors, {'logits': [1, 1000], 'early': s.STATE_SHAPE, 'late': s.STATE_SHAPE})
            s.require(type(row['metadata'].get('capture_bytes')) is int and row['metadata']['capture_bytes'] == 302592 and
                      type(row['metadata'].get('source_bytes')) is int and row['metadata']['source_bytes'] == 0,
                      'mask capture bytes differ')
            s.require(all(step.get('source_capture') is None and step.get('preceding_same_site_actions') == []
                          for step in row['metadata']['steps']), 'mask capture actions differ')
            for value in tensors.values():
                s.values(value)
            s.checked_score(row, tensors)
            s.require(s.typed_equal(saved.get('scores', {}).get(site), row['score']), 'mask reported score differs')
            logits[site] = tensors['logits']
        s.require(s.typed_equal(saved.get('logit_sha256'), {site: s.sha(logits[site])
                                                            for site in ('animal', 'background')}),
                  'mask logit hashes differ')
        pairs[ident] = checked_response_pair(logits['clean'], logits['animal'], logits['background'],
                                             saved, image['category_id'])
        raw_masks[ident] = {'animal_drop': saved['animal_drop'], 'background_drop': saved['background_drop']}
        input_by_id[ident], logits_by_id[ident] = pixels, logits
    s.require(records.next == count + 1, 'mask forward order differs')
    selected, counts, rows = select(images, observations, pairs)
    reported_selected, reported_counts, reported_rows = select(images, result['screen'], raw_masks)
    ids = [x['image_id'] for x in selected]
    s.require(s.typed_equal([x['image_id'] for x in reported_selected], ids) and
              s.typed_equal(reported_counts, counts) and s.typed_equal(result.get('selected_ids'), ids) and
              s.typed_equal(result.get('counts'), counts) and s.typed_equal(result.get('rows'), reported_rows) and
              s.typed_equal(terminal.get('selected_ids'), ids) and s.typed_equal(terminal.get('counts'), counts) and
              result.get('decision') == terminal.get('decision') == ('pending' if ids else 'inconclusive'),
              'screen selection, rows or decision differs')
    for computed, reported in zip(rows, reported_rows):
        s.require(computed['image_id'] == reported['image_id'] and computed['reasons'] == reported['reasons'],
                  'reported response disposition differs')
        if computed['occlusion_contrast'] is not None:
            s.close(reported['occlusion_contrast'], computed['occlusion_contrast'], 'response contrast differs')
    archive_hash = check_archive(Path(archive_path), data, expected)
    observer_hash = check_observer(Path(observer_path), start, terminal_raw)
    s.require_nearest_rounding()
    return {'manifest_sha256': s.sha(manifest_raw), 'start': start, 'start_sha256': s.sha(start_raw),
            'terminal_sha256': s.sha(terminal_raw), 'result_sha256': s.sha(result_raw),
            'archive_sha256': archive_hash, 'observer_sha256': observer_hash, 'selected': selected,
            'counts': counts, 'scores': observations, 'rows': rows, 'mask_drops': pairs,
            'screen_forward_hashes': hashes + records.hashes,
            'input_by_id': input_by_id, 'logits_by_id': logits_by_id}


def check_initials(data, screen, forward_count):
    """Bind every selected clean/masked input and logit before any patch.

    The caller must separately validate the later phase's envelope and remaining
    intervention schedule; this routine checks just the ordered initial prefix.
    """
    data = Path(data)
    images = screen['selected']
    s.require(type(forward_count) is int and 3 * len(images) <= forward_count <= 184,
              'evaluation forward count differs')
    records, checked = s.Records(data, forward_count), []
    for image in images:
        ident = image['image_id']
        for name in ('clean', 'animal', 'background'):
            pixel = s.bounded_read(data / f'initial-input-{ident}-{name}.bin', PIXEL_BYTES)
            s.require(pixel == screen['input_by_id'][ident][name], 'cross-phase input bytes differ')
            row, tensors = records.take(f'initial:{ident}:{name}')
            s.expect_shapes(row, tensors, {'logits': [1, 1000], 'early': s.STATE_SHAPE, 'late': s.STATE_SHAPE})
            s.require(type(row['metadata'].get('capture_bytes')) is int and row['metadata']['capture_bytes'] == 302592 and
                      type(row['metadata'].get('source_bytes')) is int and row['metadata']['source_bytes'] == 0 and
                      all(step.get('source_capture') is None and step.get('preceding_same_site_actions') == []
                          for step in row['metadata']['steps']), 'initial capture metadata differs')
            for value in tensors.values():
                s.values(value)
            s.checked_score(row, tensors)
            s.require(tensors['logits'] == screen['logits_by_id'][ident][name], 'cross-phase logits differ')
            checked.append({'image_id': ident, 'input': name, 'submission': row['submission'],
                            'pixel_sha256': s.sha(pixel), 'logit_sha256': s.sha(tensors['logits'])})
    return {'initials': checked, 'initial_forward_hashes': records.hashes, 'next_submission': records.next,
            'scope': 'Selected initial pixel and logit bytes only; phase envelope and patches need separate checks.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('manifest', 'screen-data', 'public-screen-result', 'screen-archive', 'screen-observer', 'report'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--source-revision', required=True)
    parser.add_argument('--initials-data', type=Path)
    parser.add_argument('--initial-forward-count', type=int)
    parser.add_argument('--synthetic', action='store_true')
    args = parser.parse_args()
    s.require((args.initials_data is None) == (args.initial_forward_count is None),
              'initial data and count must be provided together')
    screen = audit_screen(args.manifest, args.screen_data, args.public_screen_result, args.screen_archive,
                          args.screen_observer, args.source_revision, synthetic=args.synthetic)
    initial = None if args.initials_data is None else check_initials(args.initials_data, screen,
                                                                    args.initial_forward_count)
    report = {'schema': 'independent-vision-cls-occlusion-screen-v1', 'synthetic': args.synthetic,
              'source_revision': args.source_revision, 'manifest_sha256': screen['manifest_sha256'],
              'screen_start_sha256': screen['start_sha256'], 'screen_terminal_sha256': screen['terminal_sha256'],
              'screen_result_sha256': screen['result_sha256'], 'screen_archive_sha256': screen['archive_sha256'],
              'screen_observer_sha256': screen['observer_sha256'],
              'selected_ids': [x['image_id'] for x in screen['selected']], 'counts': screen['counts'],
              'scores': screen['scores'], 'rows': screen['rows'], 'mask_drops': screen['mask_drops'],
              'screen_forward_hashes': screen['screen_forward_hashes'], 'initial_check': initial,
              'scope': 'Quiescent saved-byte score, mask, selection and optional initial-prefix consistency only. '
                       'Source/model authenticity, execution, process tree, publication timing, preprocessing, '
                       'pretraining and population effects are not established. Optional class-label strings '
                       'are unchecked. Later phase envelope, patch landings, doses and decisions require separate audits.'}
    payload = (json.dumps(report, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()
    with args.report.open('xb') as stream:
        s.require(stream.write(payload) == len(payload), 'short report write')
    print(json.dumps({'report_sha256': s.sha(payload), 'selected': len(screen['selected']),
                      'initials_checked': 0 if initial is None else len(initial['initials'])}, sort_keys=True))


if __name__ == '__main__':
    main()
