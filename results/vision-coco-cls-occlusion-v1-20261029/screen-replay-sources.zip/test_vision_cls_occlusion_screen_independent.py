"""Fabricated-only unit checks for response selection and boundary handling."""

import copy
import hashlib
import math
import os
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import vision_cls_occlusion_screen_independent as audit


def fabricated_screen():
    images, scores, masks = [], [], {}
    for category in (17, 18):
        for rank in range(32):
            ident = category * 1000 + rank
            limit = 8 if category == 17 else 6
            geometry = None if rank == limit - 1 else {'fabricated': True}
            recognized = rank < limit
            images.append({'image_id': ident, 'category_id': category, 'rank': rank,
                           'occlusion_geometry': geometry})
            scores.append({'image_id': ident, 'recognized': recognized})
            if recognized and geometry is not None:
                contrast = math.nextafter(.05, -math.inf) if rank == 0 else (.05 if rank == 1 else .1)
                masks[ident] = {'animal_drop': contrast, 'background_drop': 0.}
    return images, scores, masks


class SelectionTests(unittest.TestCase):
    def test_nonfinite_and_duplicate_json_fields_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.json'
            for raw in (b'{"unused":1e999}', b'{"a":1,"a":2}', b'{"unused":NaN}'):
                path.write_bytes(raw)
                with self.assertRaises(ValueError):
                    audit.read_json(path)
            path.write_bytes(b'{"finite":1e308,"zero":-0.0}')
            _, value = audit.read_json(path)
            self.assertEqual(value['finite'], 1e308)
            self.assertEqual(math.copysign(1., value['zero']), -1.)

    def test_first_four_by_species_and_inclusive_contrast(self):
        images, scores, masks = fabricated_screen()
        selected, counts, rows = audit.select(images, scores, masks)
        self.assertEqual([x['image_id'] for x in selected],
                         [17001, 17002, 17003, 17004, 18001, 18002, 18003, 18004])
        self.assertEqual(counts['cat']['response_eligible'], 6)
        self.assertEqual(counts['dog']['response_eligible'], 4)
        self.assertEqual(rows[0]['reasons'], ['occlusion-contrast'])
        self.assertEqual(rows[1]['reasons'], [])
        self.assertEqual(rows[7]['reasons'], ['geometry'])
        self.assertEqual(rows[8]['reasons'], ['recognition'])

    def test_missing_or_extra_masks_rejected(self):
        images, scores, masks = fabricated_screen()
        for deleted in (True, False):
            altered = copy.deepcopy(masks)
            if deleted:
                del altered[17001]
            else:
                altered[17008] = {'animal_drop': .1, 'background_drop': 0.}
            with self.assertRaises(ValueError):
                audit.select(images, scores, altered)

    def test_nonfinite_or_boolean_drop_and_boolean_identity_rejected(self):
        images, scores, masks = fabricated_screen()
        for bad in (float('nan'), float('inf'), True):
            altered = copy.deepcopy(masks)
            altered[17001]['animal_drop'] = bad
            with self.assertRaises(ValueError):
                audit.select(images, scores, altered)
        scores[0]['image_id'] = True
        with self.assertRaises(ValueError):
            audit.select(images, scores, masks)

    def test_numeric_tolerance_does_not_cross_recognition_boundary(self):
        computed = {'margin': -1., 'dog_mass': 0., 'cat_mass': .2, 'off_mass': .8,
                    'top1_id': 281, 'recognized': True, 'reasons': [], 'logit_sha256': 'fake'}
        saved = dict(computed)
        saved['cat_mass'] = math.nextafter(.2, -math.inf)
        with mock.patch.object(audit.s, 'screen_scoring', return_value=computed):
            with self.assertRaisesRegex(ValueError, 'contradict recognition'):
                audit.checked_screen_score(b'fabricated', saved, 17)

    def test_numeric_tolerance_does_not_cross_mask_contrast_boundary(self):
        below = math.nextafter(.05, -math.inf)
        saved = {'animal_drop': below, 'background_drop': 0.}
        with mock.patch.object(audit, 'log_group_probability', side_effect=(0., -.05, 0.)):
            with self.assertRaisesRegex(ValueError, 'contrast contradicts eligibility'):
                audit.checked_response_pair(b'clean', b'animal', b'background', saved, 17)

    def test_processed_pixel_mask_changes_only_requested_rectangle(self):
        clean = b'\x00\x00\x80\x3f' * (3 * 224 * 224)
        masked = audit.mask_bits(clean, [2, 3])
        self.assertEqual(len(masked), len(clean))
        for channel in range(3):
            for y in range(224):
                start = 4 * ((channel * 224 + y) * 224)
                row = masked[start:start + 224 * 4]
                if 32 <= y < 64:
                    self.assertEqual(row[:48 * 4], clean[start:start + 48 * 4])
                    self.assertEqual(row[48 * 4:80 * 4], bytes(32 * 4))
                    self.assertEqual(row[80 * 4:], clean[start + 80 * 4:start + 224 * 4])
                else:
                    self.assertEqual(row, clean[start:start + 224 * 4])

    def test_coherently_rehashed_mask_tamper_still_rejected(self):
        clean = b'\x00\x00\x80\x3f' * (3 * 224 * 224)
        image = {'pixel_sha256': hashlib.sha256(clean).hexdigest(), 'occlusion_geometry':
                 {'animal': {'row_col': [2, 3]}, 'background': {'row_col': [8, 9]}}}
        pixels = {'clean': clean, 'animal': audit.mask_bits(clean, [2, 3]),
                  'background': audit.mask_bits(clean, [8, 9])}
        saved = {'input_sha256': {key: hashlib.sha256(value).hexdigest() for key, value in pixels.items()}}
        audit.check_pixels(image, pixels, saved)
        corrupted = bytearray(pixels['animal'])
        corrupted[0] ^= 1  # outside the animal mask
        pixels['animal'] = bytes(corrupted)
        saved['input_sha256']['animal'] = hashlib.sha256(pixels['animal']).hexdigest()
        with self.assertRaisesRegex(ValueError, 'untouched bits'):
            audit.check_pixels(image, pixels, saved)

    def test_observer_requires_typed_reaped_and_error_marker(self):
        terminal = b'fabricated terminal'
        start = {'source': {'revision': '0' * 40}}
        receipt = {'schema': 'vision-cls-occlusion-v1-screen-direct-observer', 'mode': 'screen',
                   'status': 'complete', 'source_revision': '0' * 40, 'exit_code': 0, 'reaped': True,
                   'timed_out': False, 'forced_stop': False, 'error_type': None,
                   'terminal_sha256': hashlib.sha256(terminal).hexdigest()}
        for broken in ({**receipt, 'reaped': 1}, {key: value for key, value in receipt.items() if key != 'error_type'}):
            with mock.patch.object(audit.s, 'read_json', return_value=(b'fake', broken)):
                with self.assertRaisesRegex(ValueError, 'observer differs'):
                    audit.check_observer(Path('unused'), start, terminal)


class FabricatedFixtureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        location = os.environ.get('VISION_CLS_OCCLUSION_FAKE_SCREEN')
        if not location:
            raise unittest.SkipTest('set VISION_CLS_OCCLUSION_FAKE_SCREEN for the fabricated fixture')
        cls.fixture = Path(location)
        cls.screen = audit.audit_screen(cls.fixture / 'fabricated-manifest.json', cls.fixture / 'screen-data',
                                        cls.fixture / 'screen-data/screen-result.json',
                                        cls.fixture / 'screen-evidence.zip', cls.fixture / 'screen-observer.json',
                                        '0' * 40, synthetic=True)

    def test_full_screen_and_initial_prefix(self):
        self.assertEqual(len(self.screen['selected']), 8)
        self.assertEqual(len(self.screen['screen_forward_hashes']), 80)
        initial = audit.check_initials(self.fixture / 'evaluation-initial-data', self.screen, 24)
        self.assertEqual(len(initial['initials']), 24)
        self.assertEqual(initial['next_submission'], 25)

    def test_selected_last_input_mismatch_rejected(self):
        altered = copy.deepcopy(self.screen)
        last = altered['selected'][-1]['image_id']
        altered['input_by_id'][last]['background'] = b'bad'
        with self.assertRaisesRegex(ValueError, 'cross-phase input bytes differ'):
            audit.check_initials(self.fixture / 'evaluation-initial-data', altered, 24)

    def test_selected_first_logit_mismatch_rejected(self):
        altered = copy.deepcopy(self.screen)
        first = altered['selected'][0]['image_id']
        altered['logits_by_id'][first]['clean'] = b'bad'
        with self.assertRaisesRegex(ValueError, 'cross-phase logits differ'):
            audit.check_initials(self.fixture / 'evaluation-initial-data', altered, 24)


if __name__ == '__main__':
    unittest.main()
