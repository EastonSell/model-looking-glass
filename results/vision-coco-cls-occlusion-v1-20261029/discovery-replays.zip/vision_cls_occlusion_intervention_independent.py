"""Independent saved-byte checks for the CLS/spatial occlusion comparison.

Inputs must be quiescent. This module checks saved arithmetic and bit-level
consistency; source, model execution, process exit, chronology and population
generalization are separate. The companion screen review supplies the fixed
selected images and the previously recorded clean/masked inputs and logits.
"""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path

PRIOR_HELPER_SHA = 'ca6dcf9c55491eec4abf98c54a6a2b29a9e4a73bc4fab90be0395283ed717693'
helper_path = Path(__file__).with_name('vision_occlusion_intervention_independent.py')
if hashlib.sha256(helper_path.read_bytes()).hexdigest() != PRIOR_HELPER_SHA:
    raise ValueError('fixed prior arithmetic helper differs')
spec = importlib.util.spec_from_file_location('prior_occlusion_replay', helper_path)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
s, h = prior.s, prior.helper
TOKEN_BYTES, PIXEL_BYTES = 192 * 4, 3 * 224 * 224 * 4
ACTIVE = {'cls_animal': 'cls', 'cls_background': 'cls', 'spatial_animal': 'animal',
          'spatial_background': 'background', 'random_cls': 'cls',
          'random_animal': 'animal', 'random_background': 'background'}
MANIFEST_SHA = 'a52040786557fde9e503b6b6d1246bee0cbd41106b3cd110ea6788ab13a53487'
PRIOR_MANIFEST_SHA = 'aa61b294710f5a6cd9682dc783085c7079f1addfbad8257fdbd893d143ce4cef'
PRIOR_AUDIT_SHA = 'db69cb0c4d0e93dfd578ec03e035399ca19f3b3447f6d2db7575d2034a7313b5'
PRIOR_TERMINAL_SHA = 'b15cb5c818df86746d35c62b1452e8c0f6f589adf3a17d579256d4675f779b64'
DISCOVERY_IDS = [404350, 151497, 470798, 135116]


def record(records, label, path=None, selected=None, action='capture'):
    row, tensors = records.take(label, path, selected, action)
    shapes = {'logits': [1, 1000]}
    if path is None:
        shapes.update(early=s.STATE_SHAPE, late=s.STATE_SHAPE)
    else:
        shapes.update(before_all=s.STATE_SHAPE, after_all=s.STATE_SHAPE)
        if selected is not None:
            shapes.update({f'{name}_{i}': [192] for i in range(len(selected)) for name in ('before', 'after')})
        if action == 'patch':
            shapes['requested'] = s.STATE_SHAPE if selected is None else [len(selected), 192]
    s.expect_shapes(row, tensors, shapes)
    s.require(type(row['metadata'].get('capture_bytes')) is int and
              row['metadata']['capture_bytes'] == sum(len(v) for k, v in tensors.items()
                                                        if k not in ('logits', 'requested')) and
              type(row['metadata'].get('source_bytes')) is int and
              row['metadata']['source_bytes'] == len(tensors.get('requested', b'')), 'capture/source byte counts')
    for value in tensors.values():
        s.values(value)
    return row, tensors


def patch(records, label, path, selected, action, before, replacement, expected_logits, reference):
    row, data = record(records, label, path, selected, action)
    s.require(data['before_all'] == before, 'patch pre-state differs')
    if action == 'patch':
        s.require(data['requested'] == replacement, 'requested bits differ')
    if selected is None:
        s.require(data['after_all'] == (before if action == 'null' else replacement), 'full-state landing')
    else:
        delivered = h.block(before, selected) if action == 'null' else replacement
        altered = bytearray(before)
        for index, token in enumerate(selected):
            lo, hi = token * TOKEN_BYTES, (token + 1) * TOKEN_BYTES
            value = delivered[index * TOKEN_BYTES:(index + 1) * TOKEN_BYTES]
            s.require(data[f'before_{index}'] == before[lo:hi] and data[f'after_{index}'] == value,
                      'per-token witness differs')
            altered[lo:hi] = value
        s.require(data['after_all'] == altered, 'landing or untouched tokens differ')
    if expected_logits is not None:
        s.require(data['logits'] == expected_logits, 'control logits differ')
    score, _ = s.checked_score(row, data, reference)
    return score, data


def dose_plan(clean, masked_animal, masked_background, image, saved):
    geom = image['occlusion_geometry']
    ids = {'cls': [0], 'animal': geom['animal']['token_ids'], 'background': geom['background']['token_ids']}
    own = {name: h.block(clean, selected) for name, selected in ids.items()}
    donor = {'cls_animal': h.block(masked_animal, [0]), 'cls_background': h.block(masked_background, [0]),
             'spatial_animal': h.block(masked_animal, ids['animal']),
             'spatial_background': h.block(masked_background, ids['background'])}
    norms = {name: h.distance(raw, bytes(len(raw))) for name, raw in own.items()}
    distances = {name: h.distance(own[ACTIVE[name]], raw) for name, raw in donor.items()}
    h.compare_nested(saved.get('receiver_norms'), norms, 'receiver norms')
    h.compare_nested(saved.get('donor_distances'), distances, 'donor distances')
    for section in ('receiver_norms', 'donor_distances'):
        s.require(all(type(v) in (int, float) and math.isfinite(v) and v >= 0
                      for v in saved[section].values()), 'negative or nonfinite reported norm')
    def reasons(ns, ds):
        return ([key + '-receiver-norm' for key in ('cls', 'animal', 'background') if ns[key] <= 1e-6] +
                [key + '-donor-distance' for key in ('cls_animal', 'cls_background', 'spatial_animal',
                                                     'spatial_background') if ds[key] <= 1e-6])
    why = reasons(norms, distances)
    s.require(why == reasons(saved['receiver_norms'], saved['donor_distances']), 'reported eligibility boundary')
    if why:
        s.require(saved.get('status') == 'dose-ineligible' and saved.get('reasons') == why, 'ineligible dose')
        return 'dose-ineligible', {}, norms
    q = min(*(.196 * v for v in norms.values()), *distances.values())
    rq = min(*(.196 * v for v in saved['receiver_norms'].values()), *saved['donor_distances'].values())
    s.close(saved.get('q'), q, 'q differs')
    s.require(saved['q'] == rq and (q <= 1e-6) == (rq <= 1e-6), 'reported q boundary')
    if q <= 1e-6:
        s.require(saved.get('status') == 'dose-ineligible' and saved.get('reasons') == ['q'], 'small q')
        return 'dose-ineligible', {}, norms
    replacements = {}
    for name, other in donor.items():
        a, b = s.values(own[ACTIVE[name]]), s.values(other)
        replacements[name] = h.encode([x + (q / distances[name]) * (y - x) for x, y in zip(a, b)])
    for site, raw in own.items():
        label = 'cls' if site == 'cls' else 'spatial'
        values = s.values(raw)
        signs = [1.0 if hashlib.sha256(f"vision-coco-cls-occlusion-v1:{image['image_id']}:{label}:{i}".encode('ascii')).digest()[0] & 1
                 else -1.0 for i in range(len(values))]
        replacements['random_' + site] = h.encode([x + q / math.sqrt(len(values)) * sign
                                                    for x, sign in zip(values, signs)])
    planned = {name: h.distance(own[ACTIVE[name]], value) for name, value in replacements.items()}
    h.compare_nested(saved.get('planned_norms'), planned, 'planned norms')
    h.compare_nested(saved.get('donor_scales'), {name: q / value for name, value in distances.items()}, 'donor scales')
    s.require(all(type(v) in (int, float) and math.isfinite(v) and v >= 0
                  for v in saved['planned_norms'].values()), 'invalid reported planned norm')
    tolerance = min(max(1e-5, 1e-5 * q), .01 * q)
    s.close(saved.get('tolerance'), tolerance, 'dose tolerance')
    s.require(saved['tolerance'] == min(max(1e-5, 1e-5 * rq), .01 * rq), 'reported tolerance')
    def mismatch(q0, tol, ns, delivered):
        reference = delivered['cls_animal']
        for name in ACTIVE:
            value = delivered[name]
            if value <= 0 or abs(value - q0) > tol or value > .2 * ns[ACTIVE[name]] or abs(value-reference) > .01*reference:
                return name + '-rounded-delivery'
        return None
    why = mismatch(q, tolerance, norms, planned)
    s.require(why == mismatch(rq, saved['tolerance'], saved['receiver_norms'], saved['planned_norms']),
              'reported matchability boundary')
    if why:
        s.require(saved.get('status') == 'dose-unmatchable' and saved.get('reasons') == [why], 'unmatchable dose')
        return 'dose-unmatchable', {}, norms
    limited = any(q / v < .02 for v in norms.values())
    s.require(limited == any(rq / v < .02 for v in saved['receiver_norms'].values()), 'reported limited-dose boundary')
    status = 'limited-dose' if limited else 'matchable'
    s.require(saved.get('status') == status and saved.get('reasons') == [], 'dose status')
    return status, replacements, norms


def initial_records(records, data, images, expected_inputs, expected_logits, synthetic=False):
    """Check all clean/masked pixels and logits before consuming any patch."""
    result = {}
    for image in images:
        ident = image['image_id']
        s.require(prior.geometry(image) == image.get('occlusion_geometry'), 'initial geometry')
        pixels, states = {}, {}
        for name in ('clean', 'animal', 'background'):
            raw = s.bounded_read(data / f'initial-input-{ident}-{name}.bin', PIXEL_BYTES)
            s.require(len(raw) == PIXEL_BYTES and raw == expected_inputs[ident][name], 'initial input mismatch')
            s.values(raw)
            pixels[name] = raw
            row, tensors = record(records, f'initial:{ident}:{name}')
            s.require(tensors['logits'] == expected_logits[ident][name], 'initial logits mismatch')
            score, _ = s.checked_score(row, tensors)
            states[name] = (row, tensors, score)
        if not synthetic:
            s.require(s.sha(pixels['clean']) == image['pixel_sha256'], 'manifest pixel identity')
        for site in ('animal', 'background'):
            rr, cc = image['occlusion_geometry'][site]['row_col']
            expected = bytearray(pixels['clean'])
            for channel in range(3):
                for y in range(16 * rr, 16 * (rr + 2)):
                    pos = ((channel * 224 + y) * 224 + 16 * cc) * 4
                    expected[pos:pos + 32 * 4] = bytes(32 * 4)
            s.require(pixels[site] == expected, 'mask or untouched pixel bits')
        result[ident] = states
    return result


def decision(c):
    return (c['occlusion_contrast'] >= .05 and c['cls_contrast'] >= .025 and
            c['cls_contrast'] - max(abs(c['random_cls']), abs(c['random_animal']),
                                    abs(c['random_background'])) >= .025 and
            c['residual_advantage'] >= .025)


def case_replay(records, image, saved, initial):
    ident, category, geom = image['image_id'], image['category_id'], image['occlusion_geometry']
    s.require(prior.geometry(image) == geom and saved.get('image_id') == ident and
              saved.get('category_id') == category and s.typed_equal(saved.get('geometry'), geom), 'case identity')
    clean = initial['clean'][1]
    masked = {name: initial[name][1] for name in ('animal', 'background')}
    baseline, reference = s.checked_score(initial['clean'][0], clean)
    s.check_score(saved['baseline'], baseline)
    base_logp = prior.log_group(clean['logits'], category)
    s.close(saved['baseline_log_probability'], base_logp, 'baseline group probability')
    conditions, drops = saved['conditions'], {}
    for name in ('animal', 'background'):
        score, _ = s.summarize(masked[name]['logits'], reference)
        drops[name + '_mask'] = prior.compare_condition(conditions[name + '_mask'], score, clean['logits'],
                                                        masked[name]['logits'], category, base_logp)
    status, replacements, _ = dose_plan(clean['early'], masked['animal']['early'],
                                         masked['background']['early'], image, saved['dose'])
    prefix = f'case-{ident}:'
    row, repeated = record(records, prefix + 'repeat')
    s.require(all(repeated[k] == clean[k] for k in ('logits', 'early', 'late')), 'repeat differs')
    score, _ = s.checked_score(row, repeated, reference)
    drops['repeat'] = prior.compare_condition(conditions['repeat'], score, clean['logits'], repeated['logits'], category, base_logp)
    ids = {'cls': [0], 'animal': geom['animal']['token_ids'], 'background': geom['background']['token_ids']}
    plans = []
    for name, selected in ids.items():
        plans.extend([(name + '_null', s.EARLY, selected, 'null', clean['early'], None, clean['logits']),
                      (name + '_self', s.EARLY, selected, 'patch', clean['early'], h.block(clean['early'], selected), clean['logits'])])
    plans.append(('full_self', s.EARLY, None, 'patch', clean['early'], clean['early'], clean['logits']))
    for site in ('animal', 'background'):
        plans.append((site + '_full', s.EARLY, None, 'patch', clean['early'], masked[site]['early'], masked[site]['logits']))
    if status in ('matchable', 'limited-dose'):
        for name, site in ACTIVE.items():
            plans.append((name, s.EARLY, ids[site], 'patch', clean['early'], replacements[name], None))
    for site in ('animal', 'background'):
        plans.append((site + '_final', s.LATE, ids[site], 'patch', clean['late'],
                      h.block(masked[site]['late'], ids[site]), clean['logits']))
    actual = {}
    for name, path, selected, action, before, replacement, expected in plans:
        score, values = patch(records, prefix + name, path, selected, action, before, replacement, expected, reference)
        drops[name] = prior.compare_condition(conditions[name], score, clean['logits'], values['logits'], category, base_logp)
        if name not in ACTIVE:
            continue
        pre, post = h.block(values['before_all'], selected), h.block(values['after_all'], selected)
        actual[name], norm = h.distance(pre, post), h.distance(pre, bytes(len(pre)))
        item = conditions[name]
        token_norms = [h.distance(pre[i*TOKEN_BYTES:(i+1)*TOKEN_BYTES], post[i*TOKEN_BYTES:(i+1)*TOKEN_BYTES])
                       for i in range(len(selected))]
        s.require(type(item.get('token_doses')) is list and len(item['token_doses']) == len(selected) and
                  all(type(x) in (int, float) and math.isfinite(x) and x >= 0 for x in item['token_doses']) and
                  type(item.get('realized_over_receiver_norm')) in (int, float) and
                  math.isfinite(item['realized_over_receiver_norm']) and item['realized_over_receiver_norm'] > 0,
                  'invalid per-token or relative dose')
        for key, value in (('actual_dose', actual[name]), ('receiver_norm', norm),
                           ('realized_over_receiver_norm', actual[name] / norm)):
            s.close(item.get(key), value, 'actual dose field')
        h.compare_nested(item['token_doses'], token_norms, 'per-token dose')
        for dose, q, tol, receiver, ref in ((actual[name], saved['dose']['q'], saved['dose']['tolerance'], norm,
                                             actual['cls_animal']),
                                            (item['actual_dose'], saved['dose']['q'], saved['dose']['tolerance'],
                                             item['receiver_norm'], conditions['cls_animal']['actual_dose'])):
            s.require(dose > 0 and receiver > 0 and abs(dose-q) <= tol and dose <= .2*receiver and
                      abs(dose-ref) <= .01*ref, 'actual dose bound or matching')
    row, end = record(records, prefix + 'post_clean')
    s.require(all(end[k] == clean[k] for k in ('logits', 'early', 'late')), 'post-clean differs')
    score, _ = s.checked_score(row, end, reference)
    drops['post_clean'] = prior.compare_condition(conditions['post_clean'], score, clean['logits'], end['logits'], category, base_logp)
    s.require(set(conditions) == set(drops), 'condition inventory differs')
    def comparisons(d):
        b = d['animal_mask'] - d['background_mask']
        out = {'occlusion_contrast': b}
        if status in ('matchable', 'limited-dose'):
            tc, ts = d['cls_animal'] - d['cls_background'], d['spatial_animal'] - d['spatial_background']
            out.update(cls_contrast=tc, spatial_contrast=ts, raw_site_difference=tc-ts,
                       cls_residual=abs(b-tc), spatial_residual=abs(b-ts), residual_advantage=abs(b-ts)-abs(b-tc),
                       random_cls=d['random_cls'], random_animal=d['random_animal'], random_background=d['random_background'])
            out['positive'] = decision(out)
        return out
    computed, reported = comparisons(drops), comparisons({name: conditions[name]['drop'] for name in drops})
    h.compare_nested(saved['comparisons'], computed, 'comparison')
    for name, value in reported.items():
        s.require(s.typed_equal(saved['comparisons'].get(name), value), 'reported comparison arithmetic')
    s.require(computed.get('positive') == reported.get('positive'), 'decision boundary')
    return {'image_id': ident, 'category_id': category, 'dose_status': status, 'comparisons': computed}


def prior_reference(manifest_path, audit_path, data, *, synthetic=False):
    """Reconstruct discovery selection and its audited previous input/logit bytes."""
    manifest_raw, manifest = s.read_json(manifest_path)
    audit_raw, audit = s.read_json(audit_path)
    if not synthetic:
        s.require(s.sha(manifest_raw) == PRIOR_MANIFEST_SHA and s.sha(audit_raw) == PRIOR_AUDIT_SHA,
                  'prior public manifest or audit differs')
    else:
        s.require(manifest.get('fabricated') is True, 'synthetic prior marker')
    result = audit['result']
    s.require(audit.get('schema') == 'vision-occlusion-independent-intervention-audit-v1' and
              result.get('mode') == 'evaluation' and result.get('manifest_sha256') == s.sha(manifest_raw),
              'prior audit identity')
    if not synthetic:
        s.require(audit.get('synthetic') is False and result.get('phase_terminal_sha256') == PRIOR_TERMINAL_SHA,
                  'prior audit terminal')
    lookup = {row['image_id']: row for row in manifest['images']}
    s.require(len(lookup) == len(manifest['images']), 'prior manifest duplicate identity')
    chosen = []
    for category in (17, 18):
        candidates = []
        for case in result['cases']:
            if case.get('category_id') != category:
                continue
            ident, b = case['image_id'], case['comparisons']['occlusion_contrast']
            s.require(type(ident) is int and type(b) in (int, float) and math.isfinite(b) and
                      ident in lookup and lookup[ident]['category_id'] == category and
                      prior.geometry(lookup[ident]) == lookup[ident]['occlusion_geometry'], 'prior candidate')
            candidates.append((-b, ident))
        s.require(len(candidates) >= 2, 'insufficient prior candidates')
        chosen.extend(lookup[ident] for _, ident in sorted(candidates)[:2])
    ids = [row['image_id'] for row in chosen]
    s.require(len(ids) == len(set(ids)) == 4 and (synthetic or ids == DISCOVERY_IDS), 'prior discovery selection')
    start_raw, _ = s.read_json(data / 'started.json')
    terminal_raw, terminal = s.read_json(data / 'terminal.json')
    s.require(s.sha(start_raw) == result.get('phase_start_sha256') and
              s.sha(terminal_raw) == result.get('phase_terminal_sha256') and
              terminal.get('mode') == 'evaluation' and terminal.get('status') == 'complete', 'prior records')
    case_by_id = {row['image_id']: row for row in terminal['cases']}
    s.require(len(case_by_id) == len(terminal['cases']), 'prior case identities')
    inputs, logits, needed = {}, {}, {}
    for image in chosen:
        ident = image['image_id']
        _, case = s.read_json(data / f'case-{ident}.json')
        s.require(s.typed_equal(case, case_by_id[ident]) and case['category_id'] == image['category_id'], 'prior case')
        prior.check_pixels(data, image, case, synthetic)
        inputs[ident] = {name: s.bounded_read(data / f'input-{ident}-{name}.bin', PIXEL_BYTES)
                         for name in ('clean', 'animal', 'background')}
        logits[ident] = {}
        for name in ('clean', 'animal', 'background'):
            label = f'case-{ident}:' + ('clean' if name == 'clean' else name + '_mask')
            needed[label] = (ident, name)
    hashes = result['forward_hashes']
    s.require(type(result.get('forwards')) is int and type(hashes) is list and len(hashes) == result['forwards'],
              'prior forward count')
    for index, expected in enumerate(hashes, 1):
        raw, row = s.read_json(data / f'forward-{index:03d}.json', 200_000)
        s.require(type(expected.get('submission')) is int and expected['submission'] == index and
                  s.sha(raw) == expected.get('json_sha256'), 'prior forward metadata')
        if row.get('label') not in needed:
            continue
        ident, name = needed.pop(row['label'])
        tensor = s.bounded_read(data / f'forward-{index:03d}.bin', 1_000_000)
        s.require(4000 <= len(tensor) <= 1_000_000 and s.sha(tensor) == expected.get('binary_sha256') and
                  row.get('sha256') == s.sha(tensor) and type(row.get('submission')) is int and
                  row['submission'] == index and row.get('file') == f'forward-{index:03d}.bin' and
                  row.get('dtype') == 'little-endian-float32' and row.get('layout', {}).get('logits') ==
                  {'shape': [1, 1000], 'offset': 0, 'bytes': 4000}, 'prior forward tensor')
        s.values(tensor[:4000])
        logits[ident][name] = tensor[:4000]
    s.require(not needed and all(set(row) == {'clean', 'animal', 'background'} for row in logits.values()),
              'prior selected forward inventory')
    return chosen, inputs, logits, s.sha(audit_raw), s.sha(terminal_raw)


def audit_discovery(manifest_path, prior_manifest, prior_audit, prior_data, data, *, synthetic=False):
    s.require_nearest_rounding()
    raw, manifest = s.read_json(manifest_path)
    if synthetic:
        s.require(manifest.get('fabricated') is True, 'synthetic manifest marker')
    else:
        s.require(s.sha(raw) == MANIFEST_SHA, 'fixed fresh manifest differs')
    images, inputs, logits, audit_sha, prior_terminal_sha = prior_reference(
        prior_manifest, prior_audit, prior_data, synthetic=synthetic)
    start_raw, start = s.read_json(data / 'started.json')
    terminal_raw, terminal = s.read_json(data / 'terminal.json')
    prior.source_revision(start, terminal)
    ids = [row['image_id'] for row in images]
    s.require(start.get('schema') == 'vision-cls-occlusion-v1-start' and start.get('mode') == 'discovery' and
              terminal.get('schema') == 'vision-cls-occlusion-v1-terminal' and terminal.get('mode') == 'discovery' and
              terminal.get('status') == 'complete' and start.get('manifest_sha256') == s.sha(raw) and
              terminal.get('manifest_sha256') == s.sha(raw) and start.get('runtime') == terminal.get('runtime') and
              start.get('model_state_sha256') == terminal.get('model_state_sha256_before_after') and
              start.get('prior_audit_sha256') == audit_sha and start.get('prior_terminal_sha256') == prior_terminal_sha and
              start.get('selected_ids') == ids and type(terminal.get('selected')) is int and terminal['selected'] == len(ids),
              'discovery start/terminal identity')
    if not synthetic:
        s.require(start.get('model_state_sha256') == s.MODEL_STATE, 'model-state claim')
    count, submissions = terminal.get('saved_forwards'), terminal.get('submissions')
    s.require(type(count) is int and type(submissions) is int and 0 <= count <= 92 and submissions == count,
              'discovery forward count')
    cases = terminal.get('cases')
    s.require(type(cases) is list and [row.get('image_id') for row in cases] == ids, 'discovery cases')
    files = {'started.json', 'terminal.json'} | {f'forward-{i:03d}.{ext}' for i in range(1, count+1)
                                                   for ext in ('json', 'bin')}
    for ident in ids:
        files.add(f'case-{ident}.json')
        files.update(f'initial-input-{ident}-{name}.bin' for name in ('clean', 'animal', 'background'))
    s.require({path.name for path in data.iterdir()} == files, 'discovery file inventory')
    records = s.Records(data, count)
    initial = initial_records(records, data, images, inputs, logits, synthetic)
    checked = []
    for image, case in zip(images, cases):
        _, stored = s.read_json(data / f"case-{image['image_id']}.json")
        s.require(s.typed_equal(stored, case), 'case/terminal mismatch')
        checked.append(case_replay(records, image, stored, initial[image['image_id']]))
    s.require(records.next == count + 1, 'missing or unexpected discovery forward')
    s.require_nearest_rounding()
    return {'manifest_sha256': s.sha(raw), 'phase_start_sha256': s.sha(start_raw),
            'phase_terminal_sha256': s.sha(terminal_raw), 'prior_audit_sha256': audit_sha,
            'prior_terminal_sha256': prior_terminal_sha, 'selected': ids, 'forwards': count,
            'cases': checked, 'forward_hashes': records.hashes}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('manifest', 'prior-manifest', 'prior-audit', 'prior-data', 'data', 'report'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--synthetic', action='store_true')
    args = parser.parse_args()
    result = audit_discovery(args.manifest, args.prior_manifest, args.prior_audit, args.prior_data, args.data,
                             synthetic=args.synthetic)
    report = {'schema': 'vision-cls-occlusion-independent-discovery-audit-v1', 'synthetic': args.synthetic,
              'result': result, 'scope': 'Quiescent saved-byte and arithmetic consistency only; no execution, '
              'source, chronology, process-tree, pretraining, causal mediation or population attestation.'}
    raw = (json.dumps(report, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()
    with args.report.open('xb') as stream:
        s.require(stream.write(raw) == len(raw), 'short report write')
    print(json.dumps({'report_sha256': s.sha(raw), 'forwards': result['forwards'], 'cases': result['cases']}, sort_keys=True))


if __name__ == '__main__':
    main()
