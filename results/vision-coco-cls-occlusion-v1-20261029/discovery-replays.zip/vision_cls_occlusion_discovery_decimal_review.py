"""Independently recompute discovery log-probability drops from saved bits."""
from decimal import Decimal, localcontext
import hashlib
import json
import math
from pathlib import Path
import struct

DATA = Path('E:/Codex/model-looking-glass/work/vision-cls-occlusion-v1-run-01/discovery/data')
AUDIT = Path('E:/Codex/model-looking-glass/work/vision-cls-occlusion-v1-discovery-independent-audit-v1.json')
OUTPUT = Path('E:/Codex/model-looking-glass/work/vision-cls-occlusion-v1-discovery-decimal-review-v1.json')


def require(value, message):
    if not value:
        raise ValueError(message)


def vector(raw):
    require(len(raw) == 4000, 'logit byte count')
    result = []
    for (word,) in struct.iter_unpack('<I', raw):
        exponent, fraction = (word >> 23) & 255, word & 0x7fffff
        require(exponent != 255, 'nonfinite logit')
        mantissa = fraction if exponent == 0 else (1 << 23) | fraction
        value = Decimal(mantissa) * (Decimal(2) ** (-149 if exponent == 0 else exponent - 150))
        result.append(-value if word & 0x80000000 else value)
    return result


def log_group(raw, category):
    z = vector(raw)
    group = z[281:286] if category == 17 else z[151:269]
    maximum, gm = max(z), max(group)
    return ((gm - maximum) + sum((x-gm).exp() for x in group).ln()
            - sum((x-maximum).exp() for x in z).ln())


def main():
    report_raw = AUDIT.read_bytes()
    require(hashlib.sha256(report_raw).hexdigest() ==
            '74d8402dabf55eb5aead79dccfd36f805765834fbd69d0dd870f194620f04561', 'audit digest')
    audit = json.loads(report_raw)['result']
    count = audit['forwards']
    records = {}
    for index in range(1, count+1):
        row = json.loads((DATA/f'forward-{index:03d}.json').read_bytes())
        raw = (DATA/f'forward-{index:03d}.bin').read_bytes()
        require(row['submission'] == index and row['sha256'] == hashlib.sha256(raw).hexdigest(), 'saved forward')
        require(row['label'] not in records, 'duplicate forward label')
        records[row['label']] = raw[:4000]
    output, max_error = [], 0.0
    with localcontext() as context:
        context.prec = 60
        for checked in audit['cases']:
            ident, category = checked['image_id'], checked['category_id']
            saved = json.loads((DATA/f'case-{ident}.json').read_bytes())
            clean = records[f'initial:{ident}:clean']
            clean_logp = log_group(clean, category)
            labels = {'animal_mask':f'initial:{ident}:animal', 'background_mask':f'initial:{ident}:background'}
            for name in ('cls_animal','cls_background','spatial_animal','spatial_background',
                         'random_cls','random_animal','random_background'):
                labels[name] = f'case-{ident}:{name}'
            drops = {name: float(clean_logp-log_group(records[label], category)) for name,label in labels.items()}
            for name, value in drops.items():
                error = abs(value-saved['conditions'][name]['drop'])
                max_error = max(max_error,error)
                require(error <= 1e-12, 'saved drop differs')
            b = drops['animal_mask']-drops['background_mask']
            cls = drops['cls_animal']-drops['cls_background']
            spatial = drops['spatial_animal']-drops['spatial_background']
            advantage = abs(b-spatial)-abs(b-cls)
            for key, value in (('occlusion_contrast',b),('cls_contrast',cls),('spatial_contrast',spatial),
                               ('residual_advantage',advantage)):
                require(abs(value-checked['comparisons'][key]) <= 1e-12, 'independent comparison differs')
            eligible = all(saved['dose']['q']/v >= .02 for v in saved['dose']['receiver_norms'].values())
            require(not eligible and saved['dose']['status'] == checked['dose_status'] == 'limited-dose', 'dose status')
            output.append({'image_id':ident,'category_id':category,'drops':drops,'occlusion_contrast':b,
                           'cls_contrast':cls,'spatial_contrast':spatial,'residual_advantage':advantage,
                           'q_over_receiver_norm':{k:saved['dose']['q']/v for k,v in saved['dose']['receiver_norms'].items()},
                           'dose_status':'limited-dose'})
    result = {'schema':'vision-cls-occlusion-discovery-decimal-review-v1','precision':60,
              'independent_audit_sha256':hashlib.sha256(report_raw).hexdigest(),
              'max_abs_drop_error':max_error,'cases':output,
              'scope':'Saved float32 logit arithmetic only; no landing, source, execution or generalization attestation.'}
    raw=(json.dumps(result,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
    with OUTPUT.open('xb') as stream:
        require(stream.write(raw)==len(raw),'short output write')
    print(json.dumps({'sha256':hashlib.sha256(raw).hexdigest(),'max_abs_drop_error':max_error,'cases':output},sort_keys=True))


if __name__ == '__main__':
    main()
