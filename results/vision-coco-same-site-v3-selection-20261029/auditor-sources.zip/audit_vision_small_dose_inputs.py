"""Independent annotation, geometry, image and frozen-source audit; no model.

Invoke only after the study owner has frozen the case manifest. Byte agreement
with third-party mirrors is not proof of official dataset origin or absence
from pretraining. The source snapshot and chronology remain cooperative.
"""
import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys
import urllib.request

PRIOR_SHA = '8b5cbfa3b2ab2786721b2c7f2e1975256aaf0864dd34784ed4bfb5e609706207'
ANNOTATION_SHA = 'e8c7f7908f1d7278341fae127d0da654f102f11bd7b21d8aeefa635b8c810b6f'
MIRROR = 'https://huggingface.co/datasets/merve/coco/resolve/9e50abcdc1361852f34841af4939cbcd2d37c92f/val2017/'
SOURCES = {'docs/VISION_COCO_SMALL_DOSE_V2.md','tools/prepare_vision_coco_small_dose.py',
           'looking_glass/__init__.py','looking_glass/vision_coco_small_dose_cases.py',
           'looking_glass/vision_coco_cases.py','experiments/vision_coco_spatial_v1.json'}

def digest(data): return hashlib.sha256(data).hexdigest()
def require(cond, reason):
    if not cond: raise ValueError(reason)
def parse(data):
    def uniq(pairs):
        out={}
        for k,v in pairs:
            require(k not in out, 'duplicate JSON key');out[k]=v
        return out
    def bad(_):raise ValueError('invalid JSON constant')
    def finite(s):
        x=float(s); require(math.isfinite(x),'nonfinite number'); return x
    return json.loads(data, object_pairs_hook=uniq, parse_constant=bad, parse_float=finite)
def eq(a,b):
    if type(a) is not type(b):return False
    if type(a) is list:return len(a)==len(b) and all(eq(x,y) for x,y in zip(a,b))
    if type(a) is dict:return set(a)==set(b) and all(eq(a[k],b[k]) for k in a)
    return a==b
def rank(cat,image):return (digest(f'vision-coco-small-dose-v2:{cat}:{image}'.encode('ascii')),image)
def radius(p):return (p[0]-6)**2+(p[1]-6)**2

def audit(args):
    sys.path.insert(0,str(args.pil_dir.resolve()))
    import numpy as np
    import PIL
    from PIL import Image, ImageDraw
    require(PIL.__version__=='11.3.0','Pillow version')
    prior_raw=args.prior.read_bytes();require(digest(prior_raw)==PRIOR_SHA,'v1 manifest bytes')
    prior=parse(prior_raw); require(len(prior['pairs'])==12,'v1 pair count')
    old=[p[s] for p in prior['pairs'] for s in ('cat','dog')]
    excluded={v['image_id'] for v in old};require(len(excluded)==24,'v1 image set')
    old_jpeg={v['jpeg_sha256'] for v in old};old_pixels={v['pixel_sha256'] for v in old}
    raw=args.manifest.read_bytes();m=parse(raw)
    require(raw==(json.dumps(m,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode(),'canonical manifest')
    require(m['schema']=='vision-coco-vit-small-dose-cases-v2' and m['annotation_sha256']==ANNOTATION_SHA and m['prior_manifest_sha256']==PRIOR_SHA,'manifest schema/pins')
    for key in ('annotation_url','model_repo','model_revision','model_files','class_groups','processor'):
        require(eq(m[key],prior[key]),'v1 model/annotation/processor binding: '+key)
    require(m['preparation_versions']['pillow']=='11.3.0','preparation rasterizer')
    snap=m['selection_source']; revision=snap['revision']; require(len(revision)==40 and all(c in '0123456789abcdef' for c in revision),'selection revision')
    require(set(snap['source_sha256'])==SOURCES,'selection source inventory')
    for name, expected in snap['source_sha256'].items():
        saved=subprocess.check_output(['git','--no-replace-objects','show',revision+':'+name],cwd=args.checkout)
        require(digest(saved)==expected,'source commit mismatch '+name)
    annotation_raw=(args.assets/'instances_val2017.json').read_bytes(); require(digest(annotation_raw)==ANNOTATION_SHA,'annotation bytes')
    for name, expected in prior['model_files'].items():require(digest((args.assets/name).read_bytes())==expected,'asset '+name)
    ann=parse(annotation_raw);images={v['id']:v for v in ann['images']};licenses={v['id']:v for v in ann['licenses']}
    require(len(images)==len(ann['images']),'duplicate image identity')
    all_by_image={}; animals={}
    for a in ann['annotations']:
        all_by_image.setdefault(a['image_id'],[]).append(a)
        if a['category_id'] in (17,18):animals.setdefault(a['image_id'],[]).append(a)
    candidates={17:[],18:[]}
    for image_id, alist in animals.items():
        image=images[image_id]
        if image_id in excluded or image_id==39769 or len(alist)!=1 or alist[0]['iscrowd'] or image['license'] not in (4,5,7,8):continue
        a=alist[0];x,y,w,h=a['bbox'];iw=image['width'];ih=image['height']
        require(all(math.isfinite(float(v)) for v in (x,y,w,h)),'nonfinite box')
        if iw<224 or ih<224 or max(iw/ih,ih/iw)>2 or not .08<=w*h/(iw*ih)<=.70 or w*224/iw<32 or h*224/ih<32:continue
        box=(x*224/iw,y*224/ih,(x+w)*224/iw,(y+h)*224/ih)
        inside=[];outside=[]
        for row in range(13):
            for col in range(13):
                l,t,r,b=16*col,16*row,16*(col+2),16*(row+2)
                if l>=box[0] and t>=box[1] and r<=box[2] and b<=box[3]:inside.append((row,col))
                if r<=box[0] or l>=box[2] or b<=box[1] or t>=box[3]:outside.append((row,col))
        if not inside or not outside:continue
        polys=a.get('segmentation')
        if not isinstance(polys,list) or not polys or any(type(p) is not list or len(p)<6 or len(p)%2 for p in polys):continue
        mask=Image.new('L',(224,224),0);draw=ImageDraw.Draw(mask)
        for poly in polys:
            require(all(math.isfinite(float(v)) for v in poly),'nonfinite polygon')
            draw.polygon([(poly[j]*224/iw,poly[j+1]*224/ih) for j in range(0,len(poly),2)],fill=1)
        pix=np.asarray(mask,dtype=np.int64); counts={}
        for row,col in inside:
            counts[(row,col)]=[int(pix[16*(row+dr):16*(row+dr+1),16*(col+dc):16*(col+dc+1)].sum()) for dr in range(2) for dc in range(2)]
        qualified={c for c,v in counts.items() if sum(v)>=512}
        if not qualified:continue
        candidates[a['category_id']].append({'image':image,'ann':a,'box':box,'inside':qualified,'outside':set(outside),'counts':counts,'mask_sha':digest(mask.tobytes())})
    for cat in (17,18):candidates[cat].sort(key=lambda c:rank(cat,c['image']['id']))
    used=set();selected=[]
    for cat in candidates[17]:
        ci=cat['image']['id']
        if ci in used:continue
        for dog in candidates[18]:
            di=dog['image']['id']
            if di in used:continue
            locations=sorted(((a,b) for a in cat['inside']&dog['inside'] for b in cat['outside']&dog['outside'] if radius(a)==radius(b)),
                             key=lambda z:(abs(z[0][0]-z[1][0])+abs(z[0][1]-z[1][1]),radius(z[0]),z))
            for block,control in locations:
                forbidden=used|{ci,di}
                cd=next((a for a in candidates[17] if a['image']['id'] not in forbidden and block in a['inside']),None)
                dd=next((a for a in candidates[18] if a['image']['id'] not in forbidden and block in a['inside']),None)
                if cd is None or dd is None:continue
                selected.append((cat,dog,cd,dd,block,control));used.update((ci,di,cd['image']['id'],dd['image']['id']));break
            if ci in used:break
        if len(selected)==8:break
    require(len(selected)==8 and len(used)==32,f'selection insufficient or duplicate: {len(selected)} pairs, {len(used)} distinct images')
    require(len(m['pairs'])==8,'pair count')
    require(eq(m['selection_diagnostics']['mask_qualified_candidates'],{str(k):len(v) for k,v in candidates.items()}),'candidate counts')
    seen_ids=set();seen_jpeg=set();seen_pixel=set();remote=[]; roles=('cat','dog','cat_donor','dog_donor')
    for i,(pair,quad) in enumerate(zip(m['pairs'],selected)):
        block,control=quad[4:]
        require(pair['pair_id']==f'pair-{i:02}' and pair['split']=='heldout','pair identity')
        require(eq(pair['box_block_row_col'],list(block)) and eq(pair['control_block_row_col'],list(control)) and eq(pair['squared_center_radius'],radius(block)),'selected geometry')
        for xy,key in ((block,'box_tokens'),(control,'control_tokens')):
            require(eq(pair[key],[1+14*(xy[0]+dr)+xy[1]+dc for dr in range(2) for dc in range(2)]),'token numbering')
        for role, item in zip(roles,quad[:4]):
            actual=pair[role]; image=item['image']; a=item['ann']; image_id=image['id']
            require(image_id not in seen_ids and image_id not in excluded and actual['image_id']==image_id,'selected image ID')
            seen_ids.add(image_id)
            for k in ('file_name','width','height','coco_url','flickr_url'):require(eq(actual[k],image[k]),'image metadata '+k)
            require(eq(actual['license'],licenses[image['license']]) and actual['annotation_id']==a['id'] and actual['category_id']==a['category_id'] and eq(actual['bbox_xywh'],a['bbox']) and eq(actual['bbox_resized_xyxy'],list(item['box'])),'annotation metadata')
            counts=item['counts'][block];require(actual['mask_sha256']==item['mask_sha'] and eq(actual['inside_token_mask_pixels'],counts) and actual['inside_block_mask_pixels']==sum(counts)>=512,'mask metadata')
            require(actual['selection_rank_sha256']==rank(a['category_id'],image_id)[0],'selection rank')
            l,t,r,b=16*control[1],16*control[0],16*(control[1]+2),16*(control[0]+2); overlaps=[]
            for other in all_by_image[image_id]:
                if other['id']==a['id']:continue
                x,y,w,h=other['bbox'];iw=image['width'];ih=image['height']
                x0,x1,y0,y1=x*224/iw,(x+w)*224/iw,y*224/ih,(y+h)*224/ih
                if l<x1 and r>x0 and t<y1 and b>y0:overlaps.append({'annotation_id':other['id'],'category_id':other['category_id']})
            overlaps.sort(key=lambda x:x['annotation_id']);require(eq(actual['control_other_box_overlaps'],overlaps),'outside overlaps')
            name=actual['file_name'];require(name==f'{image_id:012d}.jpg' and actual['mirror_url']==MIRROR+name,'mirror identity')
            jpg=(args.assets/'images'/name).read_bytes();jhash=digest(jpg)
            require(type(actual['jpeg_bytes']) is int and actual['jpeg_bytes']==len(jpg) and actual['jpeg_sha256']==jhash and jhash not in old_jpeg|seen_jpeg,'JPEG bytes/exclusion')
            seen_jpeg.add(jhash)
            with Image.open(args.assets/'images'/name) as im:
                require(im.size==(image['width'],image['height']) and im.getexif().get(274,1)==1,'dimensions/EXIF')
                resized=im.convert('RGB').resize((224,224),Image.Resampling.BILINEAR)
                pix=(np.asarray(resized).astype(np.float64)*(1/255)).astype(np.float32)
                pix=(pix-np.float32(.5))/np.float32(.5)
                pix=np.ascontiguousarray(pix.transpose(2,0,1).astype('<f4',copy=False))
            phash=digest(pix.tobytes());require(actual['pixel_sha256']==phash and phash not in old_pixels|seen_pixel,'pixel bytes/exclusion');seen_pixel.add(phash)
            remote.append((name,len(jpg),jhash))
    if args.verify_https:
        def check(x):
            name,size,h=x;request=urllib.request.Request(MIRROR+name,headers={'User-Agent':'model-looking-glass-vision-audit/2.0'})
            with urllib.request.urlopen(request,timeout=45) as response:data=response.read(5_000_001)
            return len(data)==size and digest(data)==h
        with ThreadPoolExecutor(max_workers=4) as pool:require(all(pool.map(check,remote)),'mirror bytes')
    return {'status':'saved_input_consistency_verified','manifest_sha256':digest(raw),'selection_revision':revision,'annotation_sha256':ANNOTATION_SHA,'prior_manifest_sha256':PRIOR_SHA,'pairs':len(selected),'fresh_images':len(seen_ids),'v1_excluded_images':len(excluded),'distinct_jpegs':len(seen_jpeg),'distinct_pixel_hashes':len(seen_pixel),'https_checked':args.verify_https,'limitations':['Pinned third-party mirrors do not independently authenticate official COCO origin.','Input bytes and separation do not establish pretraining independence, execution, or pre-forward chronology.']}
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--manifest',type=Path,required=True);parser.add_argument('--prior',type=Path,required=True);parser.add_argument('--assets',type=Path,required=True);parser.add_argument('--pil-dir',type=Path,required=True);parser.add_argument('--checkout',type=Path,required=True);parser.add_argument('--verify-https',action='store_true');a=parser.parse_args();print(json.dumps(audit(a),indent=2))
