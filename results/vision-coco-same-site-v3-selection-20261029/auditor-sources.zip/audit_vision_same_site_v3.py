"""Independent v3 annotation/selection/image audit, without a model forward."""
import argparse, collections, hashlib, json, math, subprocess, sys, urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from audit_vision_small_dose_inputs import PRIOR_SHA, ANNOTATION_SHA, MIRROR, digest, require, parse, eq, rank, radius
SOURCES={'docs/VISION_COCO_SMALL_DOSE_V2.md','docs/VISION_COCO_SAME_SITE_SMALL_DOSE_V3.md',
         'tools/prepare_vision_coco_same_site.py','looking_glass/__init__.py',
         'looking_glass/vision_coco_same_site_cases.py','looking_glass/vision_coco_small_dose_cases.py',
         'looking_glass/vision_coco_cases.py','experiments/vision_coco_spatial_v1.json'}

def audit(args):
 sys.path.insert(0,str(args.pil_dir.resolve()))
 import numpy as np
 import PIL
 from PIL import Image, ImageDraw
 require(PIL.__version__=='11.3.0','Pillow version')
 old_raw=args.prior.read_bytes();require(digest(old_raw)==PRIOR_SHA,'v1 manifest bytes')
 old=parse(old_raw);old_images=[p[k] for p in old['pairs'] for k in ('cat','dog')]
 excluded={v['image_id'] for v in old_images};old_jpeg={v['jpeg_sha256'] for v in old_images};old_pixel={v['pixel_sha256'] for v in old_images}
 require(len(excluded)==24,'v1 exclusion count')
 raw=args.manifest.read_bytes();m=parse(raw)
 require(raw==(json.dumps(m,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode(),'canonical manifest')
 require(m['schema']=='vision-coco-vit-same-site-cases-v3' and m['annotation_sha256']==ANNOTATION_SHA and m['prior_manifest_sha256']==PRIOR_SHA,'manifest schema/pins')
 for key in ('annotation_url','model_repo','model_revision','model_files','class_groups','processor'):require(eq(m[key],old[key]),'v1 source binding '+key)
 require(m['preparation_versions']['pillow']=='11.3.0','preparation version')
 snap=m['selection_source'];rev=snap['revision'];require(len(rev)==40 and all(c in '0123456789abcdef' for c in rev),'revision')
 require(set(snap['source_sha256'])==SOURCES,'selection source inventory')
 for path,h in snap['source_sha256'].items():
  b=subprocess.check_output(['git','--no-replace-objects','show',rev+':'+path],cwd=args.checkout);require(digest(b)==h,'source mismatch '+path)
 annotation_raw=(args.assets/'instances_val2017.json').read_bytes();require(digest(annotation_raw)==ANNOTATION_SHA,'annotation bytes')
 for name,expected in old['model_files'].items():require(digest((args.assets/name).read_bytes())==expected,'model asset '+name)
 ann=parse(annotation_raw);imgs={v['id']:v for v in ann['images']};licenses={v['id']:v for v in ann['licenses']}
 require(len(imgs)==len(ann['images']),'duplicate image ID')
 all_by_image={};animals={}
 for a in ann['annotations']:
  all_by_image.setdefault(a['image_id'],[]).append(a)
  if a['category_id'] in (17,18):animals.setdefault(a['image_id'],[]).append(a)
 candidates={17:[],18:[]}
 for iid,instances in animals.items():
  im=imgs[iid]
  if iid in excluded or iid==39769 or im['license'] not in (4,5,7,8) or len({a['category_id'] for a in instances})!=1:continue
  valid=[]
  for a in instances:
   polygons=a.get('segmentation')
   if a['iscrowd'] or type(polygons) is not list or not polygons or any(type(p) is not list or len(p)<6 or len(p)%2 for p in polygons):continue
   require(all(math.isfinite(float(x)) for x in a['bbox']),'nonfinite box');valid.append(a)
  if not valid:continue
  a=sorted(valid,key=lambda x:(-x['bbox'][2]*x['bbox'][3],x['id']))[0]
  x,y,w,h=a['bbox'];iw=im['width'];ih=im['height']
  if iw<224 or ih<224 or max(iw/ih,ih/iw)>2 or not .08<=w*h/(iw*ih)<=.70 or w*224/iw<32 or h*224/ih<32:continue
  box=(x*224/iw,y*224/ih,(x+w)*224/iw,(y+h)*224/ih)
  inside=[]
  for row in range(13):
   for col in range(13):
    l,t,r,b=16*col,16*row,16*(col+2),16*(row+2)
    if l>=box[0] and t>=box[1] and r<=box[2] and b<=box[3]:inside.append((row,col))
  if not inside:continue
  mask=Image.new('L',(224,224),0);draw=ImageDraw.Draw(mask)
  for poly in a['segmentation']:
   require(all(math.isfinite(float(v)) for v in poly),'nonfinite polygon')
   draw.polygon([(poly[j]*224/iw,poly[j+1]*224/ih) for j in range(0,len(poly),2)],fill=1)
  pix=np.asarray(mask,dtype=np.int64);counts={}
  for row,col in inside:counts[(row,col)]=[int(pix[16*(row+dr):16*(row+dr+1),16*(col+dc):16*(col+dc+1)].sum()) for dr in range(2) for dc in range(2)]
  qualified={b for b,v in counts.items() if sum(v)>=512}
  if not qualified:continue
  candidates[a['category_id']].append({'image':im,'ann':a,'instances':instances,'box':box,'inside':qualified,'counts':counts,'mask_sha':digest(mask.tobytes())})
 for category in (17,18):candidates[category].sort(key=lambda v:rank(category,v['image']['id']))
 targets=set();donors=set();selected=[]
 for cat in candidates[17]:
  ci=cat['image']['id']
  if ci in targets or ci in donors:continue
  for dog in candidates[18]:
   di=dog['image']['id']
   if di in targets or di in donors:continue
   for block in sorted(cat['inside']&dog['inside'],key=lambda v:(radius(v),v)):
    available={}
    for category in (17,18):
     available[category]=sorted((q for q in candidates[category] if q['image']['id'] not in targets and q['image']['id'] not in (ci,di) and block in q['inside']),key=lambda q:(q['image']['id'] not in donors,rank(category,q['image']['id'])))
    if not available[17] or not available[18]:continue
    cd,dd=available[17][0],available[18][0];selected.append((cat,dog,cd,dd,block));targets.update((ci,di));donors.update((cd['image']['id'],dd['image']['id']));break
   if ci in targets:break
  if len(selected)==8:break
 require(len(selected)==8 and len(targets)==16 and not (targets&donors),'selection insufficient/collision')
 require(len(m['pairs'])==8,'pair count')
 diag=m['selection_diagnostics'];require(eq(diag['mask_qualified_candidates'],{str(k):len(v) for k,v in candidates.items()}),'candidate counts')
 donor_counts=collections.Counter(q[role]['image']['id'] for q in selected for role in (2,3))
 require(diag['distinct_target_images']==16 and diag['distinct_donor_images']==len(donors) and eq(diag['donor_side_counts'],{str(k):v for k,v in sorted(donor_counts.items())}),'reuse diagnostics')
 by_id={};jpeg_owner={};pixel_owner={};roles=('cat','dog','cat_donor','dog_donor')
 for number,(pair,quad) in enumerate(zip(m['pairs'],selected)):
  block=quad[4];require(pair['pair_id']==f'pair-{number:02}' and pair['split']=='heldout','pair identity')
  require(eq(pair['box_block_row_col'],list(block)) and eq(pair['squared_center_radius'],radius(block)) and eq(pair['box_tokens'],[1+14*(block[0]+dr)+block[1]+dc for dr in range(2) for dc in range(2)]),'selected geometry')
  for role,item in zip(roles,quad[:4]):
   actual=pair[role];im=item['image'];ann0=item['ann'];iid=im['id'];require(actual['image_id']==iid and iid not in excluded,'image identity')
   for key in ('file_name','width','height','coco_url','flickr_url'):require(eq(actual[key],im[key]),'image metadata '+key)
   require(eq(actual['license'],licenses[im['license']]) and actual['annotation_id']==ann0['id'] and actual['category_id']==ann0['category_id'] and eq(actual['bbox_xywh'],ann0['bbox']) and eq(actual['bbox_resized_xyxy'],list(item['box'])),'annotation metadata')
   require(eq(actual['animal_annotation_ids'],sorted(v['id'] for v in item['instances'])),'animal instances')
   vals=item['counts'][block];require(actual['mask_sha256']==item['mask_sha'] and eq(actual['inside_token_mask_pixels'],vals) and actual['inside_block_mask_pixels']==sum(vals)>=512,'mask')
   require(actual['selection_rank_sha256']==rank(ann0['category_id'],iid)[0],'rank')
   l,t,r,b=16*block[1],16*block[0],16*(block[1]+2),16*(block[0]+2);others=[];overlaps=[]
   for other in all_by_image[iid]:
    if other['id']==ann0['id']:continue
    x,y,w,h=other['bbox'];iw=im['width'];ih=im['height'];x0,x1,y0,y1=x*224/iw,(x+w)*224/iw,y*224/ih,(y+h)*224/ih
    hit=l<x1 and r>x0 and t<y1 and b>y0
    others.append({'annotation_id':other['id'],'category_id':other['category_id'],'bbox_xywh':other['bbox'],'overlaps_inside':hit})
    if hit:overlaps.append({'annotation_id':other['id'],'category_id':other['category_id']})
   others.sort(key=lambda v:v['annotation_id']);overlaps.sort(key=lambda v:v['annotation_id'])
   require(eq(actual['other_boxes'],others) and eq(actual['inside_other_box_overlaps'],overlaps),'other box inventory')
   name=actual['file_name'];require(name==f'{iid:012d}.jpg' and actual['mirror_url']==MIRROR+name,'mirror identity')
   jpg=(args.assets/'images'/name).read_bytes();jh=digest(jpg)
   require(type(actual['jpeg_bytes']) is int and actual['jpeg_bytes']==len(jpg) and actual['jpeg_sha256']==jh and jh not in old_jpeg,'JPEG/exclusion')
   with Image.open(args.assets/'images'/name) as imfile:
    require(imfile.size==(im['width'],im['height']) and imfile.getexif().get(274,1)==1,'dimension/EXIF')
    arr=np.asarray(imfile.convert('RGB').resize((224,224),Image.Resampling.BILINEAR)).astype(np.float64)
    arr=(arr*(1/255)).astype(np.float32);arr=(arr-np.float32(.5))/np.float32(.5);arr=np.ascontiguousarray(arr.transpose(2,0,1).astype('<f4',copy=False))
   ph=digest(arr.tobytes());require(actual['pixel_sha256']==ph and ph not in old_pixel,'pixel/exclusion')
   require(iid not in by_id or by_id[iid]==(jh,ph),'changed reused donor')
   require(jh not in jpeg_owner or jpeg_owner[jh]==iid,'cross-ID JPEG duplicate')
   require(ph not in pixel_owner or pixel_owner[ph]==iid,'cross-ID pixel duplicate')
   by_id[iid]=(jh,ph);jpeg_owner[jh]=iid;pixel_owner[ph]=iid
 if args.verify_https:
  def check(v):
   iid,(jhash,_)=v; name=f'{iid:012d}.jpg';req=urllib.request.Request(MIRROR+name,headers={'User-Agent':'model-looking-glass-vision-audit/3.0'})
   with urllib.request.urlopen(req,timeout=45) as res:b=res.read(5_000_001)
   return digest(b)==jhash
  with ThreadPoolExecutor(max_workers=4) as pool:require(all(pool.map(check,by_id.items())),'HTTPS bytes')
 return {'status':'saved_input_consistency_verified','manifest_sha256':digest(raw),'selection_revision':rev,'annotation_sha256':ANNOTATION_SHA,'prior_manifest_sha256':PRIOR_SHA,'target_images':len(targets),'distinct_donors':len(donors),'distinct_images':len(by_id),'donor_references':sum(donor_counts.values()),'https_checked':args.verify_https,'limitations':['Third-party mirrors do not independently authenticate official COCO origin.','Input bytes/split do not establish pretraining independence, execution or chronology.']}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--manifest',type=Path,required=True);p.add_argument('--prior',type=Path,required=True);p.add_argument('--assets',type=Path,required=True);p.add_argument('--pil-dir',type=Path,required=True);p.add_argument('--checkout',type=Path,required=True);p.add_argument('--verify-https',action='store_true');args=p.parse_args();print(json.dumps(audit(args),indent=2))
